/* ---------- 원본 그림(문제지에서 잘라 낸 그림·표·화면) ---------- */
function figImg(f, alt){ return `<img class="fig" src="${f.f}" width="${f.w}" height="${f.h}" loading="lazy" alt="${escapeHtml(alt)}">`; }
function figBogiHtml(it){
  const fi = figI(it);
  if(!fi) return it.보기 ? `<div class="bogi"><div class="bogi-label">제시 자료</div><div class="bogi-text">${escapeHtml(it.보기)}</div></div>` : '';
  const label = fi.m === 'ch' ? '제시 자료 · 선택지 — 원본 문제지 그림' : '제시 자료 — 원본 문제지 그림';
  return `<div class="bogi fig-box"><div class="bogi-label">${label}</div>${figImg(fi, '원본 문제지의 제시 자료 부분')}
    ${it.보기 ? `<details class="fig-txt"><summary>글자로 보기</summary><div class="bogi-text">${escapeHtml(it.보기)}</div></details>` : ''}</div>`;
}
/* 선택지가 그림인 문항: 번호만 골라 채점할 수 있게 한다 */
function figChoices(it){
  const fi = figI(it);
  return fi && fi.m === 'ch' ? [1,2,3,4,5].map(n=>`위 그림의 ${CIRCLED[n]}`) : null;
}
function figPassageHtml(pf, textHtml){
  return `<div class="pfig-wrap">
    <div class="pfig-bar"><span>원본 문제지 그림으로 보는 중</span>${textHtml ? '<button type="button" class="btn-plain pfig-toggle" aria-expanded="false">글자로 보기</button>' : ''}</div>
    <div class="pfig">${pf.map(f=>figImg(f, '원본 문제지의 지문 부분')).join('')}</div>
    ${textHtml ? `<div class="ptext" hidden>${textHtml}</div>` : ''}
  </div>`;
}
document.addEventListener('click', e=>{
  const b = e.target.closest('.pfig-toggle'); if(!b) return;
  const w = b.closest('.pfig-wrap'); const txt = w.querySelector('.ptext'), fig = w.querySelector('.pfig');
  const toText = txt.hidden;
  txt.hidden = !toText; fig.hidden = toText;
  b.textContent = toText ? '원본 그림으로 보기' : '글자로 보기';
  b.setAttribute('aria-expanded', String(toText));
  w.querySelector('.pfig-bar span').textContent = toText ? '글자로 보는 중 (그림은 빠져 있음)' : '원본 문제지 그림으로 보는 중';
});
