# -*- coding: utf-8 -*-
"""HWP 문제지(문단 목록)에서 지문·문항·선택지·<보기>를 뽑는다."""
import json, re
SET = re.compile(r"^\[\s*(\d{1,2})\s*[～~∼\-–]\s*(\d{1,2})\s*\]\s*(.*)$")
ITEM = re.compile(r"^(\d{1,2})\s*\.\s*(.+)$")
CH = re.compile(r"[①②③④⑤]")
MARK = re.compile(r"^\[[A-Z가-하]\]$")
SKIP = re.compile(r"^(이 문제지에 관한 저작권은|\* 확인 사항|◦ 답안지의|※ 확인 사항)")
CIR = "①②③④⑤"

def split_choices(t, last=0):
    """선택지 번호는 순서대로(last+1) 나올 때만 끊는다. 선택지 안의 ① 같은 인용 기호는 본문으로 둔다."""
    parts = re.split(r"([①②③④⑤])", t)
    out = []; cur = None
    for p in parts:
        if p and p in CIR and CIR.index(p)+1 == last+1:
            cur = [CIR.index(p)+1, ""]; out.append(cur); last += 1
        elif cur is not None: cur[1] += p
    return [(n, s.strip()) for n, s in out]

def parse(paras, first_item=1):
    lines = [(lvl, t.replace("\u3000", " ").rstrip()) for lvl, t in paras]
    sets = []; items = []; cur_set = None; cur = None; expect = 1; mode = None; started = False
    for lvl, t in lines:
        s = t.strip()
        if SKIP.match(s): continue
        m = SET.match(s)
        if m and int(m.group(1)) == expect:
            a, b = int(m.group(1)), int(m.group(2))
            cur_set = {"range": (a, b), "instr": m.group(3), "lines": []}; sets.append(cur_set)
            cur = None; mode = "passage"; started = True; continue
        m = ITEM.match(s)
        if m and int(m.group(1)) == expect:
            n = int(m.group(1)); expect = n + 1
            in_set = cur_set and cur_set["range"][0] <= n <= cur_set["range"][1]
            cur = {"num": n, "stem": s, "block": [], "set": cur_set["range"] if in_set else None}
            items.append(cur); mode = "item"; started = True; continue
        if not started: continue
        if mode == "passage":
            if MARK.match(s) and cur_set["lines"]: cur_set["lines"][-1] += " " + s
            else: cur_set["lines"].append(s)
            continue
        if cur is not None: cur["block"].append(s)
    shared = {}
    for it in items:
        blk = [x for x in it["block"]]
        while blk and re.fullmatch(r"\[\d점\]", blk[0] or "x"): it["stem"] += " " + blk.pop(0)
        # 마지막 ①~⑤ 묶음을 선택지로 본다
        starts = [i for i, x in enumerate(blk) if x.startswith("①")]
        ch = {}; cut = len(blk); tail = []
        for st in reversed(starts):
            tmp = {}; last = None; ok = True; j = st
            while j < len(blk):
                x = blk[j]
                if CH.match(x) and x[0] == CIR[(last or 0)] if (last or 0) < 5 else False:
                    for n, txt in split_choices(x, last or 0): tmp[n] = txt; last = n
                elif x.startswith("※"):
                    break
                elif x and last:
                    if last < 5: tmp[last] += " " + x
                    else: tmp[5] += " " + x
                j += 1
            if sorted(tmp) == [1, 2, 3, 4, 5]:
                ch = tmp; cut = st; tail = blk[j:]; break
        if not ch:   # 표 안에서 줄 끝에 번호가 붙은 경우
            tmp = {}
            for i, x in enumerate(blk):
                m = re.match(r"^(.*?)\s*([①②③④⑤])$", x)
                if m and m.group(1): tmp[CIR.index(m.group(2))+1] = m.group(1).strip()
            if sorted(tmp) == [1, 2, 3, 4, 5]: ch = tmp; cut = 0; it["choice_in_table"] = True
        it["choices"] = ch
        bogi = blk[:cut]
        while bogi and bogi[0] == "": bogi.pop(0)
        while bogi and bogi[-1] == "": bogi.pop()
        it["bogi"] = bogi if not it.get("choice_in_table") else []
        it["table_block"] = blk if it.get("choice_in_table") else None
        if tail and tail[0].startswith("※") and it["set"]:
            shared[it["set"]] = (it["num"], [x for x in tail if x])
    for it in items:
        sh = shared.get(it["set"])
        if sh and it["num"] > sh[0]: it["bogi"] = sh[1] + it["bogi"]
    return sets, items

def passage_text(lines):
    out = []
    for s in lines:
        if s == "":
            if out and out[-1] != "": out.append("")
            continue
        out.append(s)
    while out and out[0] == "": out.pop(0)
    while out and out[-1] == "": out.pop()
    return "\n".join(out)

if __name__ == "__main__":
    import sys
    P = json.load(open("/home/claude/hwp/hwp_paras.json"))
    for k in ["2014-11-A", "2014-11-B", "2009-11"]:
        sets, items = parse(P[k])
        bad = [(i["num"], len(i["choices"])) for i in items if len(i["choices"]) != 5]
        print(k, "sets", [s["range"] for s in sets], "items", len(items), "bad choices", bad, "table", [i["num"] for i in items if i.get("choice_in_table")])
        for i in items:
            if i["num"] in (6,12,34,35,36,3): print("  ", i["num"], i["stem"][:50], "| bogi:", [b[:30] for b in i["bogi"]][:4], "| ch:", {k:v[:25] for k,v in i["choices"].items()})
