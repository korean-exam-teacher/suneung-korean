import sys, zlib, struct, re
sys.path.insert(0, "/home/claude/hwp")
from cfb import CFB
INLINE8 = set([1,2,3,4,5,6,7,8,9,11,12,14,15,16,17,18,19,20,21,22,23])
def para_text(b):
    out = []; i = 0; n = len(b)//2
    u = struct.unpack(f"<{n}H", b[:n*2])
    while i < n:
        c = u[i]
        if c < 32:
            if c == 9: out.append(" "); i += 8; continue
            if c in INLINE8: i += 8; continue
            if c == 10: out.append("\n")
            elif c == 13: pass
            elif c == 9: out.append("\t")
            i += 1; continue
        out.append(chr(c)); i += 1
    t = "".join(out)
    return t.encode("utf-16le", "surrogatepass").decode("utf-16le", "replace")
def records(data):
    p = 0
    while p + 4 <= len(data):
        h = struct.unpack_from("<I", data, p)[0]; p += 4
        tag = h & 0x3FF; lvl = (h >> 10) & 0x3FF; size = (h >> 20) & 0xFFF
        if size == 0xFFF: size = struct.unpack_from("<I", data, p)[0]; p += 4
        yield tag, lvl, data[p:p+size]; p += size
def paragraphs(path):
    f = CFB(path)
    hdr = f.read(f.streams["FileHeader"])
    compressed = hdr[36] & 1
    secs = sorted([k for k in f.streams if k.startswith("BodyText/Section")], key=lambda k: int(k[16:]))
    paras = []
    for k in secs:
        data = f.read(f.streams[k])
        if compressed: data = zlib.decompress(data, -15)
        for tag, lvl, body in records(data):
            if tag == 67: paras.append((lvl, para_text(body)))
    return paras
if __name__ == "__main__":
    P = paragraphs(sys.argv[1])
    print(len(P))
    for lvl, t in P[:int(sys.argv[2]) if len(sys.argv) > 2 else 60]: print(lvl, repr(t[:150]))
