"""Minimal pure-python MS-CFB reader (프로젝트 claude/cfb.py와 같은 코드)."""
import struct
ENDOFCHAIN = 0xFFFFFFFE
FREESECT = 0xFFFFFFFF
NOSTREAM = 0xFFFFFFFF

class Entry:
    __slots__ = ("name", "type", "left", "right", "child", "start", "size")

class CFB:
    def __init__(self, path):
        self.data = open(path, "rb").read()
        assert self.data[:8] == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1", "not a CFB file"
        hdr = self.data
        self.sector_shift = struct.unpack_from("<H", hdr, 30)[0]
        self.mini_sector_shift = struct.unpack_from("<H", hdr, 32)[0]
        self.sector_size = 1 << self.sector_shift
        self.mini_sector_size = 1 << self.mini_sector_shift
        self.first_dir_sector = struct.unpack_from("<I", hdr, 48)[0]
        self.mini_cutoff = struct.unpack_from("<I", hdr, 56)[0]
        self.first_minifat_sector = struct.unpack_from("<I", hdr, 60)[0]
        self.num_minifat_sectors = struct.unpack_from("<I", hdr, 64)[0]
        self.first_difat_sector = struct.unpack_from("<I", hdr, 68)[0]
        header_difat = list(struct.unpack_from("<109I", hdr, 76))
        difat = [s for s in header_difat if s != FREESECT]
        sector_num = self.first_difat_sector; seen = set()
        while sector_num not in (ENDOFCHAIN, FREESECT, 0xFFFFFFFC) and sector_num not in seen:
            seen.add(sector_num)
            sec = self._sector(sector_num)
            n = self.sector_size // 4
            vals = struct.unpack_from(f"<{n}I", sec, 0)
            difat.extend(vals[:-1]); sector_num = vals[-1]
        difat = [s for s in difat if s != FREESECT]
        fat = []
        for fs in difat:
            sec = self._sector(fs); n = self.sector_size // 4
            fat.extend(struct.unpack_from(f"<{n}I", sec, 0))
        self.fat = fat
        minifat = []
        if self.num_minifat_sectors:
            for s in self._chain(self.first_minifat_sector, fat):
                sec = self._sector(s); n = self.sector_size // 4
                minifat.extend(struct.unpack_from(f"<{n}I", sec, 0))
        self.minifat = minifat
        dir_bytes = b"".join(self._sector(s) for s in self._chain(self.first_dir_sector, fat))
        self.entries = []
        for i in range(len(dir_bytes) // 128):
            raw = dir_bytes[i*128:(i+1)*128]
            name_len = struct.unpack_from("<H", raw, 64)[0]
            e = Entry()
            e.name = raw[:max(name_len-2, 0)].decode("utf-16le", errors="ignore") if name_len >= 2 else ""
            e.type = raw[66]
            e.left = struct.unpack_from("<I", raw, 68)[0]
            e.right = struct.unpack_from("<I", raw, 72)[0]
            e.child = struct.unpack_from("<I", raw, 76)[0]
            e.start = struct.unpack_from("<I", raw, 116)[0]
            e.size = struct.unpack_from("<Q", raw, 120)[0]
            self.entries.append(e)
        self.root = self.entries[0]
        self._ministream = self._read_stream_normal(self.root.start, self.root.size)
        self.streams = {}
        self._walk(0, "")

    def _sector(self, idx):
        start = 512 + idx * self.sector_size
        return self.data[start:start + self.sector_size]

    def _chain(self, start, fat):
        out = []; s = start; seen = set()
        while s not in (ENDOFCHAIN, FREESECT) and s not in seen and s < len(fat):
            seen.add(s); out.append(s); s = fat[s]
        return out

    def _read_stream_normal(self, start, size):
        return b"".join(self._sector(s) for s in self._chain(start, self.fat))[:size]

    def _read_stream_mini(self, start, size):
        chain = []; s = start; seen = set()
        while s not in (ENDOFCHAIN, FREESECT) and s not in seen and s < len(self.minifat):
            seen.add(s); chain.append(s); s = self.minifat[s]
        buf = bytearray()
        for sec in chain:
            off = sec * self.mini_sector_size
            buf += self._ministream[off:off + self.mini_sector_size]
        return bytes(buf[:size])

    def read(self, entry):
        if entry.size < self.mini_cutoff: return self._read_stream_mini(entry.start, entry.size)
        return self._read_stream_normal(entry.start, entry.size)

    def _collect(self, eid, out):
        if eid == NOSTREAM or eid >= len(self.entries): return
        e = self.entries[eid]
        self._collect(e.left, out); out.append(eid); self._collect(e.right, out)

    def _walk(self, eid, path):
        kids = []; self._collect(self.entries[eid].child, kids)
        for k in kids:
            e = self.entries[k]
            full = path + "/" + e.name if path else e.name
            if e.type == 1: self._walk(k, full)
            elif e.type == 2: self.streams[full] = e
