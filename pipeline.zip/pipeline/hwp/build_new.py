# -*- coding: utf-8 -*-
"""HWP 문제지(2009 수능, 2014 수능 A/B)로 사이트 형식의 문항·지문·선택지 묶음을 만든다 → new_bundle.json"""
import json, re, sys
from collections import Counter, defaultdict
sys.path.insert(0, "/home/claude/hwp"); sys.path.insert(0, "/home/claude/typegroup"); sys.path.insert(0, "/home/claude/old")
from parse_items import parse, passage_text
from para2 import pua
import type_groups as TG

P = json.load(open("/home/claude/hwp/hwp_paras.json"))
T = json.load(open("/home/claude/hsj/answer_tables.json"))

EXAMS = {
    "2014-11-A": dict(y=2014, form="A", name="2014학년도 대학수학능력시험(A형)", first=1),
    "2014-11-B": dict(y=2014, form="B", name="2014학년도 대학수학능력시험(B형)", first=1),
    "2009-11": dict(y=2009, form="", name="2009학년도 대학수학능력시험", first=6),
    "2009-09": dict(y=2009, form="", name="2009학년도 9월 모의평가", first=6, mon=9, kind="평가원 모의평가", paras="2009-09n"),
}
def area_of(ex, n):
    if ex == "2009-09":
        if n <= 10: return "화법과 작문"
        if n <= 12: return "언어와 매체"
        if 20 <= n <= 23 or 28 <= n <= 33 or 38 <= n <= 40 or n >= 47: return "문학"
        return "독서"
    if ex == "2009-11":
        if n <= 10: return "화법과 작문"
        if n <= 12: return "언어와 매체"
        if 20 <= n <= 23 or 28 <= n <= 33 or 37 <= n <= 39 or n >= 47: return "문학"
        return "독서"
    lang_end = 15 if ex.endswith("A") else 16
    if n <= 10: return "화법과 작문"
    if n <= lang_end: return "언어와 매체"
    return "독서" if n <= 30 else "문학"

# 지문 묶음별 소재·분야·작품 (분야·제목은 해당 회차 「정답 및 해설」의 지문 머리말을 따름)
W38 = ["왕방연, 「천만리 머나먼 길에」", "임제, 「청초 우거진 골에」", "원천석, 「흥망이 유수하니」"]
L = {
 ("2014-11-A", 1): ("전교 학생 회장 선거 출마를 고민하는 친구 간의 대화", "화법(대화)", []),
 ("2014-11-A", 4): ("엑스선으로 밝혀낸 고흐 작품의 비밀 학생 발표", "화법(발표)", []),
 ("2014-11-A", 6): ("청소년 UCC 제작 기술 프로그램 제작 건의 글 초고", "작문(건의문)", []),
 ("2014-11-A", 9): ("나눔 도서관을 소개하는 게시판 글과 고쳐 쓰기", "작문(소개하는 글)", []),
 ("2014-11-A", 16): ("분광 분석법의 창안과 과학적 성과", "과학(화학)", []),
 ("2014-11-A", 19): ("선암사 승선교에 담긴 미의식", "예술(건축)", []),
 ("2014-11-A", 22): ("토인비의 문명 단위 역사 연구", "인문(역사학)", []),
 ("2014-11-A", 24): ("간접 광고(PPL)의 이해", "사회(광고)", []),
 ("2014-11-A", 28): ("CD 드라이브의 정보 판독 원리", "기술(정보 저장)", []),
 ("2014-11-A", 31): ("꽃이 지는 모습에서 발견한 이별과 성숙(현대시)", "현대시", ["이형기, 「낙화(洛花)」"]),
 ("2014-11-A", 34): ("아파트 입주권 문제로 고통받는 난장이 가족(현대소설)", "현대소설", ["조세희, 「난장이가 쏘아 올린 작은 공」"]),
 ("2014-11-A", 38): ("임과의 이별·죽음, 왕조의 흥망에 대한 회한(시조)", "고전시가(시조)", W38),
 ("2014-11-A", 41): ("임금에게 자신의 처지를 아뢰고 하직하는 길동(고전소설)", "고전소설", ["허균, 「홍길동전」"]),
 ("2014-11-A", 44): ("소를 바라보며 느끼는 권태(수필)", "수필", ["이상, 「권태」"]),
 ("2014-11-B", 1): ("공장 이전을 둘러싼 회사와 시청의 모의 협상", "화법(협상)", []),
 ("2014-11-B", 4): ("엑스선으로 밝혀낸 고흐 작품의 비밀 학생 발표", "화법(발표)", []),
 ("2014-11-B", 6): ("생태 관광의 문제점과 개선 방안 논설문 자료와 개요", "작문(논설문)", []),
 ("2014-11-B", 9): ("나눔 도서관을 소개하는 게시판 글과 고쳐 쓰기", "작문(소개하는 글)", []),
 ("2014-11-B", 17): ("이덕무 「사소절」에 나타난 독서 태도", "인문(독서 이론)", []),
 ("2014-11-B", 19): ("심신 이원론과 심신 일원론", "인문(철학)", []),
 ("2014-11-B", 22): ("간접 광고(PPL)의 이해", "사회(광고)", []),
 ("2014-11-B", 26): ("지구 상에서 운동하는 물체에 작용하는 전향력", "과학(지구과학)", []),
 ("2014-11-B", 28): ("베토벤 교향곡의 음악사적 의의", "예술(음악)", []),
 ("2014-11-B", 31): ("꿈속에서 보살을 만난 강남홍(고전소설)", "고전소설", ["남영로, 「옥루몽」"]),
 ("2014-11-B", 35): ("어둠과 전짓불을 두려워하는 박준(현대소설)", "현대소설", ["이청준, 「소문의 벽」"]),
 ("2014-11-B", 38): ("임과의 이별·죽음, 왕조의 흥망에 대한 회한(시조)", "고전시가(시조)", W38),
 ("2014-11-B", 41): ("비 오는 저녁의 그리움과 막차를 기다리는 대합실 풍경(현대시)", "현대시", ["조지훈, 「파초우(芭蕉雨)」", "곽재구, 「사평역에서」"]),
 ("2014-11-B", 44): ("소를 바라보며 느끼는 권태(수필)", "수필", ["이상, 「권태」"]),
 ("2009-09", 13): ("디지털 영상 처리 기술과 사진의 조작", "기술(영상 처리)", []),
 ("2009-09", 16): ("영웅의 창조와 전승 과정", "인문(역사학)", []),
 ("2009-09", 20): ("가난한 흥보 가족의 해학적인 대화(고전소설)", "고전소설(판소리계)", ["작자 미상, 「박흥보전」"]),
 ("2009-09", 24): ("영화의 리얼리즘 미학에 관한 바쟁의 영화관", "예술(영화)", []),
 ("2009-09", 28): ("이상 세계에 대한 동경과 삶의 성찰(현대시·고전시가)", "현대시·고전시가 복합", ["서정주, 「꽃밭의 독백-사소(娑蘇) 단장」", "신경림, 「나무를 위하여」", "안조원, 「만언사」"]),
 ("2009-09", 34): ("화행 이론에서 발화의 적절성 조건", "인문(언어학)", []),
 ("2009-09", 38): ("허구의 이리 떼로 유지되는 마을의 질서(희곡)", "희곡", ["이강백, 「파수꾼」"]),
 ("2009-09", 41): ("과거의 대기 성분과 기온 변화를 알려 주는 남극 빙하", "과학(지구과학)", []),
 ("2009-09", 44): ("여론 조사 결과 공표가 선거에 미치는 영향", "사회(정치·언론)", []),
 ("2009-09", 47): ("밀회 약속과 어머니 곁 사이에서 갈등하는 '그'(현대소설)", "현대소설", ["오상원, 「모반」"]),
 ("2009-11", 9): ("공공건물 벽화 그리기 축제 프로그램 제안서 초고", "작문(제안서)", []),
 ("2009-11", 13): ("옛 문헌의 문장 부호", "인문(국어학)", []),
 ("2009-11", 16): ("각 시대의 음악 양식에 적용된 반복의 양상", "예술(음악)", []),
 ("2009-11", 20): ("성벽의 돌을 맨손으로 옮기는 서씨를 목격한 '나'(현대소설)", "현대소설", ["김승옥, 「역사(力士)」"]),
 ("2009-11", 24): ("창조 도시의 근본 동력과 환경", "사회(도시)", []),
 ("2009-11", 28): ("이별한 임에 대한 그리움(현대시·고전시가)", "현대시·고전시가 복합", ["한용운, 「님의 침묵」", "김광규, 「나뭇잎 하나」", "작자 미상, 「춘면곡(春眠曲)」"]),
 ("2009-11", 34): ("공룡 발자국 화석 연구와 그 의미", "과학(지구과학)", []),
 ("2009-11", 37): ("철거민 가족의 삶(시나리오)", "시나리오", ["홍파 각색, 「난쟁이가 쏘아 올린 작은 공」"]),
 ("2009-11", 40): ("집단 수준의 인과: 필연성과 개연성", "인문(철학)", []),
 ("2009-11", 43): ("동영상 압축 기술의 원리", "기술(정보 통신)", []),
 ("2009-11", 47): ("박 처사의 청혼과 상공 집안의 혼인(고전소설)", "고전소설", ["작자 미상, 「박씨전」"]),
}
def genres(area, f):
    g = []
    if area == "문학":
        if "현대시" in f: g.append("현대시")
        if "현대소설" in f: g.append("현대소설")
        if "고전시가" in f: g.append("고전시가")
        if "고전소설" in f: g.append("고전소설")
        if "극" in f or "시나리오" in f or "희곡" in f: g.append("극·시나리오")
        if "수필" in f: g.append("수필")
    elif area == "독서":
        if f.startswith(("인문", "예술")): g.append("인문·예술")
        elif f.startswith("사회"): g.append("사회·문화")
        elif f.startswith(("과학", "기술")): g.append("과학·기술")
    return g
def reform(area, grp):
    if area == "독서": return "독서와 작문"
    if area == "문학": return "문학"
    if area == "언어와 매체": return "화법과 언어"
    return "화법과 언어" if grp.startswith("화법") else "독서와 작문"

FN = re.compile(r"\*\s?([^\s*:：][^*:：\n]{0,28}?)\s*[:：]\s*([^*\n]+?)(?=\s*\*\s?[^\s*:：][^*:：\n]{0,28}?\s*[:：]|\s*\n|\s*$)")
WORD_OK = re.compile(r"^[가-힣A-Za-z0-9◯ㄱ-ㅎ][^’‘“”\"]{0,20}$")

ITEMS = []; PAS = {}; CHO = {}; NOTES = {}; REPORT = Counter()
for ex, meta in EXAMS.items():
    sets, items = parse(P[meta.get("paras", ex)])
    tb = T.get(ex, {}).get("공통", {})
    setinfo = {s["range"]: s for s in sets}
    for it in items:
        n = it["num"]
        if n < meta["first"]: continue
        area = area_of(ex, n)
        rng = it["set"]
        r = f"{rng[0]}~{rng[1]}" if rng else "(독립 문항)"
        stem = pua(it["stem"])
        pts = 3 if "[3점]" in stem else 1 if "[1점]" in stem else 2
        rec = {"연도": meta["y"], "시행월": meta.get("mon", 11), "시행유형": meta.get("kind", "대학수학능력시험"), "명칭": meta["name"], "exam_id": ex,
               "문항번호": n, "영역": area, "지문범위": r, "발문": stem, "배점": pts,
               "정답": tb.get(str(n)), "보기": pua("\n".join(it["bogi"])).strip()}
        if meta["form"]: rec["형"] = meta["form"]
        if rng:
            lab = L.get((ex, rng[0]))
            rec["소재"], rec["분야"], rec["작품"] = lab if lab else ("(미분류)", "(미분류)", [])
            if not lab: REPORT["no label " + r] += 1
        else:
            rec["소재"], rec["분야"], rec["작품"] = "", "", []
        rec["작품"] = list(rec["작품"]); rec["갈래"] = genres(area, rec["분야"])
        ch = it["choices"]
        if len(ch) == 5:
            CHO[f"{ex}||{area}||{n}"] = [pua(ch[k]).strip() for k in range(1, 6)]
        else: REPORT["no choices"] += 1
        ITEMS.append(rec)
    for s in sets:
        a, b = s["range"]
        if a < meta["first"]: continue
        t = pua(passage_text(s["lines"]))
        if len(re.sub(r"\s", "", t)) < 150: REPORT["passage too short (image) " + ex + f" {a}~{b}"] += 1; continue
        PAS[f"{ex}||{area_of(ex, a)}||{a}~{b}"] = t

# 배점은 정답표(answer_keys_2009_2017.json)를 따른다
K = json.load(open("/mnt/user-data/outputs/answer_keys_2009_2017.json"))
for it in ITEMS:
    ak = K.get(it["exam_id"], {}).get(str(it["문항번호"]))
    if ak:
        if it["정답"] is None: it["정답"] = ak[0]
        assert it["정답"] == ak[0], (it["exam_id"], it["문항번호"])
        if it["배점"] != ak[1]: REPORT["배점 보정"] += 1; it["배점"] = ak[1]

# 낱말 풀이·지문 길이
LEN = {}
for k, v in PAS.items():
    notes = [[m.group(1).strip(), m.group(2).strip(), m.group(0)] for m in FN.finditer(v) if WORD_OK.match(m.group(1).strip()) and len(m.group(2)) <= 150]
    body = v
    for nt in notes: body = body.replace(nt[2], "")
    if notes: NOTES[k] = notes
    LEN[k] = len(body.strip())
for it in ITEMS:
    L_ = LEN.get(f'{it["exam_id"]}||{it["영역"]}||{it["지문범위"]}', 0)
    it["지문길이"] = L_ if L_ >= 100 else 0
print("items", len(ITEMS), "passages", len(PAS), "choices", len(CHO), "notes", sum(len(v) for v in NOTES.values()))
print(REPORT)
print(Counter((i["exam_id"], i["정답"] is not None) for i in ITEMS))
print("배점 합계", {ex: sum(i["배점"] for i in ITEMS if i["exam_id"] == ex) for ex in EXAMS})
json.dump({"items": ITEMS, "passages": PAS, "choices": CHO, "notes": NOTES}, open("/home/claude/hwp/new_bundle.json", "w"), ensure_ascii=False)
