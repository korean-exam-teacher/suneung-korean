
# ==================== map.py ====================
import json,re
d=json.load(open('ident.json'))
M={}
for n,v in d.items():
    h=re.sub(r'(.)\1\1',r'\1',v.get('head',''))
    m=re.search(r'(20\d\d)학년도',h)
    if not m or 'mun' in n: continue
    y=int(m.group(1))
    if y<2009: continue
    mo='06' if re.search(r'6월',h[:60]) else '09' if re.search(r'9월',h[:60]) else '11'
    form=re.search(r'([AB])\s*형',h[:80])
    ex=f"{y}-{mo}"+(f"-{form.group(1)}" if form and 2014<=y<=2016 else "")
    M.setdefault(ex,[]).append(n)
M.setdefault("2012-06?",[]).append("kor_hsj (3).pdf")
json.dump(M,open('map.json','w'),ensure_ascii=False,indent=0)
for k in sorted(M): print(k,M[k])

# ==================== dump.py ====================
import sys, json, pdfplumber, re
M = json.load(open("/home/claude/hsj/map.json"))
D = "/mnt/user-data/uploads/평가원 기출 문제 모음/"

def lines_page(pg, has_space):
    chars = list(pg.chars)
    if not chars: return [], 1
    mid = pg.width/2
    band = sum(1 for c in chars if mid-12 < (c["x0"]+c["x1"])/2 < mid+12 and c["text"].strip())
    two = band < 0.004*len(chars)
    cols = {"L": [], "R": []} if two else {"F": []}
    for c in chars:
        k = ("L" if c["x0"] < mid else "R") if two else "F"
        cols[k].append(c)
    out = []
    for side, cs in cols.items():
        cs = sorted(cs, key=lambda c: c["top"]); cl = []
        for c in cs:
            if cl and c["top"]-cl[-1][0] <= 4: cl[-1][1].append(c)
            else: cl.append([c["top"], [c]])
        for top, g in cl:
            g.sort(key=lambda c: c["x0"])
            gaps = sorted(b["x0"]-a["x1"] for a, b in zip(g, g[1:]) if a["text"] != " " and b["text"] != " ")
            med = gaps[len(gaps)//2] if gaps else 0
            t = ""; prev = None
            for c in g:
                if prev is not None and c["text"] != " " and not t.endswith(" "):
                    gap = c["x0"]-prev["x1"]
                    thr = med+0.3*c["size"] if has_space else max(1.0, med+0.15*c["size"])
                    if gap > thr: t += " "
                t += c["text"]; prev = c
            vis = [c for c in g if c["text"].strip()]
            if not vis: continue
            out.append({"t": re.sub(r" {2,}", " ", t).strip(), "endsp": (g[-1]["text"] == " ") if has_space else None,
                        "x0": round(vis[0]["x0"], 1), "x1": round(vis[-1]["x1"], 1), "top": round(top, 1), "side": side,
                        "size": round(vis[0]["size"], 1)})
    return out, 2 if two else 1

out = {}
for ex, files in sorted(M.items()):
    f = files[0]
    with pdfplumber.open(D+f) as pdf:
        sample = "".join(c["text"] for pg in pdf.pages[1:3] for c in pg.chars)
        hs = sample.count(" ")/max(len(sample), 1) > 0.08
        pages = []; ncol = []
        for pg in pdf.pages:
            L, nc = lines_page(pg.dedupe_chars(), hs); pages.append(L); ncol.append(nc)
    out[ex] = {"file": f, "has_space": hs, "pages": pages, "ncol": ncol, "width": 0}
    print(ex, f, hs, len(pages), "".join(map(str, ncol)), flush=True)
json.dump(out, open("/home/claude/hsj/hsj_lines.json", "w"), ensure_ascii=False)

# ==================== answers.py ====================
import json,re
from collections import defaultdict, Counter
H=json.load(open("hsj_lines.json"))
CIR="①②③④⑤"
ROW=re.compile(r"^[\s　\d\.①-⑤]+$")
PAIR=re.compile(r"(\d{1,2})\s*\.?\s*([①-⑤])")
def tables(ex):
    sec="공통"; res=defaultdict(dict); open_=True
    for pi,L in enumerate(H[ex]["pages"]):
        for l in L:
            t=l["t"]
            if "■" in t or re.match(r"^\[(공통|선택)",t):
                if "화법과 작문" in t: sec="화법과 작문"
                elif "언어와 매체" in t: sec="언어와 매체"
                elif "공통" in t: sec="공통"
                open_=True; continue
            if re.match(r"^\[\s*\d",t): open_=False
            if open_ and ROW.match(t) and PAIR.search(t):
                for n,a in PAIR.findall(t): res[sec][int(n)]=CIR.index(a)+1
    return res
s=open("/home/claude/site_v34.html",encoding="utf-8").read().split("\n")
ITEMS=json.loads([l for l in s if l.startswith("const ITEMS = ")][0][len("const ITEMS = "):].rstrip(";"))
by=defaultdict(dict)
for it in ITEMS:
    sec="공통" if it["exam_id"]>="2022" and it["영역"] in ("독서","문학") else (it["영역"] if it["exam_id"]>="2022" else "공통")
    by[it["exam_id"]][(sec,it["문항번호"])]=it
T={}
for ex in H:
    if "#" in ex: continue
    T[ex]=tables(ex)
    if ex+"#B" in H:
        tb=tables(ex+"#B")
        if "언어와 매체" in tb: T[ex]["언어와 매체"]=tb["언어와 매체"]
json.dump({ex:{sec:v for sec,v in t.items()} for ex,t in T.items()},open("answer_tables.json","w"),ensure_ascii=False)
report=[]
for ex,t in sorted(T.items()):
    exs=[ex] if ex!="2012-06?" else ["2012-06"]
    n=sum(len(v) for v in t.values())
    site=by.get(exs[0],{})
    agree=dis=fill=0; dl=[]
    for (sec,num),it in site.items():
        a=t.get(sec,{}).get(num)
        if a is None: continue
        if it["정답"] is None: fill+=1
        elif it["정답"]==a: agree+=1
        else: dis+=1; dl.append((num,it["영역"],it["정답"],a))
    print(ex, "table",n, {k:len(v) for k,v in t.items()}, "site",len(site),"agree",agree,"DIS",dis,"fillable",fill, dl[:6])

# ==================== explain.py ====================
import json,re
from collections import defaultdict
H=json.load(open("/home/claude/hsj/hsj_lines.json"))
CIR="①②③④⑤"
SETH=re.compile(r"^\[\s*(\d{1,2})\s*[~～\-–]\s*(\d{1,2})\s*\]\s*(.*)$")
ITEMH=re.compile(r"^(\d{1,2})\s*\.\s*(.*)$")
ROW=re.compile(r"^[\s　\d\.①-⑤]+$")
ANS=re.compile(r"(?:\[정답\]|정답|\[답\])\s*:?\s*([①-⑤])")
def join(lines):
    out=""
    for i,l in enumerate(lines):
        t=l["t"]
        if not out: out=t; continue
        p=lines[i-1]
        if re.match(r"^(\[오답피하기\]|정답해설|\[정답해설\]|지문해설|\[지문해설\]|\[보기\s*해설\])",t): out+="\n"+t; continue
        if p.get("endsp") is True or re.search(r"[.?!,:;)\]』」’”]$",p["t"]) or p.get("short"): out+=" "+t
        elif p.get("endsp") is False: out+=t
        else: out+=" "+t
    out = re.sub(r"\s?20\d\d학년도 대학수학능력시험[^.。]{0,40}?정답 및 해설(\s*\(홀수형\))?\s?", " ", out)
    return out.replace("\u3000"," ").replace("  "," ")
def parse(ex):
    pages=H[ex]["pages"]
    seq=[]
    for pi_, L in enumerate(pages):
        if not L: continue
        mxs={}
        for l in L: mxs[l["side"]]=max(mxs.get(l["side"],0),l["x1"])
        for j,l in enumerate(L):
            if re.fullmatch(r"-?\s*\d{1,2}\s*-?",l["t"]): continue   # 쪽 번호
            if pi_ > 0 and re.match(r"^20\d\d학년도 .{0,40}(정답 및 해설|해설)", l["t"]) and len(l["t"]) < 70: continue   # 쪽 머리글
            l=dict(l); l["short"]= l["x1"] < mxs[l["side"]]-25
            seq.append(l)
    sec="공통"; cur=None; items=[]; sets=[]; curset=None
    started=False
    for i,l in enumerate(seq):
        t=l["t"]
        if "■" in t and ("공통" in t or "선택" in t):
            sec="화법과 작문" if "화법과 작문" in t else "언어와 매체" if "언어와 매체" in t else "공통"; cur=None; continue
        if ROW.match(t): continue
        m=SETH.match(t)
        if m:
            a,b=int(m.group(1)),int(m.group(2))
            curset={"sec":sec,"range":(a,b),"head":m.group(3),"lines":[]}; sets.append(curset); cur=None; started=True; continue
        m=ITEMH.match(t)
        if m and started:
            n=int(m.group(1)); rest=m.group(2)
            nxt=seq[i+1]["t"] if i+1<len(seq) else ""
            looks = ("정답해설" in rest or "정답해설" in nxt or re.match(r"^\[?정답",nxt) or "[출제의도]" in nxt or "[출제 의도]" in nxt)
            inset = any(x["sec"]==sec and x["range"][0]<=n<=x["range"][1] for x in sets[-3:]) or (items and items[-1]["sec"]==sec and n==items[-1]["num"]+1)
            if looks and (inset or not curset):
                cur={"sec":sec,"num":n,"label":rest.strip(),"lines":[]}; items.append(cur); continue
        if cur is not None: cur["lines"].append(l)
        elif curset is not None: curset["lines"].append(l)
    res=[]
    for it in items:
        body=join(it["lines"])
        a=ANS.search(body)
        res.append({"sec":it["sec"],"num":it["num"],"label":it["label"],"ans":CIR.index(a.group(1))+1 if a else None,"text":body})
    st=[{"sec":s["sec"],"range":s["range"],"head":s["head"],"text":join(s["lines"])} for s in sets]
    return res,st
if __name__=="__main__":
    import sys
    r,s=parse(sys.argv[1])
    print(len(r),"items",[ (x["sec"][:2],x["num"]) for x in r])
    for x in r[:3]: print(x["num"],x["label"],x["ans"],"\n",x["text"][:500],"\n")
    print(s[0]["head"], s[0]["text"][:300])

# ==================== run_all.py ====================
import json,sys
sys.path.insert(0,"/home/claude/hsj")
from explain import parse, H
from collections import Counter
OUT={}
for ex in sorted(H):
    r,s=parse(ex); OUT[ex]={"items":r,"sets":s}
    c=Counter(x["sec"] for x in r)
    nums=[x["num"] for x in r if x["sec"]=="공통"]
    noans=sum(1 for x in r if x["ans"] is None)
    print(ex, dict(c), "noans",noans, "dup",len(nums)-len(set(nums)), "missing", sorted(set(range(min(nums or[1]),max(nums or[1])+1))-set(nums))[:12])
json.dump(OUT,open("/home/claude/hsj/explains.json","w"),ensure_ascii=False)

# ==================== integrate.py ====================
# -*- coding: utf-8 -*-
"""정답 및 해설(원자료)로 정답·유형·해설을 사이트 데이터에 반영한다.
입력: site_v34.html, explains.json, answer_tables.json  →  출력: integ.json"""
import json, re, sys
from collections import Counter, defaultdict
sys.path.insert(0, "/home/claude/typegroup")
import type_groups as TG

s = open("/home/claude/site_v34.html", encoding="utf-8").read().split("\n")
def load(n): return json.loads([l for l in s if l.startswith(f"const {n} = ")][0][len(f"const {n} = "):].rstrip(";"))
ITEMS = load("ITEMS"); PASSAGES = load("PASSAGES"); CHOICES = load("CHOICES")
E = json.load(open("/home/claude/hsj/explains.json"))
T = json.load(open("/home/claude/hsj/answer_tables.json"))

def hkey(ex): return "2012-06?" if ex == "2012-06" else ex
def sec_of(it):
    if it["exam_id"] >= "2022": return "공통" if it["영역"] in ("독서", "문학") else it["영역"]
    return "공통"
def src_for(it):
    k = hkey(it["exam_id"])
    if it["exam_id"] >= "2022" and it["영역"] == "언어와 매체": k += "#B"
    return E.get(k)

# ---------- 해설 유형 이름 → 유형 묶음 ----------
def has(t, *ws): return any(w in t for w in ws)
ALLOWED = {"독서": {"독서"}, "문학": {"문학"}, "화법과 작문": {"화법", "작문"}, "언어와 매체": {"문법", "매체"}}
def label_group(label, it):
    area = it["영역"]
    if label in TG.RAW_MAP and TG.GROUP_OF.get(TG.RAW_MAP[label]) in ALLOWED.get(area, set()):
        g = TG.RAW_MAP[label]
        # 화법과 작문 영역에서는 지문 분야(화법/작문)와 묶음이 어긋나면 키워드 규칙으로 다시 판정
        if area != "화법과 작문" or (TG.GROUP_OF[g] == "화법") == str(it.get("분야", "")).startswith("화법"):
            return g
    t = label
    if area == "독서":
        if has(t, "어휘", "단어의 의미", "바꿔 쓰", "바꾸어 쓰", "사전적 의미", "문맥적 의미"): return "어휘의 문맥적 의미"
        if has(t, "전개 방식", "서술 방식", "글의 구조", "전개 양상", "서술상"): return "글의 구조·전개 방식"
        if has(t, "관점", "견해", "입장"): return "견해·관점 비교"
        if has(t, "적용", "사례", "상황"): return "구체적 사례·상황 적용"
        if has(t, "비판", "평가", "타당", "반박", "비평"): return "비판적 이해·평가"
        if has(t, "관계", "인과", "상관", "비교", "대조"): return "정보 간의 관계 파악"
        if has(t, "추론", "미루어", "추리", "전제"): return "내용 추론"
        if has(t, "독서 방법", "읽기 방법", "독서 활동", "독서 과정", "읽기 과정", "독서의 방법"): return "독서 방법·활동"
        if has(t, "세부", "핵심", "중심", "정보", "일치", "내용 파악", "내용 이해", "내용 확인", "화제"): return "세부·핵심 내용 파악"
        return None
    if area == "문학":
        if has(t, "외적 준거", "외재적", "<보기>", "보기를"): return "외적 준거에 따른 감상"
        if has(t, "공통점", "차이점", "작품 간", "작품의 비교", "비교"): return "작품 간 비교"
        if has(t, "화자", "서술자", "어조", "정서"): return "화자·서술자의 태도·정서"
        if has(t, "인물", "심리", "성격"): return "인물의 심리·태도·성격"
        if has(t, "표현", "서술상", "서술 방식", "서술의 특징", "수사", "형식", "구성"): return "표현·서술상의 특징"
        if has(t, "시어", "시구", "구절", "어구", "단어의 의미", "의미 파악"): return "시어·시구·구절의 의미"
        if has(t, "소재", "배경", "기능", "역할", "공간"): return "소재·배경의 기능"
        if has(t, "주제", "작가", "의도"): return "주제 의식·작가의 관점"
        if has(t, "감상", "반응", "수용", "평가", "이해와 감상"): return "작품 감상·수용"
        if has(t, "내용", "상황", "사건", "종합적 이해", "이해", "줄거리"): return "작품 내용·상황 이해"
        return None
    if area == "화법과 작문":
        f = str(it.get("분야", ""))
        speech = f.startswith("화법") if (f.startswith("화법") or f.startswith("작문")) and not f.startswith("화법·작문") and not f.startswith("화법과 작문") else \
                 has(t + it["발문"], "말하기", "듣기", "화법", "토론", "토의", "발표", "대화", "면접", "협상", "강연", "연설", "청중", "발화", "담화")
        if speech:
            if has(t, "자료", "매체"): return "화법: 자료·매체 활용"
            if has(t, "계획", "내용 생성", "조직", "구성"): return "화법: 내용 생성·조직"
            if has(t, "전략", "방식", "표현", "태도"): return "화법: 말하기 방식·표현 전략"
            return "화법: 내용 이해·평가"
        if has(t, "고쳐", "퇴고", "수정", "점검", "비문", "어휘 선택", "문장 다듬"): return "작문: 점검·고쳐쓰기"
        if has(t, "자료"): return "작문: 자료·매체 활용"
        if has(t, "계획", "맥락", "독자", "목적"): return "작문: 계획·맥락 반영"
        if has(t, "표현", "조건", "전략", "제목", "글쓰기"): return "작문: 표현 전략"
        if has(t, "내용 생성", "개요", "조직", "내용", "생성"): return "작문: 내용 생성·조직"
        return None
    if area == "언어와 매체":
        if has(t, "매체"):
            if has(t, "표현"): return "매체 언어의 표현 방법"
            if has(t, "수용", "제작", "생산"): return "매체 자료의 수용·제작"
            return "매체의 특성·정보 구성"
        if has(t, "음운", "발음", "음절", "자음", "모음"): return "음운·음운 변동"
        if has(t, "중세", "국어사", "변천", "옛", "고대", "근대 국어", "훈민정음"): return "중세 국어·국어의 변천"
        if has(t, "맞춤법", "표준어", "표기", "로마자", "외래어", "띄어쓰기", "사이시옷", "어문 규범"): return "한글 맞춤법·표준어 규정"
        if has(t, "형태소", "단어 형성", "단어의 형성", "파생", "합성", "조어", "단어의 구조"): return "형태소·단어 형성"
        if has(t, "높임", "시제", "시간 표현", "피동", "사동", "부정 표현", "문법 요소", "인용", "종결 표현"): return "문법 요소"
        if has(t, "문장 성분", "문장의 짜임", "안은", "이어진", "홑문장", "겹문장", "서술어", "자릿수", "문장 구조", "문장의 구조"): return "문장 성분·문장의 짜임"
        if has(t, "품사", "용언", "활용", "어미", "조사", "체언"): return "품사·용언의 활용"
        if has(t, "의미 관계", "어휘", "다의어", "동음이의어", "반의어", "유의어", "사전", "단어의 의미"): return "어휘와 의미"
        if has(t, "담화", "지시 표현"): return "담화의 특성"
        return None
    return None

# 역량: 같은 유형 묶음 문항에 절반 이상 붙은 역량
gs = defaultdict(Counter); gn = Counter()
for it in ITEMS:
    if it["exam_id"] >= "2022":
        gn[it["유형묶음"]] += 1
        for sk in it.get("역량", []): gs[it["유형묶음"]][sk] += 1
SKILL_OF = {g: [sk for sk, c in gs[g].most_common() if c >= gn[g]*0.5] for g in gn}

stat = Counter(); changes = []; EXPLAIN = {}; LABELMISS = Counter()
for it in ITEMS:
    ex = it["exam_id"]; key = f'{ex}||{it["영역"]}||{it["문항번호"]}'
    sec = sec_of(it)
    # 1) 정답
    tb = T.get(hkey(ex), {}).get(sec, {})
    a = tb.get(str(it["문항번호"]))
    if a:
        if it["정답"] is None: it["정답"] = a; stat["answer filled"] += 1; changes.append((key, None, a))
        elif it["정답"] != a: changes.append((key, it["정답"], a)); it["정답"] = a; stat["answer corrected"] += 1
        else: stat["answer same"] += 1
        it["_정답출처"] = "정답및해설(원자료)"
    else:
        stat["answer no table"] += 1
    # 2) 해설
    src = src_for(it)
    hit = None
    if src:
        cands = [x for x in src["items"] if x["num"] == it["문항번호"] and x["sec"] == sec]
        if len(cands) == 1: hit = cands[0]
    if not hit: stat["no explanation"] += 1; continue
    if hit["ans"] and a and hit["ans"] != a: stat["explain-answer conflict"] += 1
    txt = hit["text"].strip()
    if len(txt) >= 40: EXPLAIN[key] = txt; stat["explanation"] += 1
    # 3) 유형 (2009~2021학년도만: 2022~는 이미 원자료로 확인됨)
    if ex < "2022" and hit["label"] and len(hit["label"]) <= 60:
        lab = re.sub(r"\s+", " ", hit["label"]).strip(" .")
        g = label_group(lab, it)
        it["유형_해설확인"] = lab
        if g:
            old = it["유형묶음"]
            it["유형"] = lab; it["유형묶음"] = g; it["유형갈래"] = TG.GROUP_OF.get(g, it["유형갈래"])
            it["_유형출처"] = "정답및해설(원자료)"
            it.pop("_유형재분류", None); it.pop("_ebs_매칭", None); it.pop("유형_EBS", None)
            if old != g:
                stat["group changed"] += 1
                it["역량"] = SKILL_OF.get(g, it.get("역량", []))
            stat["type verified"] += 1
        else:
            LABELMISS[(it["영역"], lab)] += 1; stat["label unmapped"] += 1

# 2018~2021학년도: 공식 해설 유형 이름을 못 얻은 문항은 EBS 대조 결과도 믿기 어려우므로 '유형 확인' 표시를 뗀다
for it in ITEMS:
    if "2018" <= it["exam_id"] < "2022" and it.get("_유형출처") != "정답및해설(원자료)":
        if it.get("_유형출처") or it.get("_ebs_매칭"):
            it["_유형재분류"] = True; stat["2018-21 ebs type unverified"] += 1

# 지문 해설
PEXPLAIN = {}
area_of = {}
for it in ITEMS: area_of[(it["exam_id"], sec_of(it), it["문항번호"])] = it["영역"]
for ex in sorted({i["exam_id"] for i in ITEMS}):
    for k in [hkey(ex), hkey(ex) + "#B"]:
        if k not in E: continue
        for st in E[k]["sets"]:
            if "지문해설" not in st["text"][:20]: continue
            a, b = st["range"]
            area = area_of.get((ex, st["sec"], a))
            if not area: continue
            pk = f"{ex}||{area}||{a}~{b}"
            if pk in PASSAGES and pk not in PEXPLAIN:
                PEXPLAIN[pk] = st["text"].strip()
print(stat); print("passage explanations", len(PEXPLAIN))
print("unmapped labels", len(LABELMISS)); print(LABELMISS.most_common(40))
json.dump({"items": ITEMS, "explain": EXPLAIN, "pexplain": PEXPLAIN, "changes": changes}, open("/home/claude/hsj/integ.json", "w"), ensure_ascii=False)

# ==================== merge_v35.py ====================
# -*- coding: utf-8 -*-
"""site_v34 + hsj/integ.json(정답·유형·해설) → site_v35.html, explain.json"""
import json, re
SRC = "/home/claude/site_v34.html"; DST = "/home/claude/site_v35.html"
D = json.load(open("/home/claude/hsj/integ.json", encoding="utf-8"))
lines = open(SRC, encoding="utf-8").read().split("\n")
def idx(n): return [k for k, l in enumerate(lines) if l.startswith(f"const {n} = ")][0]
items = D["items"]
for it in items:
    if f'{it["exam_id"]}||{it["영역"]}||{it["문항번호"]}' in D["explain"]: it["_h"] = 1
lines[idx("ITEMS")] = "const ITEMS = " + json.dumps(items, ensure_ascii=False) + ";"
pk = sorted(D["pexplain"].keys())
lines.insert(idx("PASSAGE_NOTES") + 1, "const PASSAGE_EXPLAIN_KEYS = new Set(" + json.dumps(pk, ensure_ascii=False) + ");")
s = "\n".join(lines)
json.dump({"i": D["explain"], "p": D["pexplain"]}, open("/home/claude/explain.json", "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))

def rep(old, new, cnt=1):
    global s
    assert s.count(old) == cnt, (s.count(old), old[:90])
    s = s.replace(old, new)

# ---- 문항 상세: 해설 보기 ----
rep("""      ${withJump ? `<button type="button" class="btn-line goto-exam" data-exam="${escapeHtml(it.exam_id)}" data-key="${escapeHtml(itemKey(it))}">지문과 함께 보기 →</button>` : ''}
    </div>
  `;
}""", """      ${it._h ? `<button type="button" class="btn-plain do-explain" data-key="${escapeHtml(itemKey(it))}" aria-expanded="false">해설 보기</button>` : ''}
      ${withJump ? `<button type="button" class="btn-line goto-exam" data-exam="${escapeHtml(it.exam_id)}" data-key="${escapeHtml(itemKey(it))}">지문과 함께 보기 →</button>` : ''}
    </div>
    ${it._h ? `<div class="explain" hidden></div>` : ''}
  `;
}

/* ---------- 해설(정답 및 해설 원자료) : 처음 열 때 explain.json을 한 번만 받아 온다 ---------- */
let explainData = null, explainLoading = null;
function loadExplain(){
  if(explainData) return Promise.resolve(explainData);
  if(!explainLoading){
    explainLoading = fetch('explain.json').then(r=>{ if(!r.ok) throw new Error(r.status); return r.json(); })
      .then(d=>{ explainData = d; return d; })
      .catch(err=>{ explainLoading = null; throw err; });
  }
  return explainLoading;
}
function explainHtml(text){
  return text.split(/\\n+/).map(p=>{
    let h = escapeHtml(p.trim());
    h = h.replace(/^\\[?(정답 ?해설|지문 ?해설|보기 ?해설)\\]?\\s*:?\\s*/, (m,a)=>`<b class="ex-h">${a.replace(' ','')}</b> `)
         .replace(/^\\[(오답 ?피하기)\\]\\s*/, '<b class="ex-h">오답 피하기</b> ');
    return `<p>${h}</p>`;
  }).join('');
}
async function toggleExplain(btn, kind){
  const box = kind==='p' ? btn.closest('.pg-body').querySelector('.explain') : btn.closest('.detail').querySelector('.explain');
  if(!box) return;
  const open = box.hidden;
  btn.setAttribute('aria-expanded', String(open));
  if(!open){ box.hidden = true; btn.textContent = kind==='p' ? '지문 해설 보기' : '해설 보기'; return; }
  box.hidden = false; btn.textContent = kind==='p' ? '지문 해설 닫기' : '해설 닫기';
  if(box.dataset.done) return;
  box.innerHTML = '<p class="ex-wait">해설을 불러오는 중입니다…</p>';
  try{
    const d = await loadExplain();
    const t = (kind==='p' ? d.p : d.i)[btn.dataset.key];
    const it = kind==='p' ? null : itemByKey(btn.dataset.key);
    box.innerHTML = t ? `<div class="ex-src">${kind==='p'?'지문 해설':'문항 해설'} · 해당 회차 「정답 및 해설」 원문${it && it.유형_해설확인 ? ` · 해설 유형: ${escapeHtml(it.유형_해설확인)}` : ''}</div>${explainHtml(t)}` : '<p class="ex-wait">이 문항의 해설은 아직 없습니다.</p>';
    box.dataset.done = '1';
  }catch(err){
    box.innerHTML = '<p class="ex-wait">해설을 불러오지 못했습니다. 잠시 뒤 다시 눌러 주세요.</p>';
  }
}
document.addEventListener('click', e=>{
  const b = e.target.closest('.do-explain'); if(b){ toggleExplain(b, 'i'); return; }
  const p = e.target.closest('.do-pexplain'); if(p){ toggleExplain(p, 'p'); }
});""")

# ---- 지문 해설 버튼 ----
rep("""  const notesHtml = notes.length ? `<div class="notes"><b>낱말 풀이</b><dl>${notes.map(n=>`<dt>${escapeHtml(n[0])}</dt><dd>${escapeHtml(n[1])}</dd>`).join('')}</dl></div>` : '';
  return body + notesHtml;""", """  const notesHtml = notes.length ? `<div class="notes"><b>낱말 풀이</b><dl>${notes.map(n=>`<dt>${escapeHtml(n[0])}</dt><dd>${escapeHtml(n[1])}</dd>`).join('')}</dl></div>` : '';
  const pkey = `${examId}||${g.영역}||${g.지문범위}`;
  const pex = PASSAGE_EXPLAIN_KEYS.has(pkey) ? `<div class="pex-bar"><button type="button" class="btn-plain do-pexplain" data-key="${escapeHtml(pkey)}" aria-expanded="false">지문 해설 보기</button></div><div class="explain" hidden></div>` : '';
  return body + notesHtml + pex;""")

# ---- CSS ----
rep(".notes{margin-top:10px;", """.explain{margin-top:12px;border:1px solid var(--line);border-left:3px solid var(--brand);background:var(--bg-sub);padding:12px 16px;font-size:calc(14px * var(--rs));line-height:1.8}
.explain p{margin:0 0 6px}
.explain .ex-h{color:var(--brand);margin-right:4px}
.explain .ex-src{font-size:12px;color:var(--text-faint);margin-bottom:6px}
.explain .ex-wait{color:var(--text-sub)}
.pex-bar{margin-top:10px}
.notes{margin-top:10px;""")

# ---- 정답 출처 안내 ----
rep("""  'EBS 기출의 미래(2023학년도판)': 'EBS 「2023학년도 수능 기출의 미래」 해설(2018~2021학년도 기출 수록)과 대조해 확인한 유형입니다. 이 회차들은 별도 공식 정답표가 없어 정답도 이 자료의 매칭 결과에 의존합니다.',""",
    """  'EBS 기출의 미래(2023학년도판)': 'EBS 「2023학년도 수능 기출의 미래」 해설(2018~2021학년도 기출 수록)과 대조해 확인한 유형입니다.',""")

# ---- 이용 안내 ----
def sub_between(start, end, new):
    global s
    i = s.index(start); j = s.index(end, i)
    s = s[:i] + new + s[j:]
rep("정답은 확보한 정답표로 1,440문항에 반영했고, 2014학년도 예비 시행 90문항은 정답표를 구하지 못해 정답이 없습니다.",
    "정답은 확보한 정답표로 1,440문항에 반영했고, 해당 회차 「정답 및 해설」의 정답표와도 모두 일치함을 확인했습니다(2012학년도 9월, 2013학년도 6월·9월은 해설 파일의 정답표 글자가 그림이라 대조하지 못했습니다). 2014학년도 예비 시행 90문항은 정답표를 구하지 못해 정답이 없습니다.")
sub_between("2018~2021학년도(12개 회차, 540문항)는 별도로 구할 수 있는 공식 정답표가 없어", "</p>",
    "2018~2021학년도(12개 회차, 540문항)는 해당 회차 「정답 및 해설」에 실린 정답표로 정답을 반영했습니다. 예전에는 공식 정답표를 구하지 못해 EBS 「2023학년도 수능 기출의 미래」 해설과 지문·발문을 대조해 정답을 붙였는데(443문항), 「정답 및 해설」 정답표와 맞춰 보니 그중 150문항이 틀려 있어 모두 바로잡았고, 비어 있던 97문항도 채웠습니다. 2022~2027학년도 952문항의 정답도 같은 정답표와 모두 일치합니다. 배점은 문제지에 인쇄된 값을 그대로 반영했습니다.")
sub_between("<p>2018~2027학년도 문항은 공식·사설 해설 자료와 대조해 유형을 검증했습니다", "</p>",
    "<p>문항마다 해당 회차 「정답 및 해설」에 적힌 유형 이름을 확인해 유형 묶음을 정했습니다(\"유형 확인\" 표시, 전체 3,022문항 중 2,593문항). 2009~2017학년도는 1,530문항 중 1,273문항, 2018~2021학년도는 540문항 중 438문항을 「정답 및 해설」로 확인했습니다. 2018~2021학년도는 예전에 EBS 「기출의 미래」와 대조해 붙였던 유형을 「정답 및 해설」 유형으로 바꾸었고, 「정답 및 해설」로 확인하지 못한 문항(2018학년도 6월·수능 등 해설 파일의 글자가 그림이라 읽을 수 없는 회차)은 EBS 대조 결과도 믿기 어려워 확인 표시를 뺐습니다. 2022~2027학년도는 공식 「정답 및 해설」(728문항), EBS 「기출의 미래」(99문항), 사설 학원(바탕국어연구소) 해설지(55문항)와 대조했습니다. 해설 자료에 적힌 원래 유형 이름은 문항을 펼치면 \"해설 표기\"로 함께 보이고, 확인 표시가 없는 문항은 발문 패턴에 따른 자동 분류입니다.")
rep("""        <summary>2009~2017학년도 기출 정리 방법</summary>""", """        <summary>해설 보기</summary>
        <p>문항을 펼쳐 "해설 보기"를 누르면 해당 회차 「정답 및 해설」의 문항 해설(정답 해설·오답 피하기)을 원문 그대로 보여 줍니다. 회차 화면에서는 지문 아래 "지문 해설 보기"로 지문 해설도 볼 수 있습니다. 해설에는 정답이 나오므로 먼저 풀어 본 뒤 여는 것이 좋습니다. 2009~2027학년도 문항 중 2,678문항에 해설이 있습니다. 해설 파일의 글자가 그림이라 읽을 수 없는 회차(2012학년도·2017학년도·2018학년도 수능, 2018학년도 6월), 해설 파일이 없는 회차(2023학년도 9월, 2014학년도 예비 시행)와 일부 문항은 해설이 없습니다. 해설은 처음 누를 때 한 번 내려받으므로 잠깐 걸릴 수 있습니다.</p>
      </details>
      <details>
        <summary>2009~2017학년도 기출 정리 방법</summary>""")

open(DST, "w", encoding="utf-8").write(s)
print("ok", len(s.encode()) / 1e6, "MB; explain.json", len(open("/home/claude/explain.json", "rb").read()) / 1e6, "MB")
