#!/usr/bin/env python3
"""Version 45: 원본 그림(제시 자료·선택지·지문 속 그림·매체 화면)을 site_v40.html에 얹어 site_v41.html을 만든다.
먼저 merge_v40.py로 site_v40.html을 다시 만든 뒤 실행한다. 그림 파일은 fig/ 아래(fig/fig_index.json의 f 경로)."""
import json, re, sys, subprocess
subprocess.run([sys.executable, '/home/claude/merge_v40.py'], check=True)
SRC, OUT = '/home/claude/site_v40.html', '/home/claude/site_v41.html'
s = open(SRC, encoding='utf-8').read()
FIGS = json.load(open('/home/claude/fig/fig_index.json', encoding='utf-8'))
css = open('/home/claude/v41/figs.css', encoding='utf-8').read()
js = open('/home/claude/v41/figs.js', encoding='utf-8').read()

def rep(old, new, count=1):
    global s
    n = s.count(old)
    if n != count: sys.exit(f'patch miss ({n} != {count}): {old[:80]!r}')
    s = s.replace(old, new)

# 1) 글자만 있는 <보기> 두 개는 원본을 보고 글자로 옮긴다(그림 대신 글자)
TEXT_BOGI = {
    ('2016-09-B', '문학', 36): '<보 기> 사랑이 이루어진 상황을 사랑의 결실이라고 부르는 것은, 사랑을 이루기 위해 지극한 노력이 필요하기 때문이다. 사랑하기로 마음먹는 것만으로 사랑의 결실을 얻을 수는 없다. 사랑하는 대상에게 지속적으로 관심을 쏟아야 하고, 그 대상을 빼앗으려 하거나 위협하는 것들에 맞서야 한다. 이는 연인은 물론 다른 대상을 향한 사랑에서도 마찬가지이다.',
    ('2016-09-B', '문학', 38): '<보 기> ｢보리｣에서 글쓴이는 파종된 보리가 자라는 과정을 인간의 삶에 접목하여 그 인격적 속성을 제시함으로써 보리의 모습에서 알 수 있는 다양한 가치를 드러내고 있다.',
}
m = re.search(r'^const ITEMS = (\[.*\]);$', s, re.M)
items = json.loads(m.group(1)); done = 0
for it in items:
    k = (it['exam_id'], it['영역'], it['문항번호'])
    if k in TEXT_BOGI:
        assert not (it.get('보기') or '').strip(); it['보기'] = TEXT_BOGI[k]; done += 1
assert done == 2
s = s[:m.start(1)] + json.dumps(items, ensure_ascii=False) + s[m.end(1):]

# 1-0) 2028 예시문항 화법과 언어 6번 <보기>: 원본 캡처·원본 문제지 PDF를 보고 글자로 옮김(그림은 fig/m06.png, USB '국어의 모든 것'의 PDF에서 잘라 냄)
BOGI_2028_6 = """<보 기> [자료 1] 후문 계단 안전사고 실태 파악을 위해 정리한 표
사고 발생 일시(연번 · 날짜 · 시간) / 해당 일 일출 / 해당 일 일몰
1 · 12.03. · 20:40 / 07:30 / 17:19
2 · 12.11. · 21:10 / 07:38 / 17:18
3 · 12.23. · 18:30 / 07:47 / 17:14
4 · 12.27. · 07:25 / 07:44 / 17:21
[자료 2] 인터넷에서 ‘조명’을 검색하여 정리한 메모
- 가로등: 통행 및 보행 안전을 위해 길가를 따라 설치.
- 센서등: 움직임을 감지하여 자동으로 켜짐. 상시 조명이 필요 없는 곳에 설치.
- 잔디등: 상가 거리, 광장 주변 녹지에 설치. 야간 보행 안전 및 미관을 위해 설치.
[자료 3] 조명과 관련된 정보를 검색하다가 읽게 된 신문 기사
○○시에 따르면, 지난해에 빛 공해 관련 민원이 모두 227건 접수됐다. 특히 A 아파트에 대한 민원이 지속적으로 제기되고 있다. 인근 주민 B 씨는 “A 아파트의 외부 조명으로 인해 저녁부터 새벽까지 내내 집 안이 환해서 너무 힘듭니다.”라며 “A 아파트가 준공되고 나서 지금까지 조명이 꺼진 적이 단 한 번도 없습니다.”라고 말했다."""
m3 = re.search(r'^const ITEMS_2028 = (\[.*\]);$', s, re.M)
I28 = json.loads(m3.group(1))
for it in I28:
    if it['문항번호'] == 6 and it['영역'] == '화법과 언어':
        assert not (it.get('보기') or '').strip(); it['보기'] = BOGI_2028_6
s = s[:m3.start(1)] + json.dumps(I28, ensure_ascii=False) + s[m3.end(1):]
# 1-1) 2012학년도 6월 화법과 작문 8~9번은 따로 된 지문 없이 세트 머리말만 있다(원문 그대로)
m2 = re.search(r'^const PASSAGES = (\{.*\});$', s, re.M)
P = json.loads(m2.group(1)); k = '2012-06||화법과 작문||8~9'
if not P.get(k): P[k] = '‘우유 팩 재활용 활성화’에 대해 글을 쓰려고 한다.'
s = s[:m2.start(1)] + json.dumps(P, ensure_ascii=False) + s[m2.end(1):]
# 2) 그림 목록
rep('\nfunction escapeHtml(s){', '\nconst FIGS = ' + json.dumps(FIGS, ensure_ascii=False, separators=(',', ':')) + ';\nfunction escapeHtml(s){')
# 3) 문항 화면
rep("    ${it.보기 ? `<div class=\"bogi\"><div class=\"bogi-label\">제시 자료</div><div class=\"bogi-text\">${escapeHtml(it.보기)}</div></div>` : ''}",
    "    ${figBogiHtml(it)}")
rep("  const ch = (it.exam_id === '2028-예시' ? CHOICES_2028 : CHOICES)[key];",
    "  const ch = (it.exam_id === '2028-예시' ? CHOICES_2028 : CHOICES)[key] || figChoices(it);")
# 4) 지문 화면
rep("  if(!t) return '<span class=\"na\">이 지문은 원문이 수록되어 있지 않습니다.</span>';",
    "  if(!t){ const pf0 = figP(examId, g.영역, g.지문범위); return pf0 ? figPassageHtml(pf0, '') : '<span class=\"na\">이 지문은 원문이 수록되어 있지 않습니다.</span>'; }")
rep("  return body + notesHtml + pex;\n}",
    "  const pf = figP(examId, g.영역, g.지문범위);\n  if(pf) return figPassageHtml(pf, body + notesHtml) + pex;\n  return body + notesHtml + pex;\n}")
# 5) CSS · JS
rep('@media (prefers-reduced-motion: reduce)', css + '\n@media (prefers-reduced-motion: reduce)')
rep('/* 좁은 화면에서는 검색 조건을 접어 둔다 */', js + '\n/* 좁은 화면에서는 검색 조건을 접어 둔다 */')
# 6) 이용 안내
rep('2028학년도 개편 예시문항 45문항 중 14문항에서 확보했습니다', '2028학년도 개편 예시문항 45문항 중 18문항에서 확보했습니다(6·20·28·30번은 원본 문제지에서 잘라 낸 그림)')
ni = len(FIGS['i']); npg = len(FIGS['p'])
rep('나머지 8문항은 선택지가 그래프·도식 그림이라 "선택지 정보를 표시할 수 없습니다"로 표시됩니다.',
    '나머지 8문항은 선택지가 그래프·도식 그림이라 원본 문제지에서 잘라 낸 그림으로 보여 주고, 번호만 골라 채점할 수 있게 했습니다.')
rep('선택지나 제시 자료(&lt;보기&gt; 등)가 그림·표인 문항, 원본에서 그림(화면)으로 된 매체 지문, 지문 속 [그림]은 인쇄본에 "원본 문제지를 확인하세요"라고 적어 두고 담은 문제 목록에도 표시합니다.',
    '그림·표·화면이 들어 있는 제시 자료와 지문은 원본 문제지에서 잘라 낸 그림 그대로 인쇄됩니다(이 부분은 고른 글꼴로 바뀌지 않습니다). 원본 그림을 구하지 못한 문항은 인쇄본에 "원본 문제지를 확인하세요"라고 적어 두고 담은 문제 목록에도 표시합니다.')
GUIDE = f'''      <details>
        <summary>원본 그림(제시 자료·지문 속 그림·매체 화면)</summary>
        <p>그래프·도식·표·사진·만화·매체 화면처럼 글자로 옮길 수 없는 부분은 원본 문제지(PDF)에서 그 자리를 잘라 낸 그림으로 보여 줍니다. 문항 {ni}개의 제시 자료(&lt;보기&gt;·&lt;자료&gt;·&lt;학습 활동&gt; 등, 이 중 10문항은 그림으로 된 선택지까지)와 지문 {npg}개(그림이 든 독서·화법과 작문 지문, 화면으로 된 언어와 매체 지문)가 해당합니다. 그림 아래 "글자로 보기"를 누르면 원본에서 뽑아 둔 글자만 볼 수 있습니다(검색은 늘 이 글자로 합니다). 그림은 글자를 새로 짓지 않고 원본을 그대로 잘라 낸 것이며, 글꼴 크기 단추로는 커지지 않습니다. 2028학년도 예시문항은 원본 문제지 PDF에서 화법과 언어 6번, 독서와 작문 20·28·30번의 자료를 잘라 넣었습니다.</p>
      </details>
    </div>
    <div class="foot-copy">'''
rep('''      </details>
    </div>
    <div class="foot-copy">''', '\n'.join(['      </details>', GUIDE.split('      <details>', 1)[0] + '      <details>' + GUIDE.split('      <details>', 1)[1]]) if False else '      </details>\n' + GUIDE)
open(OUT, 'w', encoding='utf-8').write(s)
print('ok', len(s), 'items with fig', ni, 'passages with fig', npg)
