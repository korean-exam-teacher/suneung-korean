# -*- coding: utf-8 -*-
"""한글이 텍스트로 추출되지 않는 해설 PDF 고치기.
원인: 본문 글꼴이 사용자 정의 인코딩 CMap(WinCharSetFFFF)을 쓰고, ToUnicode가 없거나(2018) 코드 기준이 어긋나(2012) 추출기가 글자를 잃는다.
방법: (1) 글꼴 인코딩을 Identity-H로 바꾸고 본문 문자열의 코드를 CID로 다시 쓴다.
      (2) CID→유니코드 표(ToUnicode)를 새로 만든다.
         - 기존 ToUnicode가 있으면(코드 기준) 그대로 CID 기준으로 옮긴다.
         - 없으면 같은 글꼴 파일을 공유하는 다른 글꼴의 ToUnicode(GID 기준)와,
           함초롬바탕 계열의 한글 글리프 배열(GID = 기준값 + (코드포인트 - U+AC00))로 채운다.
           기준값은 같은 글꼴을 공유하는 글꼴의 ToUnicode에서 확인하거나, 지정한 값으로 둔다."""
import pikepdf, re, sys, json
from collections import Counter

def parse_enc_cmap(data):
    m = {}; txt = data.decode("latin-1")
    for blk in re.findall(r"begincidrange(.*?)endcidrange", txt, re.S):
        for a, b, c in re.findall(r"<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>\s*(\d+)", blk):
            a, b, c = int(a, 16), int(b, 16), int(c)
            for k in range(a, b+1): m[k] = c + (k - a)
    for blk in re.findall(r"begincidchar(.*?)endcidchar", txt, re.S):
        for a, c in re.findall(r"<([0-9a-fA-F]+)>\s*(\d+)", blk): m[int(a, 16)] = int(c)
    return m

def tounicode(stream):
    t = stream.read_bytes().decode("latin-1"); m = {}
    for blk in re.findall(r"beginbfchar(.*?)endbfchar", t, re.S):
        for a, b in re.findall(r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", blk):
            try: m[int(a, 16)] = bytes.fromhex(b).decode("utf-16-be")
            except Exception: pass
    for blk in re.findall(r"beginbfrange(.*?)endbfrange", t, re.S):
        for a, b, c in re.findall(r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", blk):
            a, b = int(a, 16), int(b, 16); base = int(c, 16)
            for k in range(a, b+1): m[k] = chr(base + k - a)
    return m

def c2g_of(d):
    m = d.get("/CIDToGIDMap")
    if m is None or isinstance(m, pikepdf.Name): return None
    raw = m.read_bytes(); return [int.from_bytes(raw[i:i+2], "big") for i in range(0, len(raw), 2)]

def make_tounicode(pdf, cid2u):
    lines = ["/CIDInit /ProcSet findresource begin", "12 dict begin", "begincmap",
             "/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def",
             "/CMapName /Fixed-UCS def", "/CMapType 2 def", "1 begincodespacerange", "<0000> <FFFF>", "endcodespacerange"]
    items = sorted(cid2u.items())
    for i in range(0, len(items), 100):
        chunk = items[i:i+100]
        lines.append(f"{len(chunk)} beginbfchar")
        for c, u in chunk: lines.append(f"<{c:04X}> <{u.encode('utf-16-be', 'surrogatepass').hex().upper()}>")
        lines.append("endbfchar")
    lines += ["endcmap", "CMapName currentdict /CMap defineresource pop", "end", "end"]
    return pdf.make_stream("\n".join(lines).encode())

def fix(src, dst, hangul_base=None):
    pdf = pikepdf.open(src)
    # 1) 글꼴 파일(Descendant)별 GID→유니코드 단서 모으기
    gid_u = {}      # descendant objgen -> {gid: u}
    for page in pdf.pages:
        for name, f in page.Resources.get("/Font", {}).items():
            if f.get("/Subtype") != "/Type0" or "/ToUnicode" not in f: continue
            d = f.DescendantFonts[0]; c2g = c2g_of(d); tu = tounicode(f.ToUnicode)
            enc = f.Encoding
            code2cid = parse_enc_cmap(enc.read_bytes()) if isinstance(enc, pikepdf.Stream) else None
            for code, u in tu.items():
                cid = code2cid.get(code) if code2cid is not None else code
                if cid is None: continue
                g = c2g[cid] if c2g and cid < len(c2g) else cid
                gid_u.setdefault(d.FontDescriptor.objgen, {})[g] = u
    # 한글 글리프 기준값 확인(같은 글꼴의 한글 단서에서)
    bases = {}
    for k, m in gid_u.items():
        offs = Counter(g - (ord(u) - 0xAC00) for g, u in m.items() if len(u) == 1 and "가" <= u <= "힣")
        if offs: bases[k] = offs.most_common(1)[0][0]
    report = []
    # 2) 사용자 정의 인코딩 글꼴 고치기
    fixed = {}
    for page in pdf.pages:
        fonts = page.Resources.get("/Font", {})
        targets = {}
        for name, f in fonts.items():
            if f.get("/Subtype") != "/Type0": continue
            key = f.objgen
            enc = f.Encoding
            if key in fixed: targets[str(name)] = fixed[key]; continue
            if not isinstance(enc, pikepdf.Stream): continue
            if key not in fixed:
                code2cid = parse_enc_cmap(enc.read_bytes())
                d = f.DescendantFonts[0]; c2g = c2g_of(d); fd = d.FontDescriptor.objgen
                base = bases.get(fd, hangul_base)
                known = gid_u.get(fd, {})
                own = tounicode(f.ToUnicode) if "/ToUnicode" in f else {}
                cid2u = {}
                for code, cid in code2cid.items():
                    u = own.get(code)
                    if u is None:
                        g = c2g[cid] if c2g and cid < len(c2g) else cid
                        u = known.get(g)
                        if u is None and base is not None and 0 <= g - base < 11172: u = chr(0xAC00 + g - base)
                    if u: cid2u[cid] = u
                f.Encoding = pikepdf.Name("/Identity-H")
                f.ToUnicode = make_tounicode(pdf, cid2u)
                fixed[key] = code2cid
                report.append((str(name), len(code2cid), len(cid2u), base))
            targets[str(name)] = fixed[key]
        if not targets: continue
        # 3) 본문 문자열을 코드→CID로 다시 쓰기
        ops = pikepdf.parse_content_stream(page)
        cur = None; out = []
        def conv(b, m):
            r = bytearray()
            for i in range(0, len(b) - 1, 2):
                c = int.from_bytes(b[i:i+2], "big"); cid = m.get(c, 0)
                r += cid.to_bytes(2, "big")
            return pikepdf.String(bytes(r))
        for operands, op in ops:
            o = str(op)
            if o == "Tf": cur = str(operands[0])
            elif cur in targets and o in ("Tj", "'", '"'):
                operands = list(operands); operands[-1] = conv(bytes(operands[-1]), targets[cur])
            elif cur in targets and o == "TJ":
                arr = pikepdf.Array([conv(bytes(x), targets[cur]) if isinstance(x, pikepdf.String) else x for x in operands[0]])
                operands = [arr]
            out.append((operands, op))
        page.Contents = pdf.make_stream(pikepdf.unparse_content_stream(out))
    pdf.save(dst)
    return report, bases

if __name__ == "__main__":
    rep, bases = fix(sys.argv[1], sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else None)
    print(rep); print({str(k): v for k, v in bases.items()})
