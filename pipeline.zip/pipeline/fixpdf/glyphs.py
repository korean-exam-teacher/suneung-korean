import pikepdf, re, sys
from collections import Counter
sys.path.insert(0,"/home/claude/fixpdf")
from fix import parse_enc_cmap

def tokens(data):
    i=0; n=len(data)
    while i<n:
        c=data[i:i+1]
        if c in b" \t\r\n\x00\x0c": i+=1; continue
        if c==b"%":
            while i<n and data[i:i+1] not in b"\r\n": i+=1
            continue
        if c==b"(":
            depth=1; i+=1; out=bytearray()
            while i<n and depth:
                ch=data[i]
                if ch==0x5c:
                    nx=data[i+1:i+2]
                    if nx in b"nrtbf": out+= {b"n":b"\n",b"r":b"\r",b"t":b"\t",b"b":b"\b",b"f":b"\f"}[nx]; i+=2
                    elif nx.isdigit():
                        j=i+1; oct_=b""
                        while j<n and len(oct_)<3 and data[j:j+1].isdigit(): oct_+=data[j:j+1]; j+=1
                        out.append(int(oct_,8)&0xff); i=j
                    elif nx in b"\r\n": i+=2
                    else: out+=nx; i+=2
                    continue
                if ch==0x28: depth+=1
                elif ch==0x29:
                    depth-=1
                    if depth==0: i+=1; break
                out.append(ch); i+=1
            yield ("str",bytes(out)); continue
        if c==b"<" and data[i+1:i+2]!=b"<":
            j=data.index(b">",i); yield ("str",bytes.fromhex(data[i+1:j].decode().replace(" ","").replace("\n","")) ); i=j+1; continue
        if c in b"[]": yield ("op",c.decode()); i+=1; continue
        if c==b"<" : yield ("op","<<"); i+=2; continue
        if c==b">" : yield ("op",">>"); i+=2; continue
        j=i
        while j<n and data[j:j+1] not in b" \t\r\n()<>[]/%" : j+=1
        if c==b"/":
            j=i+1
            while j<n and data[j:j+1] not in b" \t\r\n()<>[]/%" : j+=1
            yield ("name",data[i:j].decode("latin-1")); i=j; continue
        tok=data[i:j].decode("latin-1"); i=j
        if tok=="BI":
            k=data.index(b"EI",i); i=k+2; continue
        yield ("tok",tok)

def glyph_runs(pdf, fontkey_filter=None):
    """페이지별로 (폰트이름, CID 목록) 순서대로 돌려준다(줄 정보 없이)."""
    for pno,page in enumerate(pdf.pages):
        fonts=page.Resources.get("/Font",{})
        data=b"".join(c.read_bytes() for c in (page.Contents if isinstance(page.Contents,pikepdf.Array) else [page.Contents]))
        stack=[]; cur=None
        for kind,val in tokens(data):
            if kind=="tok" and val=="Tf": cur=stack[-2] if len(stack)>=2 else cur; stack=[]; continue
            if kind=="tok" and val in ("Tj","'","\""):
                s=[x for x in stack if isinstance(x,bytes)]
                if s: yield pno,cur,s[-1]
                stack=[]; continue
            if kind=="tok" and val=="TJ":
                for x in stack:
                    if isinstance(x,bytes): yield pno,cur,x
                stack=[]; continue
            if kind=="str": stack.append(val)
            elif kind=="name": stack.append(val)
            elif kind=="op" and val in "[]": pass
            elif kind=="tok":
                if val in ("BT","ET","q","Q","cm","Tm","Td","TD","T*","gs","re","W","n","m","l","S","f","h","w","G","g","rg","RG","k","K","cs","CS","sc","scn","Do","Tc","Tw","Tz","TL","Ts","Tr","BI","ID","EI"): stack=[] if val not in ("Tc","Tw","Tz","TL","Ts","Tr") else stack[:-1]
                else: stack.append(val)
