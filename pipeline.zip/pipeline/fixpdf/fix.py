"""ToUnicode가 없는 CID 글꼴에 내장 TrueType의 cmap으로 ToUnicode를 만들어 넣는다."""
import pikepdf, io, re, sys
from fontTools.ttLib import TTFont

def parse_enc_cmap(data):
    """인코딩 CMap: code -> CID (cidrange / cidchar)"""
    m = {}
    txt = data.decode("latin-1")
    for blk in re.findall(r"begincidrange(.*?)endcidrange", txt, re.S):
        for a, b, c in re.findall(r"<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>\s*(\d+)", blk):
            a, b, c = int(a, 16), int(b, 16), int(c)
            for k in range(a, b+1): m[k] = c + (k - a)
    for blk in re.findall(r"begincidchar(.*?)endcidchar", txt, re.S):
        for a, c in re.findall(r"<([0-9a-fA-F]+)>\s*(\d+)", blk): m[int(a, 16)] = int(c)
    return m

def fix(src, dst):
    pdf = pikepdf.open(src)
    done = {}; stat = []
    for page in pdf.pages:
        fonts = page.Resources.get("/Font", {})
        for name, f in fonts.items():
            if f.get("/Subtype") != "/Type0" or "/ToUnicode" in f: continue
            key = f.objgen
            if key in done: continue
            d = f.DescendantFonts[0]
            ff = d.FontDescriptor.get("/FontFile2")
            if ff is None: continue
            tt = TTFont(io.BytesIO(ff.read_bytes()), fontNumber=0)
            gid_uni = {}
            if "cmap" in tt:
                best = tt.getBestCmap() or {}
                order = tt.getGlyphOrder()
                for u, gname in best.items():
                    gid = tt.getGlyphID(gname)
                    gid_uni.setdefault(gid, u)
            # CID -> GID
            c2g = None
            m = d.get("/CIDToGIDMap")
            if m is not None and not isinstance(m, pikepdf.Name):
                raw = m.read_bytes(); c2g = [int.from_bytes(raw[i:i+2], "big") for i in range(0, len(raw), 2)]
            enc = f.Encoding
            code2cid = parse_enc_cmap(enc.read_bytes()) if isinstance(enc, pikepdf.Stream) else None
            entries = []
            codes = code2cid.items() if code2cid else [(c, c) for c in range(0, 65536)]
            for code, cid in codes:
                gid = c2g[cid] if (c2g and cid < len(c2g)) else cid
                u = gid_uni.get(gid)
                if u: entries.append((code, u))
            lines = ["/CIDInit /ProcSet findresource begin", "12 dict begin", "begincmap",
                     "/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def",
                     "/CMapName /Fix-UCS def", "/CMapType 2 def", "1 begincodespacerange", "<0000> <FFFF>", "endcodespacerange"]
            for i in range(0, len(entries), 100):
                chunk = entries[i:i+100]
                lines.append(f"{len(chunk)} beginbfchar")
                for code, u in chunk:
                    lines.append(f"<{code:04X}> <{u.encode('utf-16-be').hex().upper() if isinstance(u,str) else chr(u).encode('utf-16-be').hex().upper()}>")
                lines.append("endbfchar")
            lines += ["endcmap", "CMapName currentdict /CMap defineresource pop", "end", "end"]
            f.ToUnicode = pdf.make_stream("\n".join(lines).encode())
            done[key] = len(entries); stat.append((str(name), len(entries), len(gid_uni)))
    pdf.save(dst)
    return stat
if __name__ == "__main__":
    print(fix(sys.argv[1], sys.argv[2]))
