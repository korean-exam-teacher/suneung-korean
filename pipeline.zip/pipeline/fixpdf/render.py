import numpy as np
from PIL import Image, ImageDraw
from fontTools.pens.basePen import BasePen

class PolyPen(BasePen):
    def __init__(self, glyphSet):
        super().__init__(glyphSet); self.polys = []; self.cur = []
    def _moveTo(self, p): self.cur = [p]
    def _lineTo(self, p): self.cur.append(p)
    def _curveToOne(self, p1, p2, p3):
        p0 = self.cur[-1]
        for t in np.linspace(0, 1, 8)[1:]:
            x = (1-t)**3*p0[0] + 3*(1-t)**2*t*p1[0] + 3*(1-t)*t**2*p2[0] + t**3*p3[0]
            y = (1-t)**3*p0[1] + 3*(1-t)**2*t*p1[1] + 3*(1-t)*t**2*p2[1] + t**3*p3[1]
            self.cur.append((x, y))
    def _qCurveToOne(self, p1, p2):
        p0 = self.cur[-1]
        for t in np.linspace(0, 1, 6)[1:]:
            x = (1-t)**2*p0[0] + 2*(1-t)*t*p1[0] + t**2*p2[0]
            y = (1-t)**2*p0[1] + 2*(1-t)*t*p1[1] + t**2*p2[1]
            self.cur.append((x, y))
    def _closePath(self):
        if len(self.cur) > 2: self.polys.append(self.cur)
        self.cur = []
    _endPath = _closePath

class GlyfSet:
    def __init__(self, glyf): self.glyf = glyf
    def __getitem__(self, name):
        g = self.glyf[name]; glyf = self.glyf
        class W:
            def draw(self_, pen): g.draw(pen, glyf)
        return W()

def raster(glyphset, name, upm, asc, desc, size=40, adv=None, glyf=None):
    if glyf is not None: glyphset = GlyfSet(glyf)
    pen = PolyPen(glyphset); glyphset[name].draw(pen)
    H = asc - desc
    W = adv if adv else upm
    acc = np.zeros((size, size), dtype=np.uint8)
    for poly in pen.polys:
        im = Image.new("L", (size, size), 0); d = ImageDraw.Draw(im)
        pts = [((x / W) * size, ((asc - y) / H) * size) for x, y in poly]
        d.polygon(pts, fill=1)
        acc ^= np.array(im, dtype=np.uint8)
    return acc.astype(np.float32)
