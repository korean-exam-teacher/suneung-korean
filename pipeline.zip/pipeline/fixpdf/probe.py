import pikepdf, re, sys
if __name__!="__main__": pdf=None
else: pdf=pikepdf.open(sys.argv[1])
def tounicode(stream):
    t=stream.read_bytes().decode('latin-1'); m={}
    for blk in re.findall(r"beginbfchar(.*?)endbfchar",t,re.S):
        for a,b in re.findall(r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>",blk): m[int(a,16)]=bytes.fromhex(b).decode('utf-16-be','replace')
    for blk in re.findall(r"beginbfrange(.*?)endbfrange",t,re.S):
        for a,b,c in re.findall(r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>",blk):
            a,b=int(a,16),int(b,16); base=int(c,16)
            for k in range(a,b+1): m[k]=chr(base+k-a)
    return m
def c2g_of(d):
    m=d.get('/CIDToGIDMap')
    if m is None or isinstance(m,pikepdf.Name): return None
    raw=m.read_bytes(); return [int.from_bytes(raw[i:i+2],'big') for i in range(0,len(raw),2)]
if __name__=='__main__':
    fonts={}
    for pg in pdf.pages:
        for name,f in pg.Resources.Font.items():
            if f.get('/Subtype')!='/Type0': continue
            fonts[(str(name),f.objgen)]=f
    pairs={}
    for (name,og),f in fonts.items():
        d=f.DescendantFonts[0]; c2g=c2g_of(d)
        print(name, og, d.objgen, '/ToUnicode' in f, str(f.Encoding)[:20], None if c2g is None else len(c2g), repr(bytes(d.FontDescriptor.FontName.unparse()))[:20])
        if '/ToUnicode' in f and str(f.Encoding)=='/Identity-H':
            tu=tounicode(f.ToUnicode)
            for code,u in tu.items():
                g = c2g[code] if c2g and code<len(c2g) else code
                pairs.setdefault(bytes(d.FontDescriptor.FontName.unparse()),{})[g]=u
    for fn,p in pairs.items():
        hang=sorted((g,u) for g,u in p.items() if len(u)==1 and '가'<=u<='힣')
        offs=sorted(set(g-ord(u) for g,u in hang))
        print(fn[:30], len(p), "hangul",len(hang), hang[:8], "offsets",offs[:8], len(offs))
    