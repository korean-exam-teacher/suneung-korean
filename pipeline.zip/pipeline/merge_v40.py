#!/usr/bin/env python3
"""Version 43: '문제 담기' · 모아 풀기 · 16쪽 시험지 인쇄 기능을 site_v39.html 위에 얹어 site_v40.html을 만든다."""
import sys
SRC, OUT = '/home/claude/site_v39.html', '/home/claude/site_v40.html'
s = open(SRC, encoding='utf-8').read()
css = open('/home/claude/v40/basket.css', encoding='utf-8').read()
js = open('/home/claude/v40/basket.js', encoding='utf-8').read()

def rep(old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        sys.exit(f'patch miss ({n} != {count}): {old[:80]!r}')
    s = s.replace(old, new)

# CSS
rep('@media (prefers-reduced-motion: reduce)', css + '\n@media (prefers-reduced-motion: reduce)')
# GNB
rep('<button class="gnb-link" type="button" id="nbLink">오답 노트<span class="gnb-count" id="nbCount"></span></button>',
    '<button class="gnb-link" type="button" id="nbLink">오답 노트<span class="gnb-count" id="nbCount"></span></button>\n'
    '      <button class="gnb-link" type="button" id="bkLink">담은 문제<span class="gnb-count bk" id="bkCount"></span></button>')
# 섹션 · 인쇄 영역 · 알림
rep('<section id="notebook" hidden></section>', '<section id="notebook" hidden></section>\n    <section id="basket" hidden></section>')
rep('#exams,#results,#examView{scroll-margin-top:80px}', '#exams,#results,#examView,#notebook,#basket{scroll-margin-top:80px}')
rep('\n<script>\nconst ITEMS = ', '\n<div class="bk-toast" id="bkToast" role="status" hidden><span></span><button type="button">담은 문제 보기</button></div>\n<div id="printArea" aria-hidden="true"></div>\n\n<script>\nconst ITEMS = ')
# 이용 안내
GUIDE = '''      <details>
        <summary>문제 담기 · 모아 풀기 · 시험지 인쇄</summary>
        <p>문항을 펼쳐 "＋ 문제 담기"를 누르면 위 메뉴의 "담은 문제"에 모입니다. 회차 화면에서는 지문마다 "이 지문 문항 모두 담기"로 한 지문의 문항을 한꺼번에 담을 수 있습니다. 같은 지문의 문항은 하나로 묶여 지문이 한 번만 나오고, 번호는 담은 순서대로 1번부터 새로 매깁니다. 묶음 순서는 ↑·↓로 바꾸거나 "영역 순으로 정리"(독서 → 문학 → 화법과 작문 → 언어와 매체)로 한 번에 정리할 수 있습니다. "모아 풀기"는 담은 문제를 시험처럼 이어서 풀고 "한꺼번에 채점하기"로 점수와 풀이 시간을 보여 주며, 결과는 오답 노트에도 기록됩니다.</p>
        <p>"시험지로 인쇄하기"는 담은 문제를 국어 시험지처럼 2단으로 짜서 16쪽 안에 넣습니다. 글자 크기 "자동 맞춤"은 10.5pt부터 8.5pt까지 줄여 가며 16쪽 안에 들어가는 가장 큰 글자를 고릅니다. 16쪽을 넘으면 인쇄 단추가 꺼지고, 몇 문항쯤 빼야 하는지 알려 줍니다. 쪽수는 이 화면의 글꼴로 실제로 쪽을 나눠 본 값이라 "미리 보기"로 쪽마다 모양을 확인할 수 있습니다. 인쇄 창에서는 배율을 기본값(100%)으로 두고 머리글·바닥글을 끄세요. 정답표는 문제 쪽수와 따로 맨 뒤에 붙습니다. 글꼴은 기본 웹 글꼴(Noto Serif KR) 말고도 이 컴퓨터에 설치된 글꼴(신명 중명조, HY신명조, 함초롬바탕, 바탕 또는 직접 입력한 이름)을 고를 수 있습니다. 글꼴 파일을 사이트에 싣는 것이 아니라 보는 컴퓨터에 있는 글꼴을 빌려 쓰는 방식이라, 그 글꼴이 없는 컴퓨터에서는 기본 글꼴로 짜입니다. 지문 앞의 지시문은 모두 "다음 글을 읽고 물음에 답하시오."로 통일했으므로 원래 문제지의 지시문과 다를 수 있고, 선택지나 제시 자료(&lt;보기&gt; 등)가 그림·표인 문항, 원본에서 그림(화면)으로 된 매체 지문, 지문 속 [그림]은 인쇄본에 "원본 문제지를 확인하세요"라고 적어 두고 담은 문제 목록에도 표시합니다. 담은 문제 목록은 풀이 기록처럼 지금 쓰는 기기의 이 브라우저에만 저장됩니다.</p>
      </details>
    </div>
    <div class="foot-copy">'''
rep('''    </div>
    <div class="foot-copy">''', GUIDE)
# state
rep("point:'', notebook:false,\n};", "point:'', notebook:false, basket:false,\n};")
# detailHtml
rep('function detailHtml(it, withJump){', 'function detailHtml(it, withJump, num){')
rep('<div class="d-stem">${escapeHtml(it.발문)}</div>',
    '<div class="d-stem">${escapeHtml(num ? String(it.발문).replace(/^\\s*\\d+\\s*\\.\\s*/, num+\'. \') : it.발문)}</div>')
rep('''    <div class="d-actions">
      <button type="button" class="btn-plain goto-similar"''',
    '''    <div class="d-actions">
      <button type="button" class="btn-plain do-basket ${inBasket(itemKey(it))?'on':''}" data-key="${escapeHtml(itemKey(it))}" aria-pressed="${inBasket(itemKey(it))}">${bkBtnLabel(inBasket(itemKey(it)))}</button>
      <button type="button" class="btn-plain goto-similar"''')
rep('detail.innerHTML = detailHtml(it, !!detail.id);', 'detail.innerHTML = detailHtml(it, !!detail.id, Number(detail.dataset.num)||0);')
# 목록 행 표시
rep("${passageHit?'<span class=\"hit\">지문에서 일치</span>':''}</span>",
    "${passageHit?'<span class=\"hit\">지문에서 일치</span>':''}<span class=\"bk-mark\" ${inBasket(itemKey(it))?'':'hidden'}>담음</span></span>")
# render()
rep('''  const inExam = state.examView && state.exam && !state.notebook;
  examsSec.hidden = !!inExam || state.notebook;
  resultsSec.hidden = !!inExam || state.notebook;''',
    '''  const inExam = state.examView && state.exam && !state.notebook && !state.basket;
  examsSec.hidden = !!inExam || state.notebook || state.basket;
  resultsSec.hidden = !!inExam || state.notebook || state.basket;''')
rep('  notebookSec.hidden = !state.notebook;\n', '  notebookSec.hidden = !state.notebook;\n  basketSec.hidden = !state.basket;\n  updateBkCount();\n')
rep('  if(state.notebook){ renderNotebook(); return; }', '  if(state.basket){ renderBasket(); return; }\n  stopBkTimer();\n  if(state.notebook){ renderNotebook(); return; }')
# 메뉴 전환
rep("x.dataset.mode===mode && !state.notebook));", "x.dataset.mode===mode && !state.notebook && !state.basket));")
rep('''  if(e.target.closest('#nbLink')){
    state.notebook = true; state.examView = false;''',
    '''  if(e.target.closest('#bkLink')){ openBasket(); return; }
  if(e.target.closest('#nbLink')){
    state.notebook = true; state.examView = false; state.basket = false;''')
rep("if(state.mode === b.dataset.mode && !state.examView && !state.notebook) return;",
    "if(state.mode === b.dataset.mode && !state.examView && !state.notebook && !state.basket) return;")
rep('state.notebook = false;', 'state.notebook = false; state.basket = false;', 3)
rep("document.getElementById('nbLink').classList.remove('active');",
    "document.getElementById('nbLink').classList.remove('active'); document.getElementById('bkLink').classList.remove('active');", 2)
# 회차 화면: 지문별 '모두 담기'
rep("          ${g.작품.length ? `<span class=\"pg-works\">${escapeHtml(g.작품.join(' / '))}</span>` : ''}\n        </div>",
    "          ${g.작품.length ? `<span class=\"pg-works\">${escapeHtml(g.작품.join(' / '))}</span>` : ''}\n"
    "          <button type=\"button\" class=\"btn-plain bk-group ${g.items.every(it=>inBasket(itemKey(it)))?'on':''}\" data-keys=\"${g.items.map(it=>encodeURIComponent(itemKey(it))).join(',')}\">${bkGroupLabel(g.items.map(itemKey))}</button>\n"
    "        </div>")
# 모듈
rep('/* 좁은 화면에서는 검색 조건을 접어 둔다 */', js + '\n/* 좁은 화면에서는 검색 조건을 접어 둔다 */')
open(OUT, 'w', encoding='utf-8').write(s)
print('ok', len(s))
