# -*- coding: utf-8 -*-
"""site_v33.html + old/old_bundle.json(2009~2017학년도) → site_v34.html"""
import json, re
SRC = "/home/claude/site_v33.html"; DST = "/home/claude/site_v34.html"
lines = open(SRC, encoding="utf-8").read().split("\n")
def idx(n): return [k for k, l in enumerate(lines) if l.startswith(f"const {n} = ")][0]
def load(n): return json.loads(lines[idx(n)][len(f"const {n} = "):].rstrip(";"))
def save(n, v): lines[idx(n)] = f"const {n} = " + json.dumps(v, ensure_ascii=False) + ";"

B = json.load(open("/home/claude/old/old_bundle.json", encoding="utf-8"))
ITEMS = load("ITEMS"); PASSAGES = load("PASSAGES"); CHOICES = load("CHOICES"); NOTES = load("PASSAGE_NOTES")
assert not any(i["exam_id"] in {x["exam_id"] for x in B["items"]} for i in ITEMS)
for k in B["passages"]: assert k not in PASSAGES
ITEMS += B["items"]; PASSAGES.update(B["passages"]); CHOICES.update(B["choices"]); NOTES.update(B["notes"])
save("ITEMS", ITEMS); save("PASSAGES", PASSAGES); save("CHOICES", CHOICES); save("PASSAGE_NOTES", NOTES)
s = "\n".join(lines)
# 한글 문서 글꼴의 사용자 정의 영역 겹낫표 → 『 』
s = s.replace("\U000f0854", "『").replace("\U000f0855", "』")

def rep(old, new, cnt=1):
    global s
    assert s.count(old) == cnt, (s.count(old), old[:80])
    s = s.replace(old, new)

# ---- 회차 표기·정렬 ----
rep("""function examShort(it){
  if(it.exam_id === '2028-예시') return {code:'2028', kind:'예시문항'};
  const [y,m] = it.exam_id.split('-');
  return {code:`${y}.${m}`, kind: it.시행유형==='대학수학능력시험' ? '수능' : `${Number(m)}월 모평`};
}""", """function examShort(it){
  if(it.exam_id === '2028-예시') return {code:'2028', kind:'예시문항'};
  const [y,m,f] = it.exam_id.split('-');
  const form = f ? ` ${f}형` : '';
  if(m === '예비') return {code:`${y}`, kind:`예비 시행${form}`};
  return {code:`${y}.${m}`, kind: (it.시행유형==='대학수학능력시험' ? '수능' : `${Number(m)}월 모평`) + form};
}
/* 회차 순서 값: 학년도 → 예비 시행 → 6월 → 9월 → 수능 (큰 값이 최신). 같은 회차에서는 A형 값이 더 커서 최신순 목록에서 A형이 먼저 나온다. */
function examRank(id){
  const [y,m,f] = String(id).split('-');
  const mm = m === '예비' ? 0 : (Number(m) || 0);
  return Number(y)*1000 + mm*10 + (f === 'A' ? 2 : f === 'B' ? 1 : 0);   // 최신순 정렬에서 A형이 B형보다 먼저 오도록
}""")
rep("const exams = [...new Set(items.map(i=>i.exam_id))].sort().reverse();",
    "const exams = [...new Set(items.map(i=>i.exam_id))].sort((a,b)=>examRank(b)-examRank(a));")
rep("    b.exam_id.localeCompare(a.exam_id) ||", "    examRank(b.exam_id) - examRank(a.exam_id) ||")
rep("// 최신 회차부터(학년도 내림차순, 같은 학년도는 수능→9월→6월), 회차 안에서는 문항 번호 순.",
    "// 최신 회차부터(학년도 내림차순, 같은 학년도는 수능→9월→6월→예비 시행, 같은 회차는 A형→B형), 회차 안에서는 문항 번호 순.")

# ---- 회차별 표 ----
old_tbl = s[s.index("  const byYear = {};\n  items.forEach(i=>{ (byYear[i.연도] ??= {})[i.시행월] = i; });"):s.index("examTableWrap.addEventListener('click'")]
new_tbl = """  // byYear[학년도][6|9|11|'pre'] = [exam_id, …] (A형·B형이 있으면 두 개)
  const byYear = {};
  items.forEach(i=>{
    const m = i.exam_id.split('-')[1];
    const col = m === '예비' ? 'pre' : Number(m);
    const arr = ((byYear[i.연도] ??= {})[col] ??= []);
    if(!arr.includes(i.exam_id)) arr.push(i.exam_id);
  });
  Object.values(byYear).forEach(o=>Object.values(o).forEach(a=>a.sort((x,y)=>examRank(y)-examRank(x))));   // A형 → B형
  const years = Object.keys(byYear).sort((a,b)=>b-a);
  const shown = state.allYears ? years : years.slice(0,5);
  const LABEL = {6:'6월 모의평가', 9:'9월 모의평가', 11:'수능', pre:'예비 시행'};
  const btns = (y, col, ids)=> ids.map(id=>{
    const f = id.split('-')[2];
    const name = `${y}학년도 ${LABEL[col]}${f ? ` ${f}형` : ''}`;
    return f
      ? `<button type="button" class="ylink form" data-exam="${id}" aria-label="${name} 보기">${f}형<span class="n">${countBy[id]}</span></button>`
      : `<button type="button" class="ylink" data-exam="${id}" aria-label="${name} 보기">${countBy[id]}문항 보기</button>`;
  }).join('');
  const cell = (y,m)=>{
    const ids = byYear[y][m];
    if(ids) return `<td>${btns(y, m, ids)}</td>`;
    const miss = MISSING_EXAMS[`${y}-${m}`];
    if(miss) return `<td><span class="y-miss" title="${escapeHtml(miss)}">미수록</span></td>`;
    return `<td><span class="y-none">–</span></td>`;
  };
  const rows = shown.map(y=>{
    let h = `<tr><td>${y}학년도</td>${cell(y,6)}${cell(y,9)}${cell(y,11)}</tr>`;
    if(byYear[y].pre) h += `<tr class="pre-row"><td>${y}학년도 <small>예비 시행</small></td><td colspan="3" class="pre-cell">${btns(y,'pre',byYear[y].pre)}<span class="pre-note">수준별 국어 도입 전 ${Number(y)-2}년에 시행</span></td></tr>`;
    return h;
  }).join('');
  examTableWrap.innerHTML = `
    <table class="year-table">
      <thead><tr><th>학년도</th><th>6월 모의평가</th><th>9월 모의평가</th><th>대학수학능력시험</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
    ${years.length>5 ? `<button type="button" class="more-years" id="moreYears">${state.allYears ? '최근 5개 학년도만 보기 ▴' : `이전 학년도 펼치기 (${years[years.length-1]}~${years[5]}) ▾`}</button>` : ''}
    ${state.allYears ? `<p class="table-note">2014~2016학년도는 수준별 시험(A형·B형)으로 두 유형이 따로 출제되어 각각 수록했습니다. 미수록 회차는 원본 문제지가 스캔 이미지뿐이라 글자를 옮기지 못한 회차입니다.</p>` : ''}`;
}
const MISSING_EXAMS = {
  '2009-9': '2009학년도 9월 모의평가: 확보한 문제지가 스캔 이미지뿐이라 아직 싣지 못했습니다.',
  '2009-11': '2009학년도 수능: 확보한 문제지가 스캔 이미지뿐이라 아직 싣지 못했습니다.',
  '2014-11': '2014학년도 수능(A형·B형): 확보한 문제지가 스캔 이미지뿐이라 아직 싣지 못했습니다.',
};
"""
s = s.replace(old_tbl, new_tbl)

# ---- 이용 안내 ----
def sub_between(start, end, new):
    global s
    i = s.index(start); j = s.index(end, i)
    s = s[:i] + new + s[j:]
sub_between("<p>2018~2027학년도 6월·9월 모의평가와 11월 수능 국어영역 기출(총 29개 회차", "</p>",
  "<p>2009~2027학년도 평가원 6월·9월 모의평가와 11월 대학수학능력시험 국어(언어) 영역 기출, 그리고 2014학년도 수준별 국어 예비 시행까지 모두 63개 회차 3,022문항을 지문 소재와 문항 유형으로 찾아볼 수 있게 정리했습니다. 시험 체제는 시기마다 다릅니다 — 2009~2013학년도는 언어 영역(1~5번 듣기 문항은 싣지 않고 6~50번 45문항만 수록), 2014~2016학년도는 수준별 국어 A형·B형(두 유형을 각각 수록), 2017~2021학년도는 화법·작문·문법·독서·문학 45문항 체제, 2022학년도부터는 공통 과목(독서·문학)과 선택 과목(화법과 작문·언어와 매체) 체제입니다. 문법 문항은 시기와 상관없이 \"언어와 매체\" 영역으로 묶어 두었습니다. \"회차별 기출문제\" 표에서 회차를 누르면 그 회차 문항을 지문별로 묶어서 볼 수 있습니다. \"개편 매핑\" 표시는 2028학년도 개편 예시문항 안내자료집 분석을 바탕으로 각 문항이 개편 후 신설 과목 중 어디에 해당할지 참고용으로 붙인 것으로, 문항 자체가 2028학년도 개편 형식이라는 뜻은 아닙니다.")
rep("<p>2018~2021학년도 6월·9월 평가원 모의평가·11월 대학수학능력시험(화법·작문·문법 고정 순서 체제)",
    "<p><b>2009~2017학년도</b>(34개 회차, 1,530문항): 2009학년도 6월, 2010~2013학년도 6월·9월·수능, 2014학년도 6월·9월(A·B형)과 예비 시행(A·B형), 2015·2016학년도 6월·9월·수능(A·B형), 2017학년도 6월·9월·수능. 2009학년도 9월·수능과 2014학년도 수능은 확보한 문제지가 스캔 이미지뿐이라 아직 싣지 못했습니다(표에 \"미수록\"으로 표시). 정답은 확보한 정답표로 1,440문항에 반영했고, 2014학년도 예비 시행 90문항은 정답표를 구하지 못해 정답이 없습니다.</p>\n        <p><b>2018~2027학년도</b>: 2018~2021학년도 6월·9월 평가원 모의평가·11월 대학수학능력시험(화법·작문·문법 고정 순서 체제)")
rep("<p>소재·분야 태그는 지문을 직접 읽고 붙인 것이고,",
    "<p>소재·분야 태그는 지문을 직접 읽고 붙인 것입니다(2009~2017학년도 지문의 태그는 이번에 새로 붙인 초안이라 아직 검토 중입니다). ")
rep("<p>공식·사설 해설 자료와 대조해 유형을 검증했습니다(총 1,120/1,492, 약 75%).",
    "<p>2018~2027학년도 문항은 공식·사설 해설 자료와 대조해 유형을 검증했습니다(총 1,120/1,492, 약 75%). 2009~2017학년도 1,530문항은 아직 해설 자료와 대조하지 않아 모두 발문 패턴에 따른 자동 분류이며 \"유형 확인\" 표시가 없습니다.")
rep("전체 1,537문항 중 1,497문항(약 97%)에 역량 태그가 붙어 있으며, 나머지 40문항은 유형 자체가 \"미분류(수동 확인 필요)\"로 남아 있어 태그를 붙일 근거가 없는 문항입니다.",
    "2018~2027학년도와 2028 예시문항 1,537문항 중 1,497문항(약 97%)에 역량 태그가 붙어 있으며, 나머지 40문항은 유형 자체가 \"미분류(수동 확인 필요)\"로 남아 있어 태그를 붙일 근거가 없는 문항입니다. 2009~2017학년도 문항은 같은 유형 묶음의 문항에 절반 이상 함께 붙은 역량을 옮겨 붙였습니다(1,530문항 중 1,216문항). 그래서 역량이 고르게 갈리는 묶음의 문항에는 역량 태그가 없습니다.")
rep("<summary>제시 자료(&lt;보기&gt;·&lt;자료&gt;·&lt;학습 활동&gt; 등)</summary>",
    """<summary>2009~2017학년도 기출 정리 방법</summary>
        <p>지문·발문·선택지·&lt;보기&gt;는 문제지 PDF에서 글자 단위로 다시 뽑았습니다. PDF에는 줄이 낱말 경계에서 바뀌었는지(줄 끝 공백) 기록이 남아 있어, 이를 읽어 줄 바뀜 자리의 띄어쓰기를 되살렸습니다. 다만 2010학년도 6월·9월 모의평가 문제지는 이 기록이 없어 다른 기출 지문에서 익힌 띄어쓰기 규칙으로 추정했습니다. 그래서 이 두 회차에는 줄 바뀜 자리의 띄어쓰기가 틀린 곳이 조금 있을 수 있습니다(시험해 본 결과 약 90% 정확). 처음 받은 문항 자료에 섞여 있던 쪽 머리글(\"국어\", \"언어 영역\", \"홀수형\" 등)과 확인 사항 문구는 선택지에서 걷어 냈습니다. 위첨자·작은 글자 때문에 낱말 순서가 뒤섞였던 곳(예: f1, f2)은 PDF 글자 위치 순서대로 바로잡았습니다. 이 과정에서 글자를 새로 지어 넣지는 않았습니다. 옛 한글 글꼴로 찍힌 글자는 □로 표시됩니다. 문단 나눔과 시의 행·연 나눔도 같은 방식으로 들여쓰기·줄 길이를 읽어 되살렸습니다.</p>
      </details>
      <details>
        <summary>제시 자료(&lt;보기&gt;·&lt;자료&gt;·&lt;학습 활동&gt; 등)</summary>""")

# ---- CSS ----
rep(".y-none{color:var(--text-faint)}", """.y-none{color:var(--text-faint)}
.y-miss{color:var(--text-faint);font-size:12.5px;border-bottom:1px dotted var(--text-faint);cursor:help}
.ylink.form{min-width:0;padding:5px 10px;margin:2px 3px}
.pre-row td{background:var(--bg-sub)}
.pre-row td:first-child small{font-weight:500;color:var(--text-sub);margin-left:2px}
.pre-cell{text-align:left!important}
.pre-note{font-size:12px;color:var(--text-faint);margin-left:8px}
.table-note{font-size:12.5px;color:var(--text-sub);margin:8px 2px 0;line-height:1.6}""")

open(DST, "w", encoding="utf-8").write(s)
print("items", len(ITEMS), "passages", len(PASSAGES), "choices", len(CHOICES), "notes", len(NOTES))
