/* ---------- 문제 담기 · 모아 풀기 · 시험지 인쇄 ---------- */
const BK_KEY = 'kbank-basket-v1';
const BK_MAX_PAGES = 16;
const basket = Object.assign({keys:[], title:'', paper:'A4', font:'auto', ansKey:false, src:true, face:'noto', faceCustom:''}, loadJSON(BK_KEY));
basket.keys = (Array.isArray(basket.keys) ? basket.keys : []).filter(k=>typeof k === 'string');
const basketSec = document.getElementById('basket');
let bkView = 'list';            // 'list' | 'solve'
let bkConfirm = false;
let bkSolveStart = 0, bkTimerId = null;
let bkLayout = null, bkLayoutSig = '', bkLayoutRun = 0, bkLayoutTimer = null, bkLayoutBusy = null;
let bkDownloads = null;

function saveBasket(){ saveJSON(BK_KEY, basket); }
function inBasket(k){ return basket.keys.includes(k); }
function bkValidKeys(){ return basket.keys.filter(k=>itemByKey(k)); }
function bkBtnLabel(on){ return on ? '✓ 담음 · 빼기' : '＋ 문제 담기'; }
function updateBkCount(){ const n = bkValidKeys().length; document.getElementById('bkCount').textContent = n ? n : ''; }
function bkGroupLabel(keys){ return keys.every(inBasket) ? '이 지문 문항 모두 빼기' : `이 지문 문항 모두 담기 (${keys.length})`; }
function syncBasketMarks(){
  document.querySelectorAll('.do-basket').forEach(b=>{
    const on = inBasket(b.dataset.key);
    b.classList.toggle('on', on); b.textContent = bkBtnLabel(on); b.setAttribute('aria-pressed', String(on));
  });
  document.querySelectorAll('.result-row').forEach(r=>{ const m = r.querySelector('.bk-mark'); if(m) m.hidden = !inBasket(r.dataset.key); });
  document.querySelectorAll('.bk-group').forEach(b=>{
    const ks = b.dataset.keys.split(',').map(decodeURIComponent);
    b.textContent = bkGroupLabel(ks); b.classList.toggle('on', ks.every(inBasket));
  });
  updateBkCount();
}
function bkChanged(){
  saveBasket(); syncBasketMarks();
  if(state.basket && bkView === 'list') renderBasket();
}
function bkAdd(keys){ let added = 0; keys.forEach(k=>{ if(!inBasket(k)){ basket.keys.push(k); added++; } }); bkChanged(); return added; }
function bkRemove(keys){ const s = new Set(keys); basket.keys = basket.keys.filter(k=>!s.has(k)); bkChanged(); }

let bkToastTimer = null;
function bkToast(text){
  const t = document.getElementById('bkToast');
  t.querySelector('span').textContent = text;
  t.hidden = false;
  clearTimeout(bkToastTimer); bkToastTimer = setTimeout(()=>{ t.hidden = true; }, 3200);
}

/* 담은 문항을 지문별로 묶는다. 묶음 순서는 처음 담은 순서, 묶음 안에서는 원래 문항 번호 순. */
function bkGroups(){
  const groups = [], map = new Map();
  bkValidKeys().forEach(k=>{
    const it = itemByKey(k);
    const solo = !it.지문범위 || it.지문범위 === '(독립 문항)';
    const gk = solo ? 'solo||'+k : `${it.exam_id}||${it.영역}||${it.지문범위}`;
    if(!map.has(gk)){
      const g = {gk, examId:it.exam_id, 영역:it.영역, 지문범위:it.지문범위, solo, 소재:it.소재, 분야:it.분야, 작품:it.작품||[], 명칭:it.명칭, items:[]};
      map.set(gk, g); groups.push(g);
    }
    map.get(gk).items.push(it);
  });
  const num = new Map(); let n = 0;
  groups.forEach(g=>{
    g.items.sort((a,b)=>a.문항번호-b.문항번호);
    g.start = n+1; g.items.forEach(it=>num.set(itemKey(it), ++n)); g.end = n;
  });
  return {groups, num, total:n};
}
function bkSetOrder(groups){ basket.keys = groups.flatMap(g=>g.items.map(itemKey)); bkChanged(); }
const BK_AREA_ORDER = ['독서','독서와 작문','문학','화법과 작문','화법과 언어','언어와 매체'];
function bkRangeLabel(g){ return g.start === g.end ? `${g.start}` : `${g.start}~${g.end}`; }
function bkChoices(it){ return (it.exam_id === '2028-예시' ? CHOICES_2028 : CHOICES)[itemKey(it)] || null; }
function bkStem(it, n){ return String(it.발문||'').replace(/^\s*\d+\s*\.\s*/, n != null ? `${n}. ` : ''); }
const BK_BOGI_REF = /<\s*보\s*기\s*>|<\s*(자료|학습 활동|조건)( \d)?\s*>|\[자료\]/;
/* 발문이 <보기>·<자료>를 가리키는데 제시 자료 칸이 비어 있고 지문에도 없는 문항 = 제시 자료가 그림·표 */
function figI(it){ return (typeof FIGS !== 'undefined' && FIGS.i[itemKey(it)]) || null; }
function figP(examId, area, range){ return (typeof FIGS !== 'undefined' && FIGS.p[`${examId}||${area}||${range}`]) || null; }
function bkBogiMissing(it){
  if(figI(it)) return false;
  if((it.보기||'').trim() || !BK_BOGI_REF.test(it.발문||'')) return false;
  const t = getPassage(it.exam_id, it.영역, it.지문범위) || '';
  return !/<\s*보\s*기\s*>/.test(t);
}
/* 지문 상태: 'none' 원문 없음 · 'image' 글자가 거의 없음(화면·그림) · 'fig' 지문 안에 [그림] 표시 · '' 정상 */
function bkPassageState(examId, area, range){
  if(figP(examId, area, range)) return '';
  const t = getPassage(examId, area, range);
  if(!t || !t.trim()) return 'none';
  if(/\((가|나)\)|\[화면/.test(t) && t.replace(/\((가|나|다|라)\)|\[화면\d*\]|\([^)]*화면\)|\s/g,'').length < 40) return 'image';
  if(/\[(그림|사진|표)[^\]]*\]/.test(t)) return 'fig';
  return '';
}
const BK_PSTATE_TXT = {none:'지문 원문 없음', image:'지문이 그림(화면)이라 글자가 거의 없음', fig:'지문 속 그림은 빠짐'};
function bkWarnings(it, g){
  const w = [];
  if(!bkChoices(it) && !(figI(it) && figI(it).m === 'ch')) w.push('선택지가 그림이라 인쇄본에 선택지가 없음');
  if(bkBogiMissing(it)) w.push('제시 자료(<보기> 등)가 그림·표라 빠짐');
  if(!g.solo){ const ps = bkPassageState(g.examId, g.영역, g.지문범위); if(ps) w.push(BK_PSTATE_TXT[ps]); }
  if(!it.정답) w.push('정답 없음');
  return w;
}

/* ---------- 담은 문제 화면 ---------- */
function renderBasket(){
  if(bkView === 'solve'){ renderBasketSolve(); return; }
  stopBkTimer();
  const {groups, total} = bkGroups();
  const points = groups.reduce((s,g)=>s+g.items.reduce((a,it)=>a+(Number(it.배점)||0),0),0);
  const byArea = {};
  groups.forEach(g=>g.items.forEach(it=>{ byArea[it.영역] = (byArea[it.영역]||0)+1; }));
  const passN = groups.filter(g=>!g.solo).length;
  const dl = bkDownloads;
  basketSec.innerHTML = `
    <div class="crumb"><span>내 공부</span><span>담은 문제</span></div>
    <div class="exam-title">
      <div><h2>담은 문제</h2><p>${total ? `${total}문항 · 지문 ${passN}개 · 배점 합 ${points}점 · 번호는 담은 순서대로 새로 매깁니다.` : '문항을 펼쳐 "문제 담기"를 누르면 여기에 모입니다.'}</p></div>
      ${total ? `<div class="bk-bar">
        <button type="button" class="btn-fill" id="bkSolve">모아 풀기</button>
        <button type="button" class="btn-plain" id="bkSortArea" title="독서 → 문학 → 화법과 작문 → 언어와 매체 순으로 묶음을 다시 늘어놓습니다.">영역 순으로 정리</button>
        ${bkConfirm ? `<span class="bk-confirm">모두 비울까요?</span><button type="button" class="btn-plain" id="bkClearYes" style="color:var(--bad);border-color:var(--bad)">비우기</button><button type="button" class="btn-plain" id="bkClearNo">취소</button>` : `<button type="button" class="btn-plain" id="bkClear">모두 비우기</button>`}
      </div>` : ''}
    </div>
    ${!storageOK ? '<div class="notice" style="margin-top:12px"><span class="notice-tag">안내</span><span>이 브라우저에서는 담은 문제를 저장할 수 없습니다. 페이지를 새로 열면 목록이 사라집니다.</span></div>' : ''}
    ${!total ? `<div class="nb-empty" style="margin-top:16px"><b style="display:block;color:var(--text);font-size:16px;margin-bottom:4px">아직 담은 문제가 없습니다.</b>검색 결과나 회차 화면에서 문항을 펼친 뒤 "＋ 문제 담기"를 누르세요. 회차 화면에서는 "이 지문 문항 모두 담기"로 한 지문의 문항을 한꺼번에 담을 수 있습니다.</div>` : `
    <div class="bk-dist">${Object.entries(byArea).sort((a,b)=>BK_AREA_ORDER.indexOf(a[0])-BK_AREA_ORDER.indexOf(b[0])).map(([a,n])=>`${areaBadge(a)}<span>${n}문항</span>`).join('')}</div>
    <div class="bk-panel">
      <h3>시험지로 인쇄하기 <small style="font-weight:400;color:var(--text-faint);font-size:12.5px">— 국어 시험지처럼 2단으로 짜서 ${BK_MAX_PAGES}쪽 안에 넣습니다</small></h3>
      <div class="bk-fields">
        <div class="field wide"><label for="bkTitle">시험지 제목</label><input type="text" id="bkTitle" maxlength="40" placeholder="예: 3학년 2반 독서 집중 연습" value="${escapeHtml(basket.title)}"></div>
        <div class="field"><label for="bkPaper">용지</label><select id="bkPaper"><option value="A4">A4 (210×297mm)</option><option value="B4">B4 (257×364mm)</option></select></div>
        <div class="field"><label for="bkFont">글자 크기</label><select id="bkFont"><option value="auto">자동 맞춤 (${BK_MAX_PAGES}쪽 안)</option>${BK_FONT_STEPS.map(f=>`<option value="${f}">${f}pt</option>`).join('')}</select></div>
        <div class="field"><label for="bkFace">글꼴</label><select id="bkFace">${BK_FACES.map(f=>`<option value="${f.v}">${escapeHtml(f.label)}</option>`).join('')}</select></div>
        <div class="field" id="bkFaceCustomF" ${basket.face==='custom'?'':'hidden'}><label for="bkFaceCustom">글꼴 이름</label><input type="text" id="bkFaceCustom" maxlength="40" placeholder="예: 신명 중명조" value="${escapeHtml(basket.faceCustom)}"></div>
        <label class="check"><input type="checkbox" id="bkSrc" ${basket.src?'checked':''}><span>원래 회차·번호 표시</span></label>
        <label class="check"><input type="checkbox" id="bkAns" ${basket.ansKey?'checked':''}><span>맨 뒤에 정답표 붙이기</span></label>
      </div>
      <div class="bk-info" id="bkFaceInfo">${bkFaceInfo()}</div>
      <div class="bk-info" id="bkInfo">쪽수를 계산하는 중입니다…</div>
      <div class="bk-bar">
        <button type="button" class="btn-plain" id="bkPrevBtn" aria-expanded="false">미리 보기</button>
        <button type="button" class="btn-fill" id="bkPrintBtn" disabled>인쇄하기</button>
        ${dl ? `<button type="button" class="btn-plain" id="bkDlBtn" disabled>인쇄용 파일 받기 (.html)</button>` : ''}
      </div>
      <div class="bk-msg" id="bkMsg"></div>
      <div class="bk-preview" id="bkPreview"></div>
    </div>
    <div class="bk-groups">
      ${groups.map((g,gi)=>`
      <section class="bk-g" data-gi="${gi}">
        <div class="bk-g-head">
          <span class="bk-g-range">[${bkRangeLabel(g)}]</span>
          ${areaBadge(g.영역)}
          <span class="bk-g-topic">${escapeHtml(g.solo ? '독립 문항' : g.소재)}</span>
          <span class="bk-g-src">${escapeHtml(g.명칭)}${g.solo ? '' : ` ${escapeHtml(g.지문범위)}번 지문`}</span>
          <span class="bk-g-ctl">
            <button type="button" class="bk-up" data-gi="${gi}" ${gi===0?'disabled':''} aria-label="이 묶음을 위로">↑</button>
            <button type="button" class="bk-down" data-gi="${gi}" ${gi===groups.length-1?'disabled':''} aria-label="이 묶음을 아래로">↓</button>
            <button type="button" class="bk-gdel" data-gi="${gi}">묶음 빼기</button>
          </span>
        </div>
        <ol class="bk-items">${g.items.map((it,ii)=>{
          const w = bkWarnings(it, g);
          return `<li class="bk-it">
            <span class="n">${g.start+ii}.</span>
            <span class="s"><span>${escapeHtml(bkStem(it, null))}</span><small>원래 ${it.문항번호}번 · ${escapeHtml(it.유형갈래)} · ${escapeHtml(typeLabel(it.유형묶음))} · ${it.배점>=3?'<span class="hard">3점</span>':it.배점+'점'}${w.length?` · <span class="w">${escapeHtml(w.join(', '))}</span>`:''}</small></span>
            <span class="acts">
              <button type="button" class="btn-plain goto-exam" data-exam="${escapeHtml(it.exam_id)}" data-key="${escapeHtml(itemKey(it))}">원래 회차에서 보기</button>
              <button type="button" class="x bk-del" data-key="${escapeHtml(itemKey(it))}" aria-label="${g.start+ii}번 빼기">빼기</button>
            </span>
          </li>`; }).join('')}</ol>
      </section>`).join('')}
    </div>`}
  `;
  if(total){
    document.getElementById('bkPaper').value = basket.paper;
    document.getElementById('bkFont').value = basket.font;
    document.getElementById('bkFace').value = basket.face;
    scheduleBkLayout(0);
  }
}

function renderBasketSolve(){
  const {groups, num, total} = bkGroups();
  if(!total){ bkView = 'list'; renderBasket(); return; }
  basketSec.innerHTML = `
    <div class="crumb"><span>내 공부</span><span>담은 문제</span><span>모아 풀기</span></div>
    <div class="exam-title">
      <div><h2>모아 풀기 · ${total}문항</h2><p>답을 모두 고른 뒤 맨 아래 "한꺼번에 채점하기"를 누르세요. 문항마다 따로 채점해도 됩니다. 풀이 시간 <span class="bk-timer" id="bkTimer">0:00</span></p></div>
      <button type="button" class="btn-plain" id="bkBack">← 담은 문제 목록</button>
    </div>
    <div class="tools" style="margin-top:12px">
      <span class="grp">글자 크기 <button type="button" class="sz" data-sz="-1" aria-label="글자 작게">가-</button><button type="button" class="sz" data-sz="1" aria-label="글자 크게">가+</button></span>
    </div>
    ${groups.map(g=>`
      <article class="pg">
        <div class="pg-head">
          <span class="pg-range">[${bkRangeLabel(g)}]</span>
          ${areaBadge(g.영역)}
          <span class="pg-topic">${escapeHtml(g.solo ? '독립 문항' : g.소재)}</span>
          <span class="pg-field">${escapeHtml(g.명칭)}${g.solo ? ` ${g.items[0].문항번호}번` : ` ${escapeHtml(g.지문범위)}번 지문`}</span>
        </div>
        ${g.solo ? '' : `<div class="pg-body">${passageBlockHtml(g.examId, g)}</div>`}
        ${g.items.map(it=>`<div class="detail bk-solve-item" data-key="${escapeHtml(itemKey(it))}" data-num="${num.get(itemKey(it))}">${detailHtml(it, false, num.get(itemKey(it)))}</div>`).join('')}
      </article>`).join('')}
    <div class="bk-grade">
      <div class="bk-bar"><button type="button" class="btn-fill" id="bkGradeAll">한꺼번에 채점하기</button><span style="font-size:13px;color:var(--text-sub)">고른 답이 있는 문항만 채점되고, 결과는 오답 노트에도 기록됩니다.</span></div>
      <div class="bk-result" id="bkResult"></div>
    </div>`;
  bkSolveStart = Date.now();
  startBkTimer();
}
function fmtTime(ms){ const s = Math.floor(ms/1000); const h = Math.floor(s/3600), m = Math.floor(s%3600/60), x = s%60; return h ? `${h}:${String(m).padStart(2,'0')}:${String(x).padStart(2,'0')}` : `${m}:${String(x).padStart(2,'0')}`; }
function startBkTimer(){
  stopBkTimer();
  bkTimerId = setInterval(()=>{
    const t = document.getElementById('bkTimer');
    if(!t || !state.basket || bkView !== 'solve'){ stopBkTimer(); return; }
    t.textContent = fmtTime(Date.now() - bkSolveStart);
  }, 1000);
}
function stopBkTimer(){ if(bkTimerId){ clearInterval(bkTimerId); bkTimerId = null; } }
function bkGradeAll(){
  let ok = 0, graded = 0, score = 0, total = 0, noKey = 0;
  const wrong = [], blank = [];
  basketSec.querySelectorAll('.bk-solve-item').forEach(d=>{
    const it = itemByKey(d.dataset.key); const n = Number(d.dataset.num);
    if(!it) return;
    if(!it.정답){ noKey++; return; }
    total += Number(it.배점)||0;
    const list = d.querySelector('.choices.solve');
    const picked = list ? list.querySelector('.ch.picked') : null;
    if(!picked){ blank.push(n); return; }
    const g = d.querySelector('.do-grade');
    if(g && !g.disabled) g.click();
    graded++;
    if(Number(picked.dataset.n) === it.정답){ ok++; score += Number(it.배점)||0; } else wrong.push(n);
  });
  const el = document.getElementById('bkResult');
  const jumps = arr=>arr.map(n=>`<button type="button" class="bk-jump" data-num="${n}">${n}번</button>`).join('');
  el.innerHTML = `
    <div>채점한 문항 <b>${graded}</b>개 중 맞힌 문항 <b style="color:var(--good)">${ok}</b>개 · 점수 <b>${score}</b> / ${total}점 · 풀이 시간 <b>${fmtTime(Date.now()-bkSolveStart)}</b></div>
    ${blank.length ? `<div>답을 고르지 않은 문항 ${blank.length}개 (점수에는 0점으로 들어갑니다)</div><div class="jumps" style="--bad:var(--text-sub)">${jumps(blank)}</div>` : ''}
    ${wrong.length ? `<div style="margin-top:6px">틀린 문항 ${wrong.length}개 — 누르면 그 문항으로 갑니다</div><div class="jumps">${jumps(wrong)}</div>` : (graded ? '<div style="color:var(--good);font-weight:700">채점한 문항을 모두 맞혔어요!</div>' : '')}
    ${noKey ? `<div style="font-size:13px;color:var(--text-faint)">정답이 반영되지 않은 ${noKey}문항은 채점에서 뺐습니다.</div>` : ''}`;
}

/* ---------- 시험지 쪽 나누기 ---------- */
const BK_FONT_STEPS = [10.5, 10, 9.5, 9, 8.5];
const BK_PAPER = {A4:{w:210, h:297}, B4:{w:257, h:364}};
const SHEET_CSS = `
.sheet{position:relative;box-sizing:border-box;background:#fff;color:#111;overflow:hidden;
  font-family:var(--pfam,"Noto Serif KR"),"Noto Serif KR","Batang","AppleMyungjo",serif;font-size:var(--pf,10pt);line-height:1.62;
  word-break:keep-all;overflow-wrap:anywhere;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.sheet *{box-sizing:border-box}
#printArea .sheet{contain:strict}
.sh-hd{position:absolute;display:flex;align-items:flex-end;justify-content:center;border-bottom:.5mm solid #111;
  font-family:"Noto Sans KR","Malgun Gothic",sans-serif;font-weight:800;font-size:11pt;line-height:1;padding-bottom:1.6mm}
.sh-hd .pn{position:absolute;bottom:1.2mm;font-size:17pt;font-weight:800}
.sh-hd.odd .pn{right:0} .sh-hd.even .pn{left:0}
.sh-hd1{position:absolute;text-align:center;border-bottom:.8mm solid #111;font-family:"Noto Sans KR","Malgun Gothic",sans-serif;line-height:1.25}
.sh-hd1 .t-s{font-size:10pt;font-weight:500;letter-spacing:.05em}
.sh-hd1 .t-b{font-size:25pt;font-weight:800;letter-spacing:.35em;margin:1mm 0 1.4mm .35em}
.sh-hd1 .t-u{font-size:10.5pt;font-weight:700;min-height:1.25em}
.sh-hd1 .pn{position:absolute;right:0;top:0;font-size:17pt;font-weight:800}
.sh-hd1 .nm{position:absolute;right:0;bottom:1.6mm;font-size:9pt;font-weight:500;display:flex;gap:3mm}
.sh-hd1 .nm span{display:inline-block;border-bottom:.3mm solid #111;width:24mm}
.sh-cols{position:absolute;display:flex}
.sh-col{position:relative;flex:1 1 0;min-width:0;height:100%;overflow:hidden}
.sh-rule{flex:none;width:0;border-left:.3mm solid #555}
.sh-col > :first-child{margin-top:0!important}
.gh{margin-top:1.25em;font-weight:600;text-align:justify}
.gh .rg{font-weight:700;margin-right:.3em}
.src{font-family:"Noto Sans KR","Malgun Gothic",sans-serif;font-size:.74em;color:#555;font-weight:400}
.gh + .pp, .gh + .poem{margin-top:.45em}
.pp{text-align:justify;text-indent:1em}
.pp.cont{text-indent:0}
.pp.brk{text-align-last:justify}
.pp.ph{text-indent:0;font-weight:600}
.poem{white-space:pre-wrap;text-indent:0;text-align:left}
.pnote{font-size:.84em;line-height:1.5;text-indent:0;margin-top:.12em;padding-left:.8em}
.pp + .pnote, .poem + .pnote{margin-top:.5em}
.q{margin-top:1.05em}
.pp + .q, .poem + .q, .pnote + .q{margin-top:1.3em}
.qs{text-align:justify;padding-left:1.45em;text-indent:-1.45em}
.qs .qn{font-weight:700;display:inline-block;min-width:1.45em;text-indent:0}
.qb{border:.3mm solid #222;padding:1.5mm 2.4mm;margin:.45em 0 .35em}
.qb.cont{border-top-style:dashed;margin-top:0}
.qb.brk{border-bottom-style:dashed;margin-bottom:0}
.qbl{text-align:center;font-weight:600;margin-bottom:.15em}
.qbt{white-space:pre-wrap;text-align:justify}
.qc{display:grid;gap:.08em 1.2em;margin-top:.35em;padding-left:.5em}
.qc > div{padding-left:1.25em;text-indent:-1.25em}
.qna{margin-top:.35em;font-size:.88em;color:#444}
.q.part{margin-top:.25em}
.pimg{overflow:hidden;margin:.35em auto 0;break-inside:avoid}
.pimg img{display:block;width:100%;height:auto}
.gh + .pimg{margin-top:.5em}
.pimg + .pimg{margin-top:0}
.qs + .pimg{margin-top:.45em}
.sh-key{position:absolute;font-family:"Noto Sans KR","Malgun Gothic",sans-serif;font-size:9.5pt;line-height:1.35}
.sh-key h3{margin:0 0 3mm;font-size:13pt;text-align:center}
.sh-key .kc{display:flex;gap:6mm;align-items:flex-start}
.sh-key table{flex:1;border-collapse:collapse}
.sh-key th,.sh-key td{border:.25mm solid #333;padding:1mm 1.5mm;text-align:center}
.sh-key th{background:#eee;font-weight:700}
.sh-key td.l{text-align:left;font-size:.88em}
`;
(function injectSheetCss(){ const st = document.createElement('style'); st.id = 'sheetCss'; st.textContent = SHEET_CSS; document.head.appendChild(st); })();
/* 인쇄 글꼴: 웹 글꼴(Noto Serif KR) 또는 이 컴퓨터에 설치된 글꼴 */
const BK_FACES = [
  {v:'noto', label:'Noto Serif KR (기본 웹 글꼴)', names:['Noto Serif KR']},
  {v:'shin', label:'신명 중명조 (설치된 경우)', names:['신명 중명조','신명중명조','SM중명조','신명 신명조','신명신명조','SM신명조']},
  {v:'hy', label:'HY신명조', names:['HY신명조','HYSinMyeongJo-Medium']},
  {v:'hcr', label:'함초롬바탕', names:['함초롬바탕','HCR Batang']},
  {v:'batang', label:'바탕', names:['바탕','Batang']},
  {v:'custom', label:'직접 입력', names:[]},
];
const bkFontCache = new Map();
function bkFontInstalled(name){
  if(bkFontCache.has(name)) return bkFontCache.get(name);
  let ok = false;
  try{
    const c = document.createElement('canvas').getContext('2d');
    const sample = '가나다라 국어 영역 ABCabc 123 ①②';
    ok = ['monospace','sans-serif','serif'].some(base=>{
      c.font = `40px ${base}`; const w0 = c.measureText(sample).width;
      c.font = `40px "${name.replace(/"/g,'')}", ${base}`; return Math.abs(c.measureText(sample).width - w0) > 0.5;
    });
  }catch(e){}
  bkFontCache.set(name, ok); return ok;
}
/* 고른 글꼴 중 실제로 쓸 이름. 웹 글꼴은 늘 쓸 수 있다고 본다. 못 찾으면 null */
function bkFaceName(){
  const f = BK_FACES.find(x=>x.v===basket.face) || BK_FACES[0];
  if(f.v === 'noto') return 'Noto Serif KR';
  const names = f.v === 'custom' ? [basket.faceCustom.trim()].filter(Boolean) : f.names;
  return names.find(bkFontInstalled) || null;
}
function bkFaceCss(){ const n = bkFaceName(); return n ? `"${n.replace(/"/g,'')}"` : '"Noto Serif KR"'; }
function bkFaceInfo(){
  const f = BK_FACES.find(x=>x.v===basket.face) || BK_FACES[0];
  if(f.v === 'noto') return '';
  const n = bkFaceName();
  if(f.v === 'custom' && !basket.faceCustom.trim()) return '<span class="warn">글꼴 이름을 한글·워드의 글꼴 목록에 보이는 대로 적어 주세요.</span>';
  return n ? `<span class="ok">✓ 이 컴퓨터에서 "${escapeHtml(n)}" 글꼴을 찾았습니다.</span>`
           : `<span class="no">이 컴퓨터에서 ${escapeHtml(f.v === 'custom' ? '"'+basket.faceCustom.trim()+'"' : f.label.replace(/ \(.*\)$/,''))} 글꼴을 찾지 못해 기본 글꼴(Noto Serif KR)로 짭니다.</span>`;
}
function bkGeom(paper){
  const p = BK_PAPER[paper] || BK_PAPER.A4; const s = p.w/210;
  return {w:p.w, h:p.h, mx:13*s, hdTop:8*s, hdH:9*s, top:20*s, top1:42*s, hd1H:30*s, bottom:13*s, gap:8*s};
}
function mm(v){ return `${Math.round(v*100)/100}mm`; }
function bkEl(html){ const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; }
function sheetHtml(idx, g, title, nItems){
  const first = idx === 0;
  const head = first
    ? `<div class="sh-hd1" style="left:${mm(g.mx)};right:${mm(g.mx)};top:${mm(g.hdTop)};height:${mm(g.hd1H)}"><div class="pn">1</div><div class="t-s">담은 문제 모음 · ${nItems}문항</div><div class="t-b">국어 영역</div><div class="t-u">${escapeHtml(title)}</div><div class="nm">성명 <span></span> 번호 <span></span></div></div>`
    : `<div class="sh-hd ${idx%2 ? 'even' : 'odd'}" style="left:${mm(g.mx)};right:${mm(g.mx)};top:${mm(g.hdTop)};height:${mm(g.hdH)}"><span class="pn">${idx+1}</span>국어 영역</div>`;
  const top = first ? g.top1 : g.top;
  return `<div class="sheet" style="width:${mm(g.w)};height:${mm(g.h)}">${head}
    <div class="sh-cols" style="left:${mm(g.mx)};right:${mm(g.mx)};top:${mm(top)};bottom:${mm(g.bottom)}">
      <div class="sh-col"></div><div class="sh-rule" style="margin:0 ${mm(g.gap/2)}"></div><div class="sh-col"></div>
    </div></div>`;
}
function bkChoiceCols(ch, g, pt){
  const colMm = (g.w - 2*g.mx - g.gap)/2 - 2;
  const cpl = colMm / (pt*0.3528*1.02);          // 한 줄에 들어가는 대략의 글자 수(한글 기준)
  const maxLen = Math.max(...ch.map(c=>[...c].length));
  for(const k of [5, 2]) if(maxLen + 2.2 <= cpl/k) return k;
  return 1;
}
/* 원본 그림 조각: 흰 줄(c) 자리에서만 끊어 여러 단에 나눠 싣는다 */
function bkImgBlock(fg, cls){
  const ys = [0].concat((fg.c||[]).filter(y=>y > 8 && y < fg.h - 8), [fg.h]);
  const wmm = Math.round(fg.w * 0.127 * 10) / 10;   // 원본 200dpi 기준 크기
  return {t:'text', tok:ys.slice(1), sep:'', make:(i,j)=>{
    const y0 = ys[i], y1 = ys[j];
    return `<div class="pimg ${cls||''}" style="width:min(100%,${wmm}mm);aspect-ratio:${fg.w}/${Math.max(1,y1-y0)}"><img src="${fg.f}" alt="" style="margin-top:-${(y0/fg.w*100).toFixed(3)}%"></div>`;
  }};
}
/* 쪽 나누기에 쓸 조각(block) 목록 */
function bkBlocks(groups, num, g, pt){
  const B = [];
  const srcOn = basket.src;
  groups.forEach(gr=>{
    if(!gr.solo){
      const range = bkRangeLabel(gr);
      B.push({t:'head', html:`<div class="gh"><span class="rg">[${range}]</span>다음 글을 읽고 물음에 답하시오.${srcOn ? ` <span class="src">${escapeHtml(gr.명칭)} ${escapeHtml(gr.지문범위)}번</span>` : ''}</div>`});
      let t = getPassage(gr.examId, gr.영역, gr.지문범위);
      const pst = bkPassageState(gr.examId, gr.영역, gr.지문범위);
      const pf = figP(gr.examId, gr.영역, gr.지문범위);
      if(pf){
        pf.forEach(fg=>B.push(bkImgBlock(fg, 'pfg')));
      } else if(pst === 'image'){
        B.push({t:'unit', html:`<div class="pp cont qna">※ 이 지문은 원본 문제지에서 그림(화면)으로 되어 있어 이 자료에 싣지 못했습니다. 원본 문제지를 확인하세요.</div>`});
      } else if(!t){
        B.push({t:'unit', html:`<div class="pp cont qna">(이 지문은 원문이 수록되어 있지 않습니다. 원본 문제지를 확인하세요.)</div>`});
      } else {
        const notes = PASSAGE_NOTES[`${gr.examId}||${gr.영역}||${gr.지문범위}`] || [];
        notes.forEach(n=>{ t = t.replace(n[2], ''); });
        const gs = gr.items[0].갈래 || [];
        const poemOnly = gs.length > 0 && gs.every(x=>POEM_GENRES.includes(x));
        if(poemOnly){
          const lines = t.replace(/^\n+|\s+$/g,'').split('\n');
          B.push({t:'text', tok:lines, sep:'\n', make:(i,j,cont,brk)=>{
            let seg = lines.slice(i,j); if(cont) while(seg.length && !seg[0].trim()) seg = seg.slice(1);
            return `<div class="poem">${escapeHtml(seg.join('\n'))}</div>`; }});
        } else {
          t.trim().split(/\n+/).map(x=>x.trim()).filter(Boolean).forEach(x=>{
            const head = /^\((가|나|다|라|마)\)$|^\[[A-Z]\]$|^<[^>]+>$|^\[(앞부분|중략|뒷부분)/.test(x) || x.length < 8;
            const tok = x.split(' ');
            B.push({t:'text', tok, sep:' ', make:(i,j,cont,brk)=>
              `<div class="pp${head?' ph':''}${cont?' cont':''}${brk?' brk':''}">${escapeHtml(tok.slice(i,j).join(' '))}</div>`});
          });
        }
        notes.forEach(n=>B.push({t:'unit', html:`<div class="pnote">${escapeHtml(n[2])}</div>`}));
        if(pst === 'fig') B.push({t:'unit', html:`<div class="pnote qna">※ 지문 속 [그림]은 이 자료에 싣지 못했습니다. 원본 문제지를 확인하세요.</div>`});
      }
    }
    gr.items.forEach(it=>{
      const n = num.get(itemKey(it));
      const src = srcOn ? ` <span class="src">${gr.solo ? `${escapeHtml(it.명칭)} ` : '원래 '}${it.문항번호}번</span>` : '';
      const stem = `<div class="qs"><span class="qn">${n}.</span>${escapeHtml(bkStem(it, null))}${src}</div>`;
      let bogiHtml = '', bogiPart = null;
      const fi = figI(it);
      if(fi){
        const ib = bkImgBlock(fi, 'qfg');
        bogiHtml = ib.make(0, ib.tok.length);
        bogiPart = ib;
      } else if(bkBogiMissing(it)){
        bogiHtml = `<div class="qna">※ 이 문항의 제시 자료(&lt;보기&gt; 등)는 그림·표라 이 자료에 싣지 못했습니다. 원본 문제지를 확인하세요.</div>`;
        bogiPart = {t:'unit', html:`<div class="q part">${bogiHtml}</div>`};
      } else if(it.보기){
        const m = /^<\s*([^<>]{1,12}?)\s*>\s*/.exec(it.보기);
        const label = m ? m[1] : '';
        const body = m ? it.보기.slice(m[0].length) : it.보기;
        const lab = label ? `<div class="qbl">&lt; ${escapeHtml(label)} &gt;</div>` : '';
        bogiHtml = `<div class="qb">${lab}<div class="qbt">${escapeHtml(body)}</div></div>`;
        const tok = body.split(' ');
        bogiPart = {t:'text', tok, sep:' ', make:(i,j,cont,brk)=>
          `<div class="qb${cont?' cont':''}${brk?' brk':''}">${cont?'':lab}<div class="qbt">${escapeHtml(tok.slice(i,j).join(' '))}</div></div>`};
      }
      const ch = bkChoices(it);
      let chHtml;
      if(fi && fi.m === 'ch') chHtml = '';
      else if(ch){
        const k = bkChoiceCols(ch, g, pt);
        chHtml = `<div class="qc" style="grid-template-columns:repeat(${k},minmax(0,1fr))">${ch.map((c,i)=>`<div>${CIRCLED[i+1]} ${escapeHtml(c)}</div>`).join('')}</div>`;
      } else chHtml = `<div class="qna">※ 이 문항의 선택지는 그림·도식이라 이 자료에 싣지 못했습니다. 원본 문제지를 확인하세요.</div>`;
      const parts = [{t:'unit', html:`<div class="q">${stem}</div>`}];
      if(bogiPart) parts.push(bogiPart);
      if(chHtml) parts.push({t:'unit', html:`<div class="q part">${chHtml}</div>`});
      B.push({t:'unit', html:`<div class="q">${stem}${bogiHtml}${chHtml}</div>`, parts});
    });
  });
  return B;
}
function bkLayoutSync(pt){
  const {groups, num, total} = bkGroups();
  const area = document.getElementById('printArea');
  const g = bkGeom(basket.paper);
  area.innerHTML = '';
  area.style.setProperty('--pf', pt+'pt');
  area.style.setProperty('--pfam', bkFaceCss());
  const title = basket.title.trim();
  const sheets = [];
  let cols, cur, forced = 0;
  const newSheet = ()=>{ const sh = bkEl(sheetHtml(sheets.length, g, title, total)); area.appendChild(sh); sheets.push(sh); cols = sh.querySelectorAll('.sh-col'); cur = cols[0]; };
  const nextCol = ()=>{ if(cur === cols[0]) cur = cols[1]; else newSheet(); };
  const used = ()=>{ const l = cur.lastElementChild; if(!l) return 0; return l.getBoundingClientRect().bottom - cur.getBoundingClientRect().top; };
  const cap = ()=>cur.getBoundingClientRect().height - 1;
  const over = ()=>used() > cap();
  const lineH = pt*1.62*96/72;
  const tryPut = node=>{ cur.appendChild(node); if(!over()) return true; cur.removeChild(node); return false; };
  newSheet();
  function placeText(b){
    let i = 0, cont = false; const n = b.tok.length;
    while(i < n){
      if(tryPut(bkEl(b.make(i, n, cont, false)))) return;
      let lo = i+1, hi = n-1, best = -1;
      while(lo <= hi){
        const mid = (lo+hi)>>1; const p = bkEl(b.make(i, mid, cont, true));
        cur.appendChild(p); const ok = !over(); cur.removeChild(p);
        if(ok){ best = mid; lo = mid+1; } else hi = mid-1;
      }
      if(best > i){ cur.appendChild(bkEl(b.make(i, best, cont, true))); i = best; cont = true; nextCol(); }
      else if(!cur.lastElementChild){ cur.appendChild(bkEl(b.make(i, i+1, cont, true))); i++; cont = true; forced++; nextCol(); }
      else nextCol();
    }
  }
  function place(b){
    if(b.t === 'text'){ placeText(b); return; }
    if(b.t === 'head'){
      const node = bkEl(b.html); cur.appendChild(node);
      if(over() || used() + lineH*3 > cap()){ cur.removeChild(node); if(cur.lastElementChild) nextCol(); cur.appendChild(bkEl(b.html)); }
      return;
    }
    if(tryPut(bkEl(b.html))) return;
    if(cur.lastElementChild){ nextCol(); if(tryPut(bkEl(b.html))) return; }
    if(b.parts){ b.parts.forEach(place); return; }
    cur.appendChild(bkEl(b.html)); forced++; nextCol();
  }
  bkBlocks(groups, num, g, pt).forEach(place);
  while(sheets.length > 1 && !sheets[sheets.length-1].querySelector('.sh-col > *')){ sheets.pop().remove(); }
  const pages = sheets.length;
  if(basket.ansKey) bkAnswerSheets(area, g, groups, num, pages);
  return {pages, pt, paper:basket.paper, forced, total, keyPages: area.children.length - pages};
}
function bkAnswerSheets(area, g, groups, num, startIdx){
  const rows = [];
  groups.forEach(gr=>gr.items.forEach(it=>rows.push(`<tr><td>${num.get(itemKey(it))}</td><td>${it.정답 ? CIRCLED[it.정답] : '–'}</td><td>${it.배점}</td><td class="l">${escapeHtml(examShort(it).code+' '+examShort(it).kind)} ${it.문항번호}번</td></tr>`)));
  const per = Math.floor((g.h - 40*g.w/210) / 6.2) * 2;   // 한 쪽에 두 표
  for(let s = 0; s < rows.length; s += per){
    const chunk = rows.slice(s, s+per); const half = Math.ceil(chunk.length/2);
    const tbl = r=>`<table><thead><tr><th>번호</th><th>정답</th><th>배점</th><th>출처</th></tr></thead><tbody>${r.join('')}</tbody></table>`;
    area.appendChild(bkEl(`<div class="sheet" style="width:${mm(g.w)};height:${mm(g.h)}"><div class="sh-key" style="left:${mm(g.mx)};right:${mm(g.mx)};top:${mm(g.hdTop+4)}"><h3>정답표${basket.title.trim() ? ' · '+escapeHtml(basket.title.trim()) : ''}</h3><div class="kc">${tbl(chunk.slice(0,half))}${chunk.length>half ? tbl(chunk.slice(half)) : ''}</div></div></div>`));
  }
}
function bkSig(){ return JSON.stringify([bkValidKeys(), basket.paper, basket.font, basket.title.trim(), basket.ansKey, basket.src, bkFaceCss()]); }
async function bkLayoutAt(pt){
  let r = bkLayoutSync(pt);
  for(let i = 0; i < 3 && document.fonts && document.fonts.status === 'loading'; i++){
    await document.fonts.ready; r = bkLayoutSync(pt);
  }
  return r;
}
async function bkComputeLayout(){
  const sig = bkSig();
  if(bkLayout && bkLayoutSig === sig) return bkLayout;
  if(bkLayoutBusy && bkLayoutBusy.sig === sig) return bkLayoutBusy.p;
  const run = ++bkLayoutRun;
  const p = (async()=>{
    if(document.fonts) await document.fonts.ready;
    const steps = basket.font === 'auto' ? BK_FONT_STEPS : [Number(basket.font)];
    let r = null;
    for(const pt of steps){
      r = await bkLayoutAt(pt);
      if(run !== bkLayoutRun) return null;
      if(r.pages <= BK_MAX_PAGES) break;
    }
    bkLayout = r; bkLayoutSig = sig;
    return r;
  })();
  bkLayoutBusy = {sig, p};
  try{ return await p; } finally { if(bkLayoutBusy && bkLayoutBusy.p === p) bkLayoutBusy = null; }
}
function scheduleBkLayout(delay){
  clearTimeout(bkLayoutTimer);
  const info = document.getElementById('bkInfo'); if(info && !(bkLayout && bkLayoutSig === bkSig())) info.textContent = '쪽수를 계산하는 중입니다…';
  bkLayoutTimer = setTimeout(async()=>{
    const r = await bkComputeLayout();
    if(r && state.basket && bkView === 'list') showBkInfo(r);
  }, delay);
}
function showBkInfo(r){
  const info = document.getElementById('bkInfo'); if(!info) return;
  const fits = r.pages <= BK_MAX_PAGES;
  const pct = Math.min(100, Math.round(r.pages / BK_MAX_PAGES * 100));
  const paper = r.paper === 'B4' ? 'B4' : 'A4';
  let msg;
  if(fits){
    msg = `<span class="ok">✓ ${BK_MAX_PAGES}쪽 안에 들어갑니다</span> — ${paper} 용지 · 글자 ${r.pt}pt · <b>${r.pages}</b>쪽${r.keyPages ? ` (정답표 ${r.keyPages}쪽은 따로)` : ''}`;
  } else {
    const remove = Math.max(1, Math.ceil(r.total * (r.pages - BK_MAX_PAGES) / r.pages));
    msg = `<span class="no">${BK_MAX_PAGES}쪽을 넘습니다</span> — ${paper} 용지 · 글자 ${r.pt}pt로도 <b>${r.pages}</b>쪽입니다. ${basket.font === 'auto' ? '' : '글자 크기를 "자동 맞춤"으로 바꾸거나 '}문항을 대략 ${remove}개 이상 빼야 인쇄할 수 있습니다.${r.paper === 'A4' ? ' B4 용지로 바꾸면 더 많이 들어갑니다.' : ''}`;
  }
  if(r.forced) msg += `<br><span class="warn">한 단보다 긴 조각이 ${r.forced}곳 있어 그 부분은 글자가 잘릴 수 있습니다. 미리 보기로 확인하세요.</span>`;
  info.innerHTML = `${msg}<div class="bk-meter${fits?'':' over'}" style="margin-top:6px" aria-hidden="true"><i style="width:${pct}%"></i></div>`;
  const pb = document.getElementById('bkPrintBtn'); if(pb) pb.disabled = !fits;
  const db = document.getElementById('bkDlBtn'); if(db) db.disabled = !fits;
  const pv = document.getElementById('bkPreview');
  if(pv && pv.dataset.open === '1') bkFillPreview();
}
function bkFillPreview(){
  const pv = document.getElementById('bkPreview'); if(!pv) return;
  const area = document.getElementById('printArea');
  const sheets = [...area.children];
  const g = bkGeom(basket.paper);
  const pxPerMm = 96/25.4;
  const W = Math.min(440, Math.max(140, (pv.clientWidth - 14) / 2 - 2));
  const s = W / (g.w*pxPerMm);
  pv.innerHTML = '';
  sheets.forEach((sh, i)=>{
    const box = document.createElement('div'); box.className = 'bk-pv';
    const inner = document.createElement('div'); inner.className = 'pv-box';
    inner.style.width = (g.w*pxPerMm*s)+'px'; inner.style.height = (g.h*pxPerMm*s)+'px';
    inner.style.setProperty('--pf', area.style.getPropertyValue('--pf'));
    inner.style.setProperty('--pfam', area.style.getPropertyValue('--pfam'));
    const c = sh.cloneNode(true); c.style.transform = `scale(${s})`;
    inner.appendChild(c); box.appendChild(inner);
    const cap = document.createElement('span'); cap.textContent = i < (bkLayout ? bkLayout.pages : sheets.length) ? `${i+1}쪽` : '정답표';
    box.appendChild(cap); pv.appendChild(box);
  });
}
function bkPageCss(){ const p = BK_PAPER[basket.paper] || BK_PAPER.A4; return `@page{size:${p.w}mm ${p.h}mm;margin:0}`; }
async function bkPrint(){
  const r = await bkComputeLayout(); if(!r || r.pages > BK_MAX_PAGES) return;
  const msg = document.getElementById('bkMsg'); if(msg) msg.textContent = '';
  let st = document.getElementById('bkPageStyle');
  if(!st){ st = document.createElement('style'); st.id = 'bkPageStyle'; document.head.appendChild(st); }
  st.textContent = `@media print{${bkPageCss()}}`;
  await bkImagesReady();
  document.documentElement.classList.add('bk-print');
  let fired = false;
  const onBefore = ()=>{ fired = true; };
  window.addEventListener('beforeprint', onBefore, {once:true});
  try{ window.print(); }catch(e){}
  setTimeout(()=>{
    window.removeEventListener('beforeprint', onBefore);
    if(!fired){
      document.documentElement.classList.remove('bk-print');
      const m = document.getElementById('bkMsg');
      if(m) m.textContent = bkDownloads
        ? '이 화면에서는 인쇄 창이 열리지 않았습니다. "인쇄용 파일 받기"로 파일을 받아 브라우저에서 연 뒤 인쇄해 주세요.'
        : '이 화면에서는 인쇄 창이 열리지 않았습니다. 이 페이지를 브라우저 새 탭에서 열어 다시 시도해 주세요.';
    }
  }, 1500);
}
window.addEventListener('afterprint', ()=>document.documentElement.classList.remove('bk-print'));
/* 인쇄 전에 시험지 속 원본 그림을 모두 내려받아 둔다(최대 10초) */
function bkImagesReady(){
  const imgs = [...document.querySelectorAll('#printArea img')];
  imgs.forEach(i=>{ i.loading = 'eager'; });
  const all = Promise.all(imgs.map(i=>i.complete && i.naturalWidth ? null : new Promise(res=>{ i.addEventListener('load', res, {once:true}); i.addEventListener('error', res, {once:true}); })));
  return Promise.race([all, new Promise(res=>setTimeout(res, 10000))]);
}
const bkDataUrlCache = new Map();
async function bkDataUrl(src){
  if(bkDataUrlCache.has(src)) return bkDataUrlCache.get(src);
  const p = fetch(src).then(r=>{ if(!r.ok) throw new Error(r.status); return r.blob(); })
    .then(b=>new Promise((res, rej)=>{ const fr = new FileReader(); fr.onload = ()=>res(fr.result); fr.onerror = rej; fr.readAsDataURL(b); }));
  bkDataUrlCache.set(src, p);
  try{ return await p; }catch(e){ bkDataUrlCache.delete(src); throw e; }
}
async function bkStandaloneHtml(){
  const area = document.getElementById('printArea');
  const clone = area.cloneNode(true);
  for(const im of clone.querySelectorAll('img')){
    const src = im.getAttribute('src');
    try{ im.setAttribute('src', await bkDataUrl(src)); }catch(e){ im.setAttribute('src', new URL(src, location.href).href); }
  }
  const title = basket.title.trim() || '담은 문제 모음';
  return `<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(title)} — 국어 영역</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;500;700;800&family=Noto+Serif+KR:wght@400;600&display=swap">
<style>${SHEET_CSS}
${bkPageCss()}
html,body{margin:0;padding:0}
@media screen{body{background:#8a8f98}.bar{position:sticky;top:0;z-index:2;display:flex;gap:12px;align-items:center;justify-content:center;flex-wrap:wrap;padding:10px 16px;background:#1f2530;color:#fff;font:14px "Noto Sans KR",sans-serif}
.bar button{font:inherit;font-weight:700;padding:7px 18px;border:0;border-radius:3px;background:#6FA0E6;color:#13171E;cursor:pointer}
#printArea{padding:12px 0}.sheet{margin:0 auto 12px;box-shadow:0 2px 10px rgba(0,0,0,.35)}}
@media print{.bar{display:none}.sheet{break-after:page;page-break-after:always}.sheet:last-child{break-after:auto;page-break-after:auto}}
</style></head><body><div class="bar"><span>${escapeHtml(title)} · ${bkLayout.total}문항 · 문제 ${bkLayout.pages}쪽${bkLayout.keyPages ? ` + 정답표 ${bkLayout.keyPages}쪽` : ''} · 인쇄 설정에서 배율은 100%(기본값), 머리글·바닥글은 끄세요.</span><button type="button" onclick="window.print()">인쇄하기</button></div>
<div id="printArea" style="--pf:${area.style.getPropertyValue('--pf')};--pfam:${escapeHtml(area.style.getPropertyValue('--pfam'))}">${[...clone.children].map(s=>s.outerHTML).join('\n')}</div></body></html>`;
}
async function bkDownload(){
  const r = await bkComputeLayout(); if(!r || r.pages > BK_MAX_PAGES || !bkDownloads) return;
  const msg = document.getElementById('bkMsg');
  if(msg) msg.textContent = '파일을 만드는 중입니다…';
  const name = (basket.title.trim() || '국어_담은문제').replace(/[\\/:*?"<>|]+/g,' ').trim().replace(/\s+/g,'_');
  try{
    await bkDownloads.save({filename:`${name}_${r.total}문항_${r.pages}쪽.html`, data:await bkStandaloneHtml()});
    if(msg) msg.textContent = '파일을 저장했습니다. 브라우저로 열어 "인쇄하기"를 누르세요(인터넷에 연결되어 있어야 글꼴이 같게 나옵니다).';
  }catch(err){
    if(msg) msg.textContent = err && err.code === 'declined' ? '' : '파일을 저장하지 못했습니다.';
  }
}

/* ---------- 이벤트 ---------- */
document.addEventListener('click', e=>{
  const b = e.target.closest('.do-basket');
  if(b){
    const k = b.dataset.key;
    if(inBasket(k)){ bkRemove([k]); bkToast(`뺐어요 · 담은 문제 ${bkValidKeys().length}문항`); }
    else { bkAdd([k]); bkToast(`담았어요 · 담은 문제 ${bkValidKeys().length}문항`); }
    return;
  }
  const gb = e.target.closest('.bk-group');
  if(gb){
    const ks = gb.dataset.keys.split(',').map(decodeURIComponent);
    if(ks.every(inBasket)){ bkRemove(ks); bkToast(`${ks.length}문항을 뺐어요 · 담은 문제 ${bkValidKeys().length}문항`); }
    else { const n = bkAdd(ks); bkToast(`${n}문항을 담았어요 · 담은 문제 ${bkValidKeys().length}문항`); }
  }
});
document.getElementById('bkToast').querySelector('button').addEventListener('click', ()=>{ document.getElementById('bkToast').hidden = true; openBasket(); });
function openBasket(){
  state.basket = true; state.notebook = false; state.examView = false; bkView = 'list'; bkConfirm = false;
  document.querySelectorAll('.gnb-link').forEach(x=>x.classList.toggle('active', x.id==='bkLink'));
  render(); basketSec.scrollIntoView({behavior:'smooth', block:'start'});
}
basketSec.addEventListener('click', e=>{
  const t = e.target;
  if(t.closest('#bkSolve')){ bkView = 'solve'; renderBasket(); basketSec.scrollIntoView({behavior:'smooth', block:'start'}); return; }
  if(t.closest('#bkBack')){ bkView = 'list'; renderBasket(); basketSec.scrollIntoView({behavior:'smooth', block:'start'}); return; }
  if(t.closest('#bkGradeAll')){ bkGradeAll(); return; }
  const j = t.closest('.bk-jump');
  if(j){ const d = basketSec.querySelector(`.bk-solve-item[data-num="${j.dataset.num}"]`); if(d) d.scrollIntoView({behavior:'smooth', block:'center'}); return; }
  if(t.closest('#bkClear')){ bkConfirm = true; renderBasket(); return; }
  if(t.closest('#bkClearNo')){ bkConfirm = false; renderBasket(); return; }
  if(t.closest('#bkClearYes')){ bkConfirm = false; basket.keys = []; bkChanged(); return; }
  if(t.closest('#bkSortArea')){
    const {groups} = bkGroups();
    const idx = new Map(groups.map((g,i)=>[g,i]));
    const ar = a=>{ const i = BK_AREA_ORDER.indexOf(a); return i < 0 ? 99 : i; };
    groups.sort((a,b)=>ar(a.영역)-ar(b.영역) || idx.get(a)-idx.get(b));
    bkSetOrder(groups); return;
  }
  const up = t.closest('.bk-up'), down = t.closest('.bk-down'), gdel = t.closest('.bk-gdel');
  if(up || down || gdel){
    const {groups} = bkGroups(); const gi = Number((up||down||gdel).dataset.gi);
    if(gdel){ bkRemove(groups[gi].items.map(itemKey)); return; }
    const to = up ? gi-1 : gi+1; if(to < 0 || to >= groups.length) return;
    [groups[gi], groups[to]] = [groups[to], groups[gi]]; bkSetOrder(groups); return;
  }
  const del = t.closest('.bk-del'); if(del){ bkRemove([del.dataset.key]); return; }
  if(t.closest('#bkPrevBtn')){
    const pv = document.getElementById('bkPreview'); const btn = document.getElementById('bkPrevBtn');
    if(pv.dataset.open === '1'){ pv.dataset.open = ''; pv.innerHTML = ''; btn.textContent = '미리 보기'; btn.setAttribute('aria-expanded','false'); return; }
    pv.dataset.open = '1'; btn.textContent = '미리 보기 닫기'; btn.setAttribute('aria-expanded','true');
    bkComputeLayout().then(r=>{ if(r) bkFillPreview(); });
    return;
  }
  if(t.closest('#bkPrintBtn')){ bkPrint(); return; }
  if(t.closest('#bkDlBtn')){ bkDownload(); return; }
  onListClick(e);
});
basketSec.addEventListener('change', e=>{
  const id = e.target.id;
  if(id === 'bkPaper'){ basket.paper = e.target.value; }
  else if(id === 'bkFont'){ basket.font = e.target.value; }
  else if(id === 'bkFace'){ basket.face = e.target.value; document.getElementById('bkFaceCustomF').hidden = basket.face !== 'custom'; document.getElementById('bkFaceInfo').innerHTML = bkFaceInfo(); }
  else if(id === 'bkAns'){ basket.ansKey = e.target.checked; }
  else if(id === 'bkSrc'){ basket.src = e.target.checked; }
  else return;
  saveBasket(); scheduleBkLayout(50);
});
basketSec.addEventListener('input', e=>{
  if(e.target.id === 'bkFaceCustom'){ basket.faceCustom = e.target.value; saveBasket(); document.getElementById('bkFaceInfo').innerHTML = bkFaceInfo(); scheduleBkLayout(600); return; }
  if(e.target.id !== 'bkTitle') return;
  basket.title = e.target.value; saveBasket(); scheduleBkLayout(500);
});
(function setupDownloads(){
  try{
    const u = window.claude && window.claude.use ? window.claude.use('downloads') : null;
    if(!u){
      /* Claude 밖(일반 웹사이트)에서는 브라우저 내려받기로 파일을 준다 */
      bkDownloads = {save: async ({filename, data})=>{
        const blob = data instanceof Blob ? data : new Blob([data], {type:'text/html;charset=utf-8'});
        const url = URL.createObjectURL(blob); const a = document.createElement('a');
        a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
        setTimeout(()=>URL.revokeObjectURL(url), 4000); return {status:'saved'};
      }};
    }
    if(u && u.then) u.then(d=>{ bkDownloads = d || null; if(bkDownloads && state.basket && bkView === 'list') renderBasket(); }).catch(()=>{});
  }catch(e){}
})();
