import re
# 지문 원문 속 출전 표기 "-작가, ｢제목｣-" / "-｢제목｣-" 에서 작품·작가를 뽑는다.
PAT = re.compile(r"-\s*(?:([^\s\-–—｢「『,，][^\-–—｢「『\n]{0,24}?)\s*[,，]\s*)?[｢「『]([^｣」』\n]{1,40})[｣」』]\s*-")
def works_in(text):
    out=[]
    for author,title in PAT.findall(text or ""):
        author=re.sub(r"\s+"," ",author).strip()
        title=re.sub(r"\s+"," ",title).strip()
        w=f"{author}, 「{title}」" if author else f"「{title}」"
        if w not in out: out.append(w)
    return out
