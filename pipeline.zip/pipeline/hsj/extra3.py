import json, re, sys, pdfplumber
src = open("/home/claude/hsj/dump.py").read().split("out = {}")[0]
ns = {}; exec(src, ns); lines_page = ns["lines_page"]
H = json.load(open("/home/claude/hsj/hsj_lines.json"))
U = "/root/.claude/uploads/7b612bc6-ce88-5a44-acc7-f627887d12f2/"
for ex, f in [("2023-09", "e282a7a4-2023____9________________.pdf"), ("2023-09#B", "ff4cd4fb-2023____9________________.pdf")]:
    with pdfplumber.open(U + f) as pdf:
        sample = "".join(c["text"] for pg in pdf.pages[1:3] for c in pg.chars)
        hs = sample.count(" ") / max(len(sample), 1) > 0.08
        pages = []; nc = []
        for pg in pdf.pages:
            L, k = lines_page(pg.dedupe_chars(), hs); pages.append(L); nc.append(k)
    H[ex] = {"file": f, "has_space": hs, "pages": pages, "ncol": nc}
    print(ex, hs, len(pages), "".join(map(str, nc)))
json.dump(H, open("/home/claude/hsj/hsj_lines.json", "w"), ensure_ascii=False)
