import json,re
d=json.load(open('ident.json'))
M={}
for n,v in d.items():
    h=re.sub(r'(.)\1\1',r'\1',v.get('head',''))
    m=re.search(r'(20\d\d)학년도',h)
    if not m or 'mun' in n: continue
    y=int(m.group(1))
    if y<2009: continue
    mo='06' if re.search(r'6월',h[:60]) else '09' if re.search(r'9월',h[:60]) else '11'
    form=re.search(r'([AB])\s*형',h[:80])
    ex=f"{y}-{mo}"+(f"-{form.group(1)}" if form and 2014<=y<=2016 else "")
    M.setdefault(ex,[]).append(n)
M.setdefault("2012-06?",[]).append("kor_hsj (3).pdf")
json.dump(M,open('map.json','w'),ensure_ascii=False,indent=0)
for k in sorted(M): print(k,M[k])
