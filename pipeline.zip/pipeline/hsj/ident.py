import pdfplumber,glob,re,json,os
D="/mnt/user-data/uploads/평가원 기출 문제 모음/"
out={}
for f in sorted(glob.glob(D+'*hsj*')+glob.glob(D+'*mun*')):
    n=os.path.basename(f)
    try:
        p=pdfplumber.open(f)
        t=re.sub(r'\s+',' ',p.pages[0].extract_text() or '')
        nch=len(p.pages[0].chars)
        out[n]={"pages":len(p.pages),"chars0":nch,"head":t[:200]}
    except Exception as e: out[n]={"err":str(e)}
    print(n, out[n].get("head","")[:90], flush=True)
json.dump(out,open("/home/claude/hsj/ident.json","w"),ensure_ascii=False,indent=0)
