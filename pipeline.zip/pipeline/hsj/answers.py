import json,re
from collections import defaultdict, Counter
H=json.load(open("hsj_lines.json"))
CIR="①②③④⑤"
ROW=re.compile(r"^[\s　\d\.①-⑤]+$")
PAIR=re.compile(r"(\d{1,2})\s*\.?\s*([①-⑤])")
def tables(ex):
    sec="공통"; res=defaultdict(dict); open_=True
    for pi,L in enumerate(H[ex]["pages"]):
        for l in L:
            t=l["t"]
            if "■" in t or re.match(r"^\[(공통|선택)",t):
                if "화법과 작문" in t: sec="화법과 작문"
                elif "언어와 매체" in t: sec="언어와 매체"
                elif "공통" in t: sec="공통"
                open_=True; continue
            if re.match(r"^\[\s*\d",t): open_=False
            if open_ and ROW.match(t) and PAIR.search(t):
                for n,a in PAIR.findall(t): res[sec][int(n)]=CIR.index(a)+1
    return res
s=open("/home/claude/site_v34.html",encoding="utf-8").read().split("\n")
ITEMS=json.loads([l for l in s if l.startswith("const ITEMS = ")][0][len("const ITEMS = "):].rstrip(";"))
by=defaultdict(dict)
for it in ITEMS:
    sec="공통" if it["exam_id"]>="2022" and it["영역"] in ("독서","문학") else (it["영역"] if it["exam_id"]>="2022" else "공통")
    by[it["exam_id"]][(sec,it["문항번호"])]=it
T={}
for ex in H:
    if "#" in ex: continue
    T[ex]=tables(ex)
    if ex+"#B" in H:
        tb=tables(ex+"#B")
        if "언어와 매체" in tb: T[ex]["언어와 매체"]=tb["언어와 매체"]
json.dump({ex:{sec:v for sec,v in t.items()} for ex,t in T.items()},open("answer_tables.json","w"),ensure_ascii=False)
report=[]
for ex,t in sorted(T.items()):
    exs=[ex] if ex!="2012-06?" else ["2012-06"]
    n=sum(len(v) for v in t.values())
    site=by.get(exs[0],{})
    agree=dis=fill=0; dl=[]
    for (sec,num),it in site.items():
        a=t.get(sec,{}).get(num)
        if a is None: continue
        if it["정답"] is None: fill+=1
        elif it["정답"]==a: agree+=1
        else: dis+=1; dl.append((num,it["영역"],it["정답"],a))
    print(ex, "table",n, {k:len(v) for k,v in t.items()}, "site",len(site),"agree",agree,"DIS",dis,"fillable",fill, dl[:6])
