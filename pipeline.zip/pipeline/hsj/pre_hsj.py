# -*- coding: utf-8 -*-
"""2014학년도 수능 예비시행(A·B형) 해설·정답표를 explains.json, answer_tables.json에 넣는다.
원자료: 이투스청솔 교육평가연구소 「2014 수능 예비시험 정답 및 해설」(사용 허락 받음) → /home/claude/pre/parse.py 결과(pre_explain.json).
answers.py 다음, integrate.py 앞에 돌린다."""
import json
P = json.load(open("/home/claude/pre/pre_explain.json"))
E = json.load(open("/home/claude/hsj/explains.json"))
T = json.load(open("/home/claude/hsj/answer_tables.json"))
NOTE = "\n※ 2014학년도 예비 시행의 정답과 해설은 이투스청솔 교육평가연구소의 「2014 수능 예비시험 정답 및 해설」에서 옮겼습니다(평가원 공식 해설이 아닙니다)."
for ex, D in P.items():
    items = []
    for x in D["items"]:
        assert x["ans"] == D["table"][str(x["num"])], (ex, x["num"])   # 문항별 정답 표기 = 정답표
        items.append({**x, "text": x["text"] + NOTE})
    E[ex] = {"items": items, "sets": []}
    T[ex] = {"공통": {k: v for k, v in D["table"].items()}}
    print(ex, len(items), "answers", len(D["table"]))
json.dump(E, open("/home/claude/hsj/explains.json", "w"), ensure_ascii=False)
json.dump(T, open("/home/claude/hsj/answer_tables.json", "w"), ensure_ascii=False)
