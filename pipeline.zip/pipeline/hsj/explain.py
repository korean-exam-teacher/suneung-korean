import json,re
from collections import defaultdict
H=json.load(open("/home/claude/hsj/hsj_lines.json"))
CIR="①②③④⑤"
SETH=re.compile(r"^\[\s*(\d{1,2})\s*[~～\-–]\s*(\d{1,2})\s*\]\s*(.*)$")
ITEMH=re.compile(r"^(\d{1,2})\s*\.\s*(.*)$")
ROW=re.compile(r"^[\s　\d\.①-⑤]+$")
ANS=re.compile(r"(?:\[정답\]|정답|\[답\])\s*:?\s*([①-⑤])")
def join(lines):
    out=""
    for i,l in enumerate(lines):
        t=l["t"]
        if not out: out=t; continue
        p=lines[i-1]
        if re.match(r"^(\[오답피하기\]|정답해설|\[정답해설\]|지문해설|\[지문해설\]|\[보기\s*해설\])",t): out+="\n"+t; continue
        if p.get("endsp") is True or re.search(r"[.?!,:;)\]』」’”]$",p["t"]) or p.get("short"): out+=" "+t
        elif p.get("endsp") is False: out+=t
        else: out+=" "+t
    out = re.sub(r"\s?20\d\d학년도 대학수학능력시험[^.。]{0,40}?정답 및 해설(\s*\(홀수형\))?\s?", " ", out)
    return out.replace("\u3000"," ").replace("  "," ")
def parse(ex):
    pages=H[ex]["pages"]
    seq=[]
    for pi_, L in enumerate(pages):
        if not L: continue
        mxs={}
        for l in L: mxs[l["side"]]=max(mxs.get(l["side"],0),l["x1"])
        for j,l in enumerate(L):
            if re.fullmatch(r"-?\s*\d{1,2}\s*-?",l["t"]): continue   # 쪽 번호
            if pi_ > 0 and re.match(r"^20\d\d학년도 .{0,40}(정답 및 해설|해설)", l["t"]) and len(l["t"]) < 70: continue   # 쪽 머리글
            l=dict(l); l["short"]= l["x1"] < mxs[l["side"]]-25
            seq.append(l)
    sec="공통"; cur=None; items=[]; sets=[]; curset=None
    started=False
    for i,l in enumerate(seq):
        t=l["t"]
        if "■" in t and ("공통" in t or "선택" in t):
            sec="화법과 작문" if "화법과 작문" in t else "언어와 매체" if "언어와 매체" in t else "공통"; cur=None; continue
        if ROW.match(t): continue
        m=SETH.match(t)
        if m:
            a,b=int(m.group(1)),int(m.group(2))
            curset={"sec":sec,"range":(a,b),"head":m.group(3),"lines":[]}; sets.append(curset); cur=None; started=True; continue
        m=ITEMH.match(t)
        if m and started:
            n=int(m.group(1)); rest=m.group(2)
            nxt=seq[i+1]["t"] if i+1<len(seq) else ""
            looks = ("정답해설" in rest or "정답해설" in nxt or re.match(r"^\[?정답",nxt) or "[출제의도]" in nxt or "[출제 의도]" in nxt)
            inset = any(x["sec"]==sec and x["range"][0]<=n<=x["range"][1] for x in sets[-3:]) or (items and items[-1]["sec"]==sec and n==items[-1]["num"]+1)
            if looks and (inset or not curset):
                cur={"sec":sec,"num":n,"label":rest.strip(),"lines":[]}; items.append(cur); continue
        if cur is not None: cur["lines"].append(l)
        elif curset is not None: curset["lines"].append(l)
    res=[]
    for it in items:
        body=join(it["lines"])
        a=ANS.search(body)
        res.append({"sec":it["sec"],"num":it["num"],"label":it["label"],"ans":CIR.index(a.group(1))+1 if a else None,"text":body})
    st=[{"sec":s["sec"],"range":s["range"],"head":s["head"],"text":join(s["lines"])} for s in sets]
    return res,st
if __name__=="__main__":
    import sys
    r,s=parse(sys.argv[1])
    print(len(r),"items",[ (x["sec"][:2],x["num"]) for x in r])
    for x in r[:3]: print(x["num"],x["label"],x["ans"],"\n",x["text"][:500],"\n")
    print(s[0]["head"], s[0]["text"][:300])
