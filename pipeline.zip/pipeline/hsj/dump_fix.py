import sys, json, pdfplumber, re
M = json.load(open("/home/claude/hsj/map.json"))
D = "/mnt/user-data/uploads/평가원 기출 문제 모음/"

def lines_page(pg, has_space):
    chars = list(pg.chars)
    if not chars: return [], 1
    mid = pg.width/2
    band = sum(1 for c in chars if mid-12 < (c["x0"]+c["x1"])/2 < mid+12 and c["text"].strip())
    two = (band < 0.004*len(chars)) and not FORCE1
    cols = {"L": [], "R": []} if two else {"F": []}
    for c in chars:
        k = ("L" if c["x0"] < mid else "R") if two else "F"
        cols[k].append(c)
    out = []
    for side, cs in cols.items():
        cs = sorted(cs, key=lambda c: c["top"]); cl = []
        for c in cs:
            if cl and c["top"]-cl[-1][0] <= 4: cl[-1][1].append(c)
            else: cl.append([c["top"], [c]])
        for top, g in cl:
            g.sort(key=lambda c: c["x0"])
            gaps = sorted(b["x0"]-a["x1"] for a, b in zip(g, g[1:]) if a["text"] != " " and b["text"] != " ")
            med = gaps[len(gaps)//2] if gaps else 0
            t = ""; prev = None
            for c in g:
                if prev is not None and c["text"] != " " and not t.endswith(" "):
                    gap = c["x0"]-prev["x1"]
                    thr = med+0.3*c["size"] if has_space else max(1.0, med+0.15*c["size"])
                    if gap > thr: t += " "
                t += c["text"]; prev = c
            vis = [c for c in g if c["text"].strip()]
            if not vis: continue
            out.append({"t": re.sub(r" {2,}", " ", t).strip(), "endsp": (g[-1]["text"] == " ") if has_space else None,
                        "x0": round(vis[0]["x0"], 1), "x1": round(vis[-1]["x1"], 1), "top": round(top, 1), "side": side,
                        "size": round(vis[0]["size"], 1)})
    return out, 2 if two else 1

FORCE1=False
out = json.load(open("/home/claude/hsj/hsj_lines.json"))
for ex, files in sorted(M.items()):
    if ex not in ("2017-11","2018-06","2018-11"): continue
    FORCE1=True
    f = files[0]
    with pdfplumber.open(D+f) as pdf:
        sample = "".join(c["text"] for pg in pdf.pages[1:3] for c in pg.chars)
        hs = sample.count(" ")/max(len(sample), 1) > 0.08
        pages = []; ncol = []
        for pg in pdf.pages:
            L, nc = lines_page(pg.dedupe_chars(), hs); pages.append(L); ncol.append(nc)
    out[ex] = {"file": f, "has_space": hs, "pages": pages, "ncol": ncol, "width": 0}
    print(ex, f, hs, len(pages), "".join(map(str, ncol)), flush=True)
json.dump(out, open("/home/claude/hsj/hsj_lines.json", "w"), ensure_ascii=False)
