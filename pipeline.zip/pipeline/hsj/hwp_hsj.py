import json, re
P = json.load(open("/home/claude/hwp/hwp_paras.json"))["2018-06H"]
L = [t.replace("　", " ").strip() for lvl, t in P]
CIR = "①②③④⑤"
items = []; sets_pending = []; sets = []
i = 0
while i < len(L):
    if L[i] == "[해설]":
        label = L[i+1] if i+1 < len(L) else ""
        j = i + 2; body = []
        while j < len(L):
            t = L[j]
            if t.startswith(("정답해설", "[정답해설]", "[오답피하기]", "[오답 피하기]", "지문해설", "지문 해설", "작품해설", "(가)", "(나)", "(다)")) or (body and not t.startswith("[문항코드]") and False):
                body.append(t); j += 1; continue
            break
        txt = "\n".join(body)
        if body and body[0].startswith(("정답해설", "[정답해설]")):
            m = re.search(r"정답\s*([①-⑤])", txt)
            items.append({"sec": "공통", "num": len(items)+1, "label": label, "ans": CIR.index(m.group(1))+1 if m else None, "text": txt})
        else:
            sets_pending.append({"before": len(items)+1, "head": label, "text": txt})
        i = j; continue
    i += 1
print(len(items), [ (x["num"], x["ans"]) for x in items][:10], len(sets_pending))
T = json.load(open("/home/claude/hsj/answer_tables.json"))["2018-06"]["공통"]
mis = [(x["num"], x["ans"], T[str(x["num"])]) for x in items if x["ans"] and x["ans"] != T[str(x["num"])]]
print("answer mismatches", mis, "no ans", [x["num"] for x in items if not x["ans"]])
# 지문 해설: 다음 문항 번호가 속한 사이트 지문범위에 붙인다
s = open("/home/claude/site_v35.html", encoding="utf-8").read().split("\n")
ITEMS = json.loads([l for l in s if l.startswith("const ITEMS = ")][0][len("const ITEMS = "):].rstrip(";"))
rng = {i["문항번호"]: i["지문범위"] for i in ITEMS if i["exam_id"] == "2018-06"}
for sp in sets_pending:
    r = rng.get(sp["before"])
    if r and "~" in r:
        a, b = map(int, r.split("~"))
        sets.append({"sec": "공통", "range": [a, b], "head": sp["head"], "text": sp["text"] if sp["text"].startswith(("지문","작품")) else sp["text"]})
print([(x["range"], x["head"][:25], x["text"][:40]) for x in sets])
E = json.load(open("/home/claude/hsj/explains.json"))
E["2018-06"] = {"items": items, "sets": sets}
json.dump(E, open("/home/claude/hsj/explains.json", "w"), ensure_ascii=False)
