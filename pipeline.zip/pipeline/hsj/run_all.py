import json,sys
sys.path.insert(0,"/home/claude/hsj")
from explain import parse, H
from collections import Counter
OUT={}
for ex in sorted(H):
    r,s=parse(ex); OUT[ex]={"items":r,"sets":s}
    c=Counter(x["sec"] for x in r)
    nums=[x["num"] for x in r if x["sec"]=="공통"]
    noans=sum(1 for x in r if x["ans"] is None)
    print(ex, dict(c), "noans",noans, "dup",len(nums)-len(set(nums)), "missing", sorted(set(range(min(nums or[1]),max(nums or[1])+1))-set(nums))[:12])
json.dump(OUT,open("/home/claude/hsj/explains.json","w"),ensure_ascii=False)
