# -*- coding: utf-8 -*-
"""정답 및 해설(원자료)로 정답·유형·해설을 사이트 데이터에 반영한다.
입력: site_v34.html, explains.json, answer_tables.json  →  출력: integ.json"""
import json, re, sys
from collections import Counter, defaultdict
sys.path.insert(0, "/home/claude/typegroup")
import type_groups as TG

s = open("/home/claude/site_v34.html", encoding="utf-8").read().split("\n")
def load(n): return json.loads([l for l in s if l.startswith(f"const {n} = ")][0][len(f"const {n} = "):].rstrip(";"))
ITEMS = load("ITEMS"); PASSAGES = load("PASSAGES"); CHOICES = load("CHOICES")
E = json.load(open("/home/claude/hsj/explains.json"))
T = json.load(open("/home/claude/hsj/answer_tables.json"))

def hkey(ex): return "2012-06?" if ex == "2012-06" else ex
def sec_of(it):
    if it["exam_id"] >= "2022": return "공통" if it["영역"] in ("독서", "문학") else it["영역"]
    return "공통"
def src_for(it):
    k = hkey(it["exam_id"])
    if it["exam_id"] >= "2022" and it["영역"] == "언어와 매체": k += "#B"
    return E.get(k)

# ---------- 해설 유형 이름 → 유형 묶음 ----------
def has(t, *ws): return any(w in t for w in ws)
ALLOWED = {"독서": {"독서"}, "문학": {"문학"}, "화법과 작문": {"화법", "작문"}, "언어와 매체": {"문법", "매체"}}
def label_group(label, it):
    area = it["영역"]
    if label in TG.RAW_MAP and TG.GROUP_OF.get(TG.RAW_MAP[label]) in ALLOWED.get(area, set()):
        g = TG.RAW_MAP[label]
        # 화법과 작문 영역에서는 지문 분야(화법/작문)와 묶음이 어긋나면 키워드 규칙으로 다시 판정
        indep = it.get("지문범위") == "(독립 문항)"
        if area != "화법과 작문" or indep or (TG.GROUP_OF[g] == "화법") == str(it.get("분야", "")).startswith("화법"):
            return g
    t = label
    if area == "독서":
        if has(t, "어휘", "단어의 의미", "바꿔 쓰", "바꾸어 쓰", "사전적 의미", "문맥적 의미"): return "어휘의 문맥적 의미"
        if has(t, "전개 방식", "서술 방식", "글의 구조", "전개 양상", "서술상"): return "글의 구조·전개 방식"
        if has(t, "관점", "견해", "입장"): return "견해·관점 비교"
        if has(t, "적용", "사례", "상황"): return "구체적 사례·상황 적용"
        if has(t, "비판", "평가", "타당", "반박", "비평"): return "비판적 이해·평가"
        if has(t, "관계", "인과", "상관", "비교", "대조"): return "정보 간의 관계 파악"
        if has(t, "추론", "미루어", "추리", "전제"): return "내용 추론"
        if has(t, "독서 방법", "읽기 방법", "독서 활동", "독서 과정", "읽기 과정", "독서의 방법"): return "독서 방법·활동"
        if has(t, "세부", "핵심", "중심", "정보", "일치", "내용 파악", "내용 이해", "내용 확인", "화제"): return "세부·핵심 내용 파악"
        return None
    if area == "문학":
        if has(t, "외적 준거", "외재적", "<보기>", "보기를"): return "외적 준거에 따른 감상"
        if has(t, "공통점", "차이점", "작품 간", "작품의 비교", "비교"): return "작품 간 비교"
        if has(t, "화자", "서술자", "어조", "정서"): return "화자·서술자의 태도·정서"
        if has(t, "인물", "심리", "성격"): return "인물의 심리·태도·성격"
        if has(t, "표현", "서술상", "서술 방식", "서술의 특징", "수사", "형식", "구성"): return "표현·서술상의 특징"
        if has(t, "시어", "시구", "구절", "어구", "단어의 의미", "의미 파악"): return "시어·시구·구절의 의미"
        if has(t, "소재", "배경", "기능", "역할", "공간"): return "소재·배경의 기능"
        if has(t, "주제", "작가", "의도"): return "주제 의식·작가의 관점"
        if has(t, "감상", "반응", "수용", "평가", "이해와 감상"): return "작품 감상·수용"
        if has(t, "내용", "상황", "사건", "종합적 이해", "이해", "줄거리"): return "작품 내용·상황 이해"
        return None
    if area == "화법과 작문":
        f = "" if it.get("지문범위") == "(독립 문항)" else str(it.get("분야", ""))
        speech = f.startswith("화법") if (f.startswith("화법") or f.startswith("작문")) and not f.startswith("화법·작문") and not f.startswith("화법과 작문") else \
                 has(t + it["발문"], "말하기", "듣기", "화법", "토론", "토의", "발표", "대화", "면접", "협상", "강연", "연설", "청중", "발화", "담화")
        if speech:
            if has(t, "자료", "매체"): return "화법: 자료·매체 활용"
            if has(t, "계획", "내용 생성", "조직", "구성"): return "화법: 내용 생성·조직"
            if has(t, "전략", "방식", "표현", "태도"): return "화법: 말하기 방식·표현 전략"
            return "화법: 내용 이해·평가"
        if has(t, "고쳐", "퇴고", "수정", "점검", "비문", "어휘 선택", "문장 다듬"): return "작문: 점검·고쳐쓰기"
        if has(t, "자료"): return "작문: 자료·매체 활용"
        if has(t, "계획", "맥락", "독자", "목적"): return "작문: 계획·맥락 반영"
        if has(t, "표현", "조건", "전략", "제목", "글쓰기"): return "작문: 표현 전략"
        if has(t, "내용 생성", "개요", "조직", "내용", "생성"): return "작문: 내용 생성·조직"
        return None
    if area == "언어와 매체":
        if has(t, "매체"):
            if has(t, "표현"): return "매체 언어의 표현 방법"
            if has(t, "수용", "제작", "생산"): return "매체 자료의 수용·제작"
            return "매체의 특성·정보 구성"
        if has(t, "음운", "발음", "음절", "자음", "모음"): return "음운·음운 변동"
        if has(t, "중세", "국어사", "변천", "옛", "고대", "근대 국어", "훈민정음"): return "중세 국어·국어의 변천"
        if has(t, "맞춤법", "표준어", "표기", "로마자", "외래어", "띄어쓰기", "사이시옷", "어문 규범"): return "한글 맞춤법·표준어 규정"
        if has(t, "형태소", "단어 형성", "단어의 형성", "파생", "합성", "조어", "단어의 구조"): return "형태소·단어 형성"
        if has(t, "높임", "시제", "시간 표현", "피동", "사동", "부정 표현", "문법 요소", "인용", "종결 표현"): return "문법 요소"
        if has(t, "문장 성분", "문장의 짜임", "안은", "이어진", "홑문장", "겹문장", "서술어", "자릿수", "문장 구조", "문장의 구조"): return "문장 성분·문장의 짜임"
        if has(t, "품사", "용언", "활용", "어미", "조사", "체언"): return "품사·용언의 활용"
        if has(t, "의미 관계", "어휘", "다의어", "동음이의어", "반의어", "유의어", "사전", "단어의 의미"): return "어휘와 의미"
        if has(t, "담화", "지시 표현"): return "담화의 특성"
        return None
    return None

# 역량: 같은 유형 묶음 문항에 절반 이상 붙은 역량
gs = defaultdict(Counter); gn = Counter()
for it in ITEMS:
    if it["exam_id"] >= "2022":
        gn[it["유형묶음"]] += 1
        for sk in it.get("역량", []): gs[it["유형묶음"]][sk] += 1
SKILL_OF = {g: [sk for sk, c in gs[g].most_common() if c >= gn[g]*0.5] for g in gn}

# 새로 합류하는 회차(HWP 문제지: 2009 수능, 2014 수능 A/B)
NB = json.load(open("/home/claude/hwp/new_bundle.json"))
for it in NB["items"]:
    ch = NB["choices"].get(f'{it["exam_id"]}||{it["영역"]}||{it["문항번호"]}')
    it["유형"] = "미분류(수동 확인 필요)"
    g, _ = TG.group_for(it, ch)
    if g == "미분류":
        g = "화법: 내용 이해·평가" if it["영역"] == "화법과 작문" and str(it.get("분야","")).startswith("화법") else ("작문: 내용 생성·조직" if it["영역"] == "화법과 작문" else g)
    it["유형묶음"] = g; it["유형갈래"] = TG.GROUP_OF.get(g, "미분류")
    it["역량"] = SKILL_OF.get(g, [])
    it["개편매핑_과목"] = ("독서와 작문" if it["영역"] == "독서" else "문학" if it["영역"] == "문학" else "화법과 언어" if it["영역"] == "언어와 매체" else ("화법과 언어" if g.startswith("화법") else "독서와 작문"))
    ITEMS.append(it)
PASSAGES.update(NB["passages"])

stat = Counter(); changes = []; EXPLAIN = {}; LABELMISS = Counter()
for it in ITEMS:
    ex = it["exam_id"]; key = f'{ex}||{it["영역"]}||{it["문항번호"]}'
    sec = sec_of(it)
    # 1) 정답
    tb = T.get(hkey(ex), {}).get(sec, {})
    a = tb.get(str(it["문항번호"]))
    if a:
        if it["정답"] is None: it["정답"] = a; stat["answer filled"] += 1; changes.append((key, None, a))
        elif it["정답"] != a:
            src0 = src_for(it); ea = None
            if src0:
                c = [x for x in src0["items"] if x["num"] == it["문항번호"] and x["sec"] == sec]
                if len(c) == 1: ea = c[0]["ans"]
            if ea == it["정답"]:
                stat["table typo kept existing"] += 1   # 해설 본문 정답과 기존 정답이 같으면 정답표 쪽 오타로 본다
            else:
                changes.append((key, it["정답"], a)); it["정답"] = a; stat["answer corrected"] += 1
        else: stat["answer same"] += 1
        it["_정답출처"] = "이투스청솔 정답 및 해설(예비 시행)" if "예비" in ex else "정답및해설(원자료)"
    else:
        stat["answer no table"] += 1
    # 2) 해설
    src = src_for(it)
    hit = None
    if src:
        cands = [x for x in src["items"] if x["num"] == it["문항번호"] and x["sec"] == sec]
        if len(cands) == 1: hit = cands[0]
    if not hit: stat["no explanation"] += 1; continue
    if hit["ans"] and a and hit["ans"] != a: stat["explain-answer conflict"] += 1
    txt = hit["text"].strip()
    if len(txt) >= 40: EXPLAIN[key] = txt; stat["explanation"] += 1
    # 3) 유형 (2009~2021학년도만: 2022~는 이미 원자료로 확인됨)
    if ex < "2022" and hit["label"] and len(hit["label"]) <= 60:
        lab = re.sub(r"\s+", " ", hit["label"]).strip(" .")
        g = label_group(lab, it)
        it["유형_해설확인"] = lab
        if g:
            old = it["유형묶음"]
            it["유형"] = lab; it["유형묶음"] = g; it["유형갈래"] = TG.GROUP_OF.get(g, it["유형갈래"])
            it["_유형출처"] = "정답및해설(원자료)"
            it.pop("_유형재분류", None); it.pop("_ebs_매칭", None); it.pop("유형_EBS", None)
            if old != g:
                stat["group changed"] += 1
                it["역량"] = SKILL_OF.get(g, it.get("역량", []))
            stat["type verified"] += 1
        else:
            LABELMISS[(it["영역"], lab)] += 1; stat["label unmapped"] += 1

# 독립 문항의 분야·소재는 최종 유형 묶음에 맞춘다(화법 독립 문항이 '작문'으로 잘못 붙어 있던 것 바로잡기)
for it in ITEMS:
    if it["지문범위"] != "(독립 문항)" or it["exam_id"] >= "2018": continue
    g = it["유형묶음"]
    if it["영역"] == "화법과 작문":
        f = "화법(독립 문항)" if g.startswith("화법") else "작문(독립 문항)"
        if it.get("분야") != f: stat["indep field fixed"] += 1
        it["분야"] = f
    elif it["영역"] == "언어와 매체":
        it["분야"] = "문법(독립 문항)"
    it["소재"] = f"{g.replace('화법: ','').replace('작문: ','')} (독립 문항)"
    it["개편매핑_과목"] = "화법과 언어" if it["영역"] == "언어와 매체" or g.startswith("화법") else "독서와 작문"

# 2018~2021학년도: 공식 해설 유형 이름을 못 얻은 문항은 EBS 대조 결과도 믿기 어려우므로 '유형 확인' 표시를 뗀다
for it in ITEMS:
    if "2018" <= it["exam_id"] < "2022" and it.get("_유형출처") != "정답및해설(원자료)":
        if it.get("_유형출처") or it.get("_ebs_매칭"):
            it["_유형재분류"] = True; stat["2018-21 ebs type unverified"] += 1

# 해설 원문의 정답 표기가 정답표와 다르면(해설 쪽 오기) 안내를 붙인다
CIRC = "①②③④⑤"
for it in ITEMS:
    key = f'{it["exam_id"]}||{it["영역"]}||{it["문항번호"]}'
    t = EXPLAIN.get(key)
    if not t or not it["정답"]: continue
    m = re.search(r"(?:\[정답\]|정답|\[답\])\s*:?\s*([①-⑤])", t)
    if m and CIRC.index(m.group(1)) + 1 != it["정답"]:
        EXPLAIN[key] = t + f"\n※ 해설 원문에 적힌 정답({m.group(1)})이 정답표의 정답({CIRC[it['정답']-1]})과 다릅니다. 해설 원문의 오기로 보이며, 정답표 기준 정답은 {CIRC[it['정답']-1]}입니다."
        stat["explain answer typo noted"] += 1; print("typo note", key, m.group(1), it["정답"])

# 지문 해설
PEXPLAIN = {}
area_of = {}
for it in ITEMS: area_of[(it["exam_id"], sec_of(it), it["문항번호"])] = it["영역"]
for ex in sorted({i["exam_id"] for i in ITEMS}):
    for k in [hkey(ex), hkey(ex) + "#B"]:
        if k not in E: continue
        for st in E[k]["sets"]:
            if "지문해설" not in st["text"][:20]: continue
            a, b = st["range"]
            area = area_of.get((ex, st["sec"], a))
            if not area: continue
            pk = f"{ex}||{area}||{a}~{b}"
            if pk in PASSAGES and pk not in PEXPLAIN:
                PEXPLAIN[pk] = st["text"].strip()
print(stat); print("passage explanations", len(PEXPLAIN))
print("unmapped labels", len(LABELMISS)); print(LABELMISS.most_common(40))
json.dump({"items": ITEMS, "explain": EXPLAIN, "pexplain": PEXPLAIN, "changes": changes}, open("/home/claude/hsj/integ.json", "w"), ensure_ascii=False)
