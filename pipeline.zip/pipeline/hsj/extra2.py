import json, re, sys, pdfplumber
sys.path.insert(0, "/home/claude/hsj")
src = open("/home/claude/hsj/dump.py").read().split("out = {}")[0]
ns = {}; exec(src, ns); lines_page = ns["lines_page"]
H = json.load(open("/home/claude/hsj/hsj_lines.json"))
# 2018 수능 해설: 글꼴에 유니코드 정보가 없던 글자(문맥으로 확정 가능한 것만 치환, 나머지는 □)
CID_FIX = {"24858": "「", "24859": "」", "24786": " :", "24788": "<", "1347": "艱", "3664": "風", "3268": "霜", "3152": "隨", "2948": "關"}
def clean(t):
    return re.sub(r"\(cid:(\d+)\)", lambda m: CID_FIX.get(m.group(1), "□"), t)
for ex, path in [("2012-11", "/home/claude/fixpdf/2012-11_fixed.pdf"), ("2018-11", "/home/claude/fixpdf/2018-11_fixed.pdf")]:
    with pdfplumber.open(path) as pdf:
        sample = "".join(c["text"] for pg in pdf.pages[1:3] for c in pg.chars)
        hs = sample.count(" ") / max(len(sample), 1) > 0.08
        pages = []
        for pg in pdf.pages:
            L = lines_page(pg.dedupe_chars(), hs)[0]
            for l in L: l["t"] = clean(l["t"])
            pages.append(L)
    H[ex] = {"file": path, "has_space": hs, "pages": pages, "ncol": [1]*len(pages)}
    print(ex, hs, len(pages))
json.dump(H, open("/home/claude/hsj/hsj_lines.json", "w"), ensure_ascii=False)
