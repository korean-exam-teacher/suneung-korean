import json, re, sys, pdfplumber
sys.path.insert(0, "/home/claude/hsj"); sys.path.insert(0, "/home/claude/hwp")
import importlib.util
spec = importlib.util.spec_from_file_location("dumpmod", "/home/claude/hsj/dump.py")
src = open("/home/claude/hsj/dump.py").read().split("out = {}")[0]
ns = {}; exec(src, ns); lines_page = ns["lines_page"]
D = "/mnt/user-data/uploads/평가원 기출 문제 모음/"
H = json.load(open("/home/claude/hsj/hsj_lines.json"))
with pdfplumber.open(D + "2017학년도 수능 해설(ebs).pdf") as pdf:
    sample = "".join(c["text"] for pg in pdf.pages[1:3] for c in pg.chars)
    hs = sample.count(" ") / max(len(sample), 1) > 0.08
    pages = [lines_page(pg.dedupe_chars(), hs)[0] for pg in pdf.pages]
H["2017-11"] = {"file": "2017학년도 수능 해설(ebs).pdf", "has_space": hs, "pages": pages, "ncol": [1]*len(pages)}
json.dump(H, open("/home/claude/hsj/hsj_lines.json", "w"), ensure_ascii=False)
from explain import parse
import explain; explain.H = H
r, s = parse("2017-11")
print(len(r), [x["num"] for x in r], sum(1 for x in r if x["ans"]))
print(r[0]["label"], r[0]["text"][:200])
print([(x["range"], x["head"][:30]) for x in s if "지문해설" in x["text"][:10]][:12])
