# -*- coding: utf-8 -*-
"""merge_v38 → 남은 □ 되살리기(2차) + 지문·<보기> 낱말 자리 바로잡기 → site_v39.html
1) chk/pass2.json: 원본 글자 흐름(옛한글 판독표로 바꾼 것)과 앞뒤 맥락이 한 곳에서만 맞는 □ 자리
2) chk/movefix.json: 원본(글자 좌표로 다시 읽은 줄)과 낱말 단위로 맞추어, 자리가 밀린 낱말을 원래 자리로 옮기고 □를 채움
3) chk/manual39.json: 원본 그림을 보고 직접 판독한 □와 오류(문자열 바꾸기, 반드시 한 곳만 맞아야 함)"""
import json, re, subprocess, sys, os
STAGE = sys.argv[1] if len(sys.argv) > 1 else "all"
if not os.environ.get("SKIP_V38"): subprocess.run(["python3", "/home/claude/merge_v38.py"], check=True)
SRC = "/home/claude/site_v38.html"; DST = "/home/claude/site_v39.html"
lines = open(SRC, encoding="utf-8").read().split("\n")
def idx(n): return [k for k, l in enumerate(lines) if l.startswith(f"const {n} = ")][0]
def load(n): return json.loads(lines[idx(n)][len(f"const {n} = "):].rstrip(";"))
def save(n, v): lines[idx(n)] = f"const {n} = " + json.dumps(v, ensure_ascii=False) + ";"
ITEMS = load("ITEMS"); CHO = load("CHOICES"); PAS = load("PASSAGES")
IT = {f'{i["exam_id"]}||{i["영역"]}||{i["문항번호"]}': i for i in ITEMS}
def get(kind, key, num):
    if kind == "선지": return CHO[key][num - 1]
    if kind == "지문": return PAS[key]
    return IT[key][kind]
def put(kind, key, num, v):
    if kind == "선지": CHO[key][num - 1] = v
    elif kind == "지문": PAS[key] = v
    else: IT[key][kind] = v
# 1) pass2
P = json.load(open("/home/claude/chk/pass2.json")); n1 = 0; sk = []
by = {}
for r in P: by.setdefault((r["kind"], r["key"], r["num"]), []).append(r)
for k, rs in by.items():
    t = get(*k)
    for r in sorted(rs, key=lambda r: -r["pos"]):
        p, ln = r["pos"], len(r["run"])
        if t[p:p + ln] != r["run"] or (r["L"] and not t[:p].endswith(r["L"])): sk.append(r); continue
        t = t[:p] + r["rep"] + t[p + ln:]; n1 += 1
    put(*k, t)
print("pass2", n1, "skipped", len(sk))
if STAGE == "A":
    json.dump({"CHO": CHO, "PAS": PAS, "BOGI": {k: v.get("보기") for k, v in IT.items() if v.get("보기")}}, open("/home/claude/chk/v39A.json", "w"), ensure_ascii=False)
    sys.exit(0)
# 2) 지문 낱말 자리·옛한글 띄어쓰기·□ 채우기 (chk/movefix.py 결과). 원본 쪽 글자 흐름이 표·그림 배치 때문에 믿기 어려운 지문은 뺀다
EXCL = {"2022-06||언어와 매체||40~42", "2022-11||언어와 매체||44~45", "2025-09||언어와 매체||43~45", "2027-06||독서||10~13", "2027-09||화법과 작문||43~45", "2021-09||화법과 작문||8~10"}
MV = json.load(open("/home/claude/chk/movefix.json")); n2 = 0
for uk, v in MV.items():
    kind, key = uk.split("||", 1)
    if key in EXCL: continue
    if kind == "지문": PAS[key] = v; n2 += 1
print("movefix units", n2)
# 2-1) 문학 지문(2018~): 원본 줄에서 시행·연·각주 줄을 다시 짬(chk/rebuild.py). 글자 꾸러미가 같을 때만
RB = json.load(open("/home/claude/chk/rebuild.json")); n21 = 0
for key, r in RB.items():
    if r["ok"] and int(key[:4]) >= 2018 and key.split("||")[1] == "문학": PAS[key] = r["new"]; n21 += 1
print("rebuild units", n21)
# 3) 직접 판독
MAN = json.load(open("/home/claude/chk/manual39.json")); n3 = 0; miss = []
for kind, key, num, old, new, why in MAN:
    t = get(kind, key, num)
    if old == "*": put(kind, key, num, new); n3 += 1; continue
    c = t.count(old)
    if c == 1: put(kind, key, num, t.replace(old, new)); n3 += 1
    elif new in t: pass
    else: miss.append((kind, key, num, old, c))
print("manual", n3, "miss", len(miss))
for m in miss: print("  MISS", m)
# 4) <보기> 낱말 자리 바로잡기(2018~, 원본 대조로 맞는 것만 골라 씀)
BACC = {"2027-06||화법과 작문||39", "2027-06||언어와 매체||38", "2027-09||언어와 매체||36", "2022-11||독서||8", "2022-11||화법과 작문||45", "2022-11||언어와 매체||39", "2023-09||언어와 매체||41", "2023-11||언어와 매체||37", "2023-11||언어와 매체||38", "2023-11||언어와 매체||44", "2024-06||언어와 매체||36", "2024-06||언어와 매체||39", "2024-09||언어와 매체||42", "2024-11||독서||7", "2024-11||화법과 작문||45", "2024-11||언어와 매체||37", "2025-06||문학||20", "2025-09||문학||27", "2025-09||독서||6", "2018-06||독서||23", "2018-09||독서||28", "2019-09||언어와 매체||12", "2019-09||언어와 매체||14", "2019-09||독서||24", "2019-11||화법과 작문||4", "2019-11||독서||31", "2021-09||독서||29"}
MB = json.load(open("/home/claude/chk/movefix_bogi.json")); n4 = 0
for uk, v in MB.items():
    kind, key = uk.split("||", 1)
    if key in BACC: IT[key]["보기"] = v; n4 += 1
print("bogi moves", n4)
if STAGE == "B":
    json.dump({"CHO": CHO, "PAS": PAS, "BOGI": {k: v.get("보기") for k, v in IT.items() if v.get("보기")}}, open("/home/claude/chk/v39B.json", "w"), ensure_ascii=False)
    sys.exit(0)
# 4-1) 줄 구조 맞추기(chk/linesync.py): 사이트 글자는 그대로 두고 원본 줄의 줄바꿈·연 나눔을 옮김(문학),
#      원본에서 낱말 중간에 줄이 바뀐 자리에 잘못 들어간 띄어쓰기를 붙임(모든 지문; 원본 줄 끝 공백 기록 이용)
LS = json.load(open("/home/claude/chk/linesync.json")); n41 = 0; n41l = 0
for key, r in LS.items():
    if not r["ok"] or key in EXCL or key in {"2024-09||언어와 매체||44~45", "2022-09||언어와 매체||44~45", "2022-11||언어와 매체||44~45", "2023-06||언어와 매체||40~43"}: continue
    if RB.get(key, {}).get("ok") and int(key[:4]) >= 2018 and key.split("||")[1] == "문학": continue
    PAS[key] = r["new"]; n41 += 1; n41l += bool(r.get("lit"))
# 원본 줄 끝 공백 기록이 빠져 있던 몇 곳(화면 구성 지문 등)은 띄어쓰기를 되돌린다
LSX = {"2024-09||언어와 매체||44~45", "2022-09||언어와 매체||44~45", "2022-11||언어와 매체||44~45", "2023-06||언어와 매체||40~43"}
for key in LSX:
    if key in LS and LS[key]["ok"]: pass
for a, b in [("대상으로고르면", "대상으로 고르면"), ("문장을말한다", "문장을 말한다"), ("예술가의마음을", "예술가의 마음을"), ("문제인가우리", "문제인가 우리")]:
    for key in PAS:
        if a in PAS[key]: PAS[key] = PAS[key].replace(a, b)
print("linesync units", n41, "literature", n41l)
# 5) 마무리 손질
k = "2023-11||언어와 매체||37"; b = IT[k]["보기"]
assert b.count("내용이다. 에서 ⓐ") == 1
b = b.replace("내용이다. 에서 ⓐ", "내용이다. [자료]에서 ⓐ")
if "[자료] ᄢᅵ니" not in b: b = b.rstrip() + "\n[자료] ᄢᅵ니, 붇, 사ᄫᅵ, 스ᄀᆞᄫᆞᆯ, ᄧᆞᆨ, ᄒᆞᆰ"
IT[k]["보기"] = b
# 지수(위 첨자)가 숫자로 풀려 버린 곳, 낱말 풀이(각주) 손질
SUP = str.maketrans("0123456789-", "⁰¹²³⁴⁵⁶⁷⁸⁹⁻")
def exps(t):
    t = re.sub(r"×10-(\d{1,2})(?=[가-힣a-zA-Z·])", lambda m: "×10" + ("-" + m.group(1)).translate(SUP), t)
    t = re.sub(r"(?<![\d.×])10-9(?=토르)", "10⁻⁹", t)
    t = t.replace("6.02×1023개", "6.02×10²³개").replace("3.086×1013km", "3.086×10¹³km")
    return t
nx = 0
for key in PAS:
    v = exps(PAS[key]); nx += v != PAS[key]; PAS[key] = v
for key in CHO:
    for i, c in enumerate(CHO[key]):
        v = exps(c); nx += v != c; CHO[key][i] = v
for it in ITEMS:
    if it.get("보기"):
        v = exps(it["보기"]); nx += v != it["보기"]; it["보기"] = v
k = "2020-11||독서||37~42"
assert PAS[k].count("자기자본 BIS 비율(%)= ×100≥8(%) 위험가중자산") == 1
PAS[k] = PAS[k].replace("자기자본 BIS 비율(%)= ×100≥8(%) 위험가중자산", "BIS 비율(%)=자기자본/위험가중자산×100≥8(%)")
print("exponent fixes(units)", nx)
NOTES = load("PASSAGE_NOTES")
fixn = {"참승□": "참승ᄒᆞᆯ", "소쇄□": "소쇄ᄒᆞᆷ", "쌍□목": "쌍비목", "용여□쟈": "용여ᄒᆞ쟈", "6.02×1023개": "6.02×10²³개", "3.086×1013km": "3.086×10¹³km"}
for key, ents in NOTES.items():
    for e in ents:
        for j, x in enumerate(e):
            for a, b in fixn.items(): x = x.replace(a, b)
            e[j] = x
NOTES["2013-11||독서||29~31"] = [e for e in NOTES["2013-11||독서||29~31"] if not e[0].startswith("의 기체에 대해")]
assert not any("□" in x for ents in NOTES.values() for e in ents for x in e)
save("PASSAGE_NOTES", NOTES)
# 옛 표기 안내 문구: □가 더 이상 없으면 지우고, 남아 있으면 그대로 둔다
NOTE = "\n\n※ 이 지문은 옛 표기(아래아 등 옛 한글 자모)를 원본 그대로 살리지 못했습니다 — 일부 글자가 □로 표시됩니다."
nrm = 0; nkeep = []
for key, v in PAS.items():
    if NOTE in v:
        body = v.replace(NOTE, "")
        PAS[key] = body; nrm += 1   # 남은 □는 원본의 가림 글자(□□고 등)뿐이므로 안내 문구를 모두 지운다
print("note removed", nrm, "kept", nkeep)
# 남은 □ 세기(원본에 있는 빈칸·기호 □ 포함)
def cnt():
    c = sum(v.count("□") for v in PAS.values()) + sum(it.get("보기", "").count("□") for it in ITEMS) + sum(x.count("□") for v in CHO.values() for x in v)
    return c
print("□ left (incl. legit)", cnt())
save("ITEMS", ITEMS); save("CHOICES", CHO); save("PASSAGES", PAS)
s = "\n".join(lines)
A = "원본의 글자 모양을 보고 되살렸습니다."
assert s.count(A) == 1, s.count(A)
s = s.replace(A, A + f" 2차 대조에서 남은 □ 자리도 원본 그림을 크게 보고 모두 채웠고(지금 남은 □는 원본에 있는 빈칸·기호·가림 글자입니다), 지문과 &lt;보기&gt;에서 글꼴이 달라 자리를 벗어나 있던 낱말(각주 * 낱말, 말하는 이 이름, 책 이름 등)을 원본 자리로 옮겼으며, 2018학년도 이후 문학 지문 {n21}개는 원본의 시행·연 나눔대로 다시 짰습니다. 2017학년도 이전 문학 지문도 원본 줄의 길이·들여쓰기·줄 간격을 읽어 시행·연 나눔을 맞추었고, 모든 지문에서 원본 줄이 낱말 중간에서 바뀐 자리에 잘못 들어가 있던 띄어쓰기(예: ‘적용 하였고’)를 원본의 줄 끝 공백 기록대로 붙였습니다.")
for a, b in [("(2) 일부 고전시가(옛 가사·시조) 지문은 원본 PDF가 아래아(ㆍ) 등 옛 한글 자모를 특수 글꼴로 표기해, 그 글자가 정확히 복원되지 않고 □로 표시됩니다.",
              "(2) 일부 고전시가(옛 가사·시조)와 중세 국어 자료는 원본 PDF가 아래아(ㆍ) 등 옛 한글 자모를 특수 글꼴로 표기해 글자를 그대로 옮길 수 없었는데, 원본의 글자 모양을 하나하나 보고 옛한글 자모로 되살렸습니다. 옛한글을 지원하지 않는 글꼴에서는 자모가 풀어져 보일 수 있습니다."),
             ("옛 한글 글꼴로 찍힌 글자는 □로 표시됩니다.", "옛 한글 글꼴로 찍힌 글자는 원본의 글자 모양을 보고 옛한글 자모로 되살렸습니다.")]:
    assert s.count(a) == 1, a[:30]
    s = s.replace(a, b)
open(DST, "w", encoding="utf-8").write(s)
print("wrote", DST, len(s) / 1e6, "MB")
