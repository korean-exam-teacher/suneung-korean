
# ==================== extract2.py ====================
# -*- coding: utf-8 -*-
"""2009~2017학년도 문제지 PDF 재추출 (글자 단위).
- 줄 끝에 PDF가 실제로 넣어 둔 공백 문자가 있으면 '낱말 경계에서 줄이 바뀐 것', 없으면 '낱말 중간에서 줄이 바뀐 것'.
  → 줄을 이을 때 띄어쓰기를 정확히 되살린다.
- 공백 문자가 없는 PDF(2010.06, 2010.09)는 글자 사이 간격으로 띄어쓰기를 판단하고, 줄 끝은 None(미상)으로 둔다.
- 줄마다 x0, x1, 단(L/R)의 오른쪽 끝을 남겨, 시(행 구분)와 산문(꽉 찬 줄)을 구분하는 데 쓴다."""
import pdfplumber, re, json, glob, os
from collections import defaultdict

HEADER_TOP, FOOTER_TOP = 140, 1075
MARK = re.compile(r"^\[\s*(\d+)\s*[～~∼\-–]\s*(\d+)\s*\]")

def page_lines(pg, has_space):
    mid = pg.width/2
    cols = {"L": [], "R": []}
    for c in pg.chars:
        if c["top"] < HEADER_TOP or c["top"] > FOOTER_TOP: continue
        cols["L" if c["x0"] < mid else "R"].append(c)
    out = []
    for side in ("L", "R"):
        chs = sorted(cols[side], key=lambda c: c["top"])
        clusters = []
        for c in chs:
            if clusters and c["top"] - clusters[-1][0] <= 5: clusters[-1][1].append(c)
            else: clusters.append([c["top"], [c]])
        for top, g in clusters:
            g.sort(key=lambda c: c["x0"])
            t = ""; prev = None
            gaps = sorted(b["x0"]-a["x1"] for a, b in zip(g, g[1:]) if a["text"] != " " and b["text"] != " ")
            med = gaps[len(gaps)//2] if gaps else 0
            for c in g:
                if prev is not None and c["text"] != " " and not t.endswith(" "):
                    gap = c["x0"] - prev["x1"]
                    # 공백 문자가 있는 PDF: 표 칸처럼 아주 넓은 간격만 띄움 / 없는 PDF: 그 줄의 보통 글자 간격보다 확실히 넓으면 띄움
                    thr = med + 0.3*c["size"] if has_space else max(1.0, med + 0.15*c["size"])
                    if gap > thr: t += " "
                t += c["text"]; prev = c
            vis = [c for c in g if c["text"].strip()]
            if not vis: continue
            endsp = (g[-1]["text"] == " ") if has_space else None
            out.append({"t": re.sub(r" {2,}", " ", t).strip(), "endsp": endsp,
                        "x0": vis[0]["x0"], "x1": vis[-1]["x1"], "top": top, "side": side})
    return out

def lines_of(pdf):
    sample = "".join(c["text"] for pg in pdf.pages[1:3] for c in pg.chars)
    has_space = sample.count(" ") / max(len(sample), 1) > 0.08
    L = []
    for pi, pg in enumerate(pdf.pages):
        pl = page_lines(pg, has_space)
        # 단의 오른쪽 끝: 그 단에서 가장 오른쪽까지 간 줄들의 x1 (상위 값)
        for side in ("L", "R"):
            xs = sorted(l["x1"] for l in pl if l["side"] == side)
            right = xs[int(len(xs)*0.9)] if xs else 0
            for l in pl:
                if l["side"] == side: l["right"] = right; l["pg"] = pi
        L += pl
    return L, has_space

def passages(L):
    res = {}
    for i, ln in enumerate(L):
        m = MARK.match(ln["t"])
        if not m: continue
        a, b = int(m.group(1)), int(m.group(2))
        j = i; instr = ln["t"]
        while "답하시오" not in L[j]["t"] and j < i+3: j += 1; instr += " "+L[j]["t"]
        if "답하시오" not in instr: j = i
        body = []; k = j+1
        qpat = re.compile(rf"^{a}\s*\.")
        while k < len(L):
            t = L[k]["t"]
            if qpat.match(t) or MARK.match(t): break
            body.append(L[k]); k += 1
        res[f"{a}~{b}"] = {"instr": instr, "lines": body}
    return res

if __name__ == "__main__":
    base = "/mnt/user-data/uploads/평가원 기출 문제 모음"
    allp = {}; streams = {}
    for f in sorted(glob.glob(base+"/20*.pdf")):
        name = os.path.basename(f)
        m = re.match(r"(\d{4})\.(\d{2})(?:\.([AB]))?", name)
        if not m: continue
        y, mo, form = m.groups()
        if int(y) > 2017: continue
        ex = f"{y}-예비-{form}" if mo == "00" else (f"{y}-{mo}-{form}" if form else f"{y}-{mo}")
        with pdfplumber.open(f) as pdf:
            L, hs = lines_of(pdf)
        allp[ex] = passages(L)
        streams[ex] = {"has_space": hs, "lines": [{k: l[k] for k in ("t","endsp","x0","x1","top","side","pg")} for l in L]}
        print(ex, hs, len(allp[ex]), flush=True)
    json.dump({"passages": allp, "streams": streams}, open("/home/claude/old/raw2.json", "w", encoding="utf-8"), ensure_ascii=False)

# ==================== spacing.py ====================
import json, re
from collections import defaultdict
class SpaceModel:
    """글자 n-gram 띄어쓰기 모형: 경계 왼쪽 글자 3개·오른쪽 글자 3개 맥락에서 '띄움' 확률."""
    def __init__(self): self.t = defaultdict(lambda: [0, 0])
    KEYS = [(3,3),(2,3),(3,2),(2,2),(1,3),(3,1),(1,2),(2,1),(1,1)]
    def feed(self, text):
        for seg in re.split(r"\n", text):
            chars = []; sp = []
            for ch in seg:
                if ch == " ":
                    if chars: sp[-1] = True
                    continue
                chars.append(ch); sp.append(False)
            for i in range(len(chars)-1):
                for l, r in self.KEYS:
                    if i-l+1 < 0 or i+r >= len(chars): continue
                    k = (l, "".join(chars[i-l+1:i+1]), "".join(chars[i+1:i+1+r]))
                    self.t[k][sp[i]] += 1
    def prob(self, left, right):
        left = left.replace(" ", ""); right = right.replace(" ", "")
        import math
        tot = 0.0; w = 0.0
        for l, r in self.KEYS:
            if len(left) < l or len(right) < r: continue
            k = (l, left[-l:], right[:r]); n = self.t.get(k)
            if n and sum(n) >= 2:
                wt = (l+r) * min(sum(n), 20)
                tot += wt*math.log((n[1]+0.5)/(n[0]+0.5)); w += wt
        if w == 0: return 0.6
        return 1/(1+math.exp(-tot/w))

# ==================== para2.py ====================
# -*- coding: utf-8 -*-
"""raw2.json의 줄 정보로 지문 텍스트를 되살린다.
- 줄 잇기: PDF 줄 끝 공백 문자 유무(endsp)로 띄어쓰기 결정. 정보가 없는 PDF는 글자 n-gram 모형으로 추정.
- (가)(나)(다) 단위로 '꽉 찬 줄' 비율을 재서 시(행 단위 줄바꿈)와 산문(문단 단위)을 나눈다."""
import re, json, sys
sys.path.insert(0, "/home/claude/old")
from spacing import SpaceModel

HEAD = re.compile(r"^\((가|나|다|라|마|바)\)\s*$")
HEAD_INLINE = re.compile(r"^\((가|나|다|라|마|바)\)\s")
ATTR = re.compile(r"^-.*[｣」』]\s*-?\s*$|^-\s*[^-]{1,30}-\s*$")
SPEAKER = re.compile(r"^[가-힣○△□A-Z]{1,5}(\s[가-힣○△□]{1,4})?\s?\d?\s?[:：]\s?\S")
FOOT = re.compile(r"^\*\s?[^\s:：*][^:：*]{0,24}[:：]")

_M = None
def model():
    global _M
    if _M: return _M
    m = SpaceModel()
    s = open("/home/claude/site_v33.html", encoding="utf-8").read().split("\n")
    P = json.loads([l for l in s if l.startswith("const PASSAGES = ")][0][len("const PASSAGES = "):].rstrip(";"))
    for v in P.values(): m.feed(v)
    R = json.load(open("/home/claude/old/raw2.json", encoding="utf-8"))["streams"]
    for ex, st in R.items():
        if st["has_space"]:
            for l in st["lines"]: m.feed(l["t"])
    _M = m; return m

STATS = {"model_joins": 0}
def joiner(a, b):
    """줄 a 다음에 줄 b를 이을 때 넣을 문자열(' ' 또는 '')."""
    if a.get("endsp") is True: return " "
    if a.get("early"): return " "
    if re.search(r"[.?!,;:]$", a["t"]) or re.search(r"[.?!,][”’」｣)]$", a["t"]): return " "
    if a.get("endsp") is False: return ""
    STATS["model_joins"] += 1
    return " " if model().prob(a["t"], b["t"]) > 0.45 else ""

MARKER = re.compile(r"^\[[A-Za-z가-하]\]$")
def fold_markers(lines):
    """[A]·[가]처럼 표시 기호만 있는 줄은 바로 앞 줄 끝에 붙인다(줄 나눔·문단 판정에 끼지 않도록)."""
    out = []
    for ln in lines:
        if MARKER.match(ln["t"].strip()) and out:
            p = dict(out[-1]); p["_mk"] = (p.get("_mk", "") + " " + ln["t"].strip()).strip(); out[-1] = p
        else:
            out.append(ln)
    return out

def piece(prev, sep, t):
    """앞 줄에 붙은 표시 기호를 낱말이 끝나는 자리에 넣는다."""
    mk = prev.get("_mk") if prev else None
    if not mk: return sep + t
    if sep: return " " + mk + sep + t
    head, _, rest = t.partition(" ")
    return head + " " + mk + (" " + rest if rest else "")

def segments(lines):
    segs = []; cur = []
    for ln in lines:
        if (HEAD.match(ln["t"]) or HEAD_INLINE.match(ln["t"])) and cur:
            segs.append(cur); cur = []
        cur.append(ln)
    if cur: segs.append(cur)
    return segs

def is_verse(seg):
    body = [l for l in seg if not HEAD.match(l["t"]) and not ATTR.match(l["t"]) and not FOOT.match(l["t"])]
    if len(body) < 2: return False
    groups = {}
    for l in body: groups.setdefault((l["pg"], l["side"]), []).append(l)
    full = n = 0
    for g in groups.values():
        if len(g) < 3 and len(groups) > 1: continue
        mx = max(l["x1"] for l in g)
        full += sum(1 for l in g if l["x1"] >= mx - 4); n += len(g)
    if n == 0: return False
    return full / n < 0.4

def same_col(a, b): return a["pg"] == b["pg"] and a["side"] == b["side"]

def mark_short(lines):
    """문단 끝 줄: 같은 단에서 바로 앞이나 뒤 줄보다 15pt 이상 짧은 줄."""
    for i, l in enumerate(lines):
        nb = [lines[j] for j in (i-1, i+1) if 0 <= j < len(lines) and same_col(lines[j], l) and abs(lines[j]["top"]-l["top"]) < 30]
        nxt = lines[i+1]["t"] if i+1 < len(lines) else ""
        l["early"] = (bool(nb) and l["x1"] < max(n["x1"] for n in nb) - 15) or ("right" in l and l["x1"] < l["right"] - 30)
        l["short"] = (bool(nb) and l["x1"] < max(n["x1"] for n in nb) - 15
                      and (re.search(r"[.?!”’」』｣)…,:~\]]\s*$", l["t"]) is not None or re.match(r"^[“‘(\[]", nxt) is not None))

def prose(seg, out):
    for i, ln in enumerate(seg):
        t = ln["t"]
        if not out: out.append(t); continue
        prev = seg[i-1] if i > 0 else None
        if prev is None: out.append(piece(seg[-1] if False else None, "\n", t)); continue
        ref = None
        prev_close = same_col(prev, ln) and 0 < ln["top"] - prev["top"] < 30
        for nx in seg[i+1:i+3]:
            if same_col(nx, ln) and 0 < nx["top"] - ln["top"] < 30: ref = nx["x0"]; break
        if ref is not None and prev_close and not (6 <= ln["x0"] - prev["x0"] <= 16) and not re.search(r"[.?!”’」』｣)]$", prev["t"]):
            ref = None   # 앞 줄과 들여쓰기가 같고 문장도 안 끝났으면(괄호 [A] 구간 등) 새 문단이 아님
        if ref is None and prev_close and re.search(r"[.?!”’」』｣)]$", prev["t"]): ref = prev["x0"]
        new = (HEAD.match(t) or HEAD.match(prev["t"]) or HEAD_INLINE.match(t) or FOOT.match(t) or ATTR.match(t) or SPEAKER.match(t)
               or prev.get("short") or (ref is not None and 6 <= ln["x0"] - ref <= 16))
        out.append(piece(prev, "\n" if new else joiner(prev, ln), t))

def verse(seg, out):
    from collections import Counter
    body = [l for l in seg if not HEAD.match(l["t"]) and not ATTR.match(l["t"]) and not FOOT.match(l["t"])]
    base = Counter(round(l["x0"]) for l in body).most_common(1)[0][0] if body else 0
    colmax = {}
    for l in seg: colmax[(l["pg"], l["side"])] = max(colmax.get((l["pg"], l["side"]), 0), l["x1"])
    for i, ln in enumerate(seg):
        t = ln["t"]
        if not out: out.append(t); continue
        prev = seg[i-1] if i > 0 else None
        if prev is None: out.append("\n" + t); continue
        cont = (ln in body and same_col(prev, ln) and 0 < ln["top"] - prev["top"] < 30
                and ln["x0"] <= base - 6 and prev["x1"] >= colmax[(prev["pg"], prev["side"])] - 10)
        if cont: out.append(piece(prev, joiner(prev, ln), t)); continue
        gap = same_col(prev, ln) and ln["top"] - prev["top"] > 30
        out.append(piece(prev, "\n\n" if gap and not HEAD.match(prev["t"]) else "\n", t))

POEM = {"현대시", "고전시가"}
def para_text2(lines, area=None, genres=()):
    """area/genres: 문항 정보. 비문학은 산문, 시만 있는 세트는 행 보존, 그 밖의 문학은 (가)(나) 단위로 판정."""
    out = []; kinds = []
    lines = fold_markers(lines)
    mark_short(lines)
    segs_prev = None
    for seg in segments(lines):
        if area is not None and area != "문학": v = False
        elif genres and set(genres) <= POEM: v = True
        elif genres and not set(genres) & POEM: v = False
        else: v = is_verse(seg)
        kinds.append("V" if v else "P")
        if out and segs_prev and segs_prev[-1].get("_mk"): out.append(" " + segs_prev[-1]["_mk"])
        (verse if v else prose)(seg, out)
        segs_prev = seg
    if segs_prev and segs_prev[-1].get("_mk"): out.append(" " + segs_prev[-1]["_mk"])
    return pua("".join(out)), "".join(kinds)

PUA = re.compile("[\ue000-\uf8ff\U000f0000-\U0010ffff]")
def pua(s): return PUA.sub("□", s.replace("\U000f0854", "『").replace("\U000f0855", "』").replace("\u200b", ""))

def stream_text(lines):
    """회차 전체를 한 줄로 이은 텍스트(발문·선택지 띄어쓰기 맞추기용)."""
    out = []
    for i, ln in enumerate(lines):
        out.append((joiner(lines[i-1], ln) if i else "") + ln["t"])
    return "".join(out)

# ==================== respace.py ====================
import json, re, sys
sys.path.insert(0, "/home/claude/old")
from para2 import joiner, pua, mark_short
WS = re.compile(r"\s+")
def build(lines):
    cols = {}
    for l in lines: cols.setdefault((l["pg"], l["side"]), []).append(l["x1"])
    for l in lines:
        xs = sorted(cols[(l["pg"], l["side"])]); l["right"] = xs[int(len(xs)*0.9)]
    mark_short(lines)
    s = []
    for i, ln in enumerate(lines):
        s.append((joiner(lines[i-1], ln) if i else "") + ln["t"])
    text = pua("".join(s))
    ns = []; idx = []
    for k, ch in enumerate(text):
        if not ch.isspace(): ns.append(ch); idx.append(k)
    return text, "".join(ns), idx
def norm(s): return pua(WS.sub("", s))
def find_spaced(st, s, start=0):
    """원문 s(공백 무시)를 스트림에서 찾아 PDF 띄어쓰기를 입힌 문자열과 끝 위치를 돌려준다."""
    text, ns, idx = st
    q = norm(s)
    if not q: return None, start
    p = ns.find(q, start)
    if p < 0: return None, start
    seg = text[idx[p]: idx[p+len(q)-1]+1]
    return WS.sub(" ", seg).strip(), p+len(q)

# ==================== qparse.py ====================
import json, re, sys
sys.path.insert(0, "/home/claude/old")
from respace import build, find_spaced, norm, WS
MARKS = "①②③④⑤"
def clean(s): return WS.sub(" ", s).strip()
def parse_exam(lines, items):
    """items: 이 회차 문항들. 반환: {번호: {"발문":..., "보기":..., "선택지":[...]}}"""
    text, ns, idx = st = build(lines)
    # 1) 발문 위치
    pos = {}; p = 0
    for it in sorted(items, key=lambda x: x["문항번호"]):
        q = norm(it["발문"]); k = ns.find(q, p)
        if k < 0: k = ns.find(q)
        if k >= 0: pos[it["문항번호"]] = (k, k+len(q)); p = k+len(q)
    starts = sorted(v[0] for v in pos.values())
    out = {}
    for it in items:
        n = it["문항번호"]
        if n not in pos: continue
        a, b = pos[n]
        nxt = min([s for s in starts if s > a] + [len(ns)])
        m = re.compile(r"\[\d+[～~∼\-–]\d+\]").search(ns, b, nxt)
        if m: nxt = m.start()
        # 이 구간의 ①~⑤ (순서대로 하나씩)
        ms = []; q = b
        for mk in MARKS:
            k = ns.find(mk, q, nxt)
            if k < 0: ms = None; break
            ms.append(k); q = k+1
        sp = lambda i, j: clean(text[idx[i]: idx[j-1]+1]) if j > i else ""
        rec = {"발문": sp(a, b)}
        if ms:
            bounds = ms + [nxt]
            rec["선택지"] = [sp(bounds[i]+1, bounds[i+1]) for i in range(5)]
            rec["보기"] = sp(b, ms[0])
        out[n] = rec
    return out

# ==================== decide.py ====================
import re, sys
from collections import Counter
sys.path.insert(0, "/home/claude/old")
from respace import norm
from para2 import pua
JUNK_TAIL = re.compile(r"(\s*(\*\s*)?확인\s*사항.*$|\s*답안지의 해당란에.*$|\s*이\s*면\s*은\s*여\s*\d*\s*백\s*입니다\.?\s*$)")
SRC_JUNK = re.compile(r"\s*(국어|언어|영역|언어\s*영역|영역\s*\((?:[AB]\s*)?(?:홀수형\s*)?(?:[AB]\s*)?형\)|영역\s*홀수형|홀수형)\s*$")
BAD = re.compile(r"···|◦|⋮|\d+\s*\.\s[^①]{5,}\?\s*①")
def strip_src(s):
    prev = None
    while prev != s:
        prev = s; s = SRC_JUNK.sub("", s); s = JUNK_TAIL.sub("", s)
    return s.strip()
def choose(src, pdf):
    """반환: (최종 문자열, 판정)"""
    src = src or ""
    if pdf is None: return pua(strip_src(src)), "src(no pdf)"
    pdf = JUNK_TAIL.sub("", pdf).strip()
    s2 = strip_src(src)
    if norm(src) == norm(pdf): return pdf, "same"
    if norm(s2) == norm(pdf): return pdf, "junk removed"
    if BAD.search(pdf) or not pdf: return pua(s2), "src(pdf bad)"
    a, b = Counter(norm(s2)), Counter(norm(pdf))
    diff = sum(((a-b)+(b-a)).values())
    if Counter(norm(s2)) == Counter(norm(pdf)): return pdf, "reordered"
    if diff <= max(6, 0.15*len(norm(s2))): return pdf, "pdf(small diff)"
    return pua(s2), "src(big diff)"

# ==================== run_parse.py ====================
import json,sys
sys.path.insert(0,"/home/claude/old")
from qparse import parse_exam
R=json.load(open("raw2.json"))
base="/mnt/user-data/uploads/평가원 기출 문제 모음/문제은행_데이터/"
src={}
for f in ["items_2009_2013_with_answers.json","ab_items_with_answers.json","items_2017_with_answers.json"]:
    src.update(json.load(open(base+f,encoding="utf-8")))
P={ex:parse_exam(R["streams"][ex]["lines"],[{"문항번호":int(a["문항번호"]),"발문":a["발문"]} for a in arr]) for ex,arr in src.items()}
json.dump(P,open("parsed_q.json","w",encoding="utf-8"),ensure_ascii=False)
print("parsed",sum(len(v) for v in P.values()))

# ==================== build_old.py ====================
import json, re, ast, sys
from collections import Counter, defaultdict
sys.path.insert(0,"/home/claude/typegroup"); sys.path.insert(0,"/home/claude/old")
from type_groups import group_for, GROUP_OF, GROUPS
from works import works_in
from para2 import para_text2, pua
from decide import choose

SITE="/home/claude/site_v33.html"
s=open(SITE,encoding="utf-8").read().split("\n")
def idx(n): return [k for k,l in enumerate(s) if l.startswith(f"const {n} = ")][0]
def load(n): return json.loads(s[idx(n)][len(f"const {n} = "):].rstrip(";"))
ITEMS=load("ITEMS")

# 유형묶음 -> 역량 (기존 문항에서 절반 이상 함께 붙은 역량)
gs=defaultdict(Counter); gn=Counter()
for it in ITEMS:
    g=it["유형묶음"]; gn[g]+=1
    for sk in it.get("역량",[]): gs[g][sk]+=1
SKILL_OF={g:[sk for sk,c in gs[g].most_common() if c>=gn[g]*0.5] for g in gn}

RAW=json.load(open("raw2.json",encoding="utf-8"))["passages"]
PQ=json.load(open("parsed_q.json",encoding="utf-8"))
DECISIONS=Counter()
UNI=json.load(open("uniq.json",encoding="utf-8"))
LAB={}
for b in range(8): LAB.update(json.load(open(f"labels{b}.json",encoding="utf-8")))
REF={}
for pid,lst in UNI["refs"].items():
    for ex,r in lst: REF[(ex,r)]=pid

base="/mnt/user-data/uploads/평가원 기출 문제 모음/문제은행_데이터/"
src={}
for f in ["items_2009_2013_with_answers.json","ab_items_with_answers.json","items_2017_with_answers.json"]:
    src.update(json.load(open(base+f,encoding="utf-8")))

POEM={"현대시","고전시가"}
def genres(area,f):
    g=[]
    if area=="문학":
        if "현대시" in f: g.append("현대시")
        if "현대소설" in f: g.append("현대소설")
        if "고전시가" in f or "고전운문" in f: g.append("고전시가")
        if "고전소설" in f: g.append("고전소설")
        if "극" in f or "시나리오" in f: g.append("극·시나리오")
        if "수필" in f: g.append("수필")
    elif area=="독서":
        if f.startswith(("인문","예술")): g.append("인문·예술")
        elif f.startswith("사회"): g.append("사회·문화")
        elif f.startswith(("과학","기술")): g.append("과학·기술")
    return g

def reform(area,grp):
    if area=="독서": return "독서와 작문"
    if area=="문학": return "문학"
    if area=="언어와 매체": return "화법과 언어"
    return "화법과 언어" if grp.startswith("화법") else "독서와 작문"

NEW=[]; PAS={}; CHO={}
for ex,arr in src.items():
    for it0 in arr:
        y=int(it0["연도"]); mo=it0.get("시행월")
        form=it0.get("형") or ""
        if "예비" in ex:
            kind="예비 시행"; mon=None; name=f"{y}학년도 수준별 국어 예비 시행({form}형)"
        else:
            mon=int(mo); kind="대학수학능력시험" if mon==11 else "평가원 모의평가"
            name=(f"{y}학년도 대학수학능력시험" if mon==11 else f"{y}학년도 {mon}월 모의평가")+(f"({form}형)" if form else "")
        r=it0["지문범위"]; area=it0["영역"]
        ch=it0.get("선택지") or []
        if isinstance(ch,str):
            try: ch=ast.literal_eval(ch)
            except Exception: ch=[]
        rec=PQ.get(ex,{}).get(str(int(it0["문항번호"])),{})
        stem,d=choose(it0["발문"],rec.get("발문")); DECISIONS["발문",d]+=1
        bogi,d=(choose(it0.get("보기") or "",rec.get("보기")) if it0.get("보기") else ("",None))
        if d: DECISIONS["보기",d]+=1
        if len(ch)==5:
            pc=rec.get("선택지") or [None]*5
            newch=[]
            for c0,p0 in zip(ch,pc):
                c1,d=choose(c0,p0); DECISIONS["선택지",d]+=1; newch.append(c1)
            ch=newch
        it={"연도":y,"시행월":mon,"시행유형":kind,"명칭":name,"exam_id":ex,"문항번호":int(it0["문항번호"]),
            "영역":area,"지문범위":r,"발문":stem,"배점":int(it0["배점"]),"유형":it0.get("유형_자동분류") or "미분류(수동 확인 필요)",
            "정답":int(it0["정답"]) if it0.get("정답") else None,"보기":bogi}
        if form: it["형"]=form
        pid=REF.get((ex,r))
        if pid:
            it["소재"]=LAB[pid]["소재"]; it["분야"]=LAB[pid]["분야"]
        elif r=="(독립 문항)":
            it["소재"]=""; it["분야"]=""
        else:
            it["소재"]="(지문 없음)"; it["분야"]="(미확인)"
        if r=="(독립 문항)":
            it["분야"]="문법(독립 문항)" if area=="언어와 매체" else "작문(독립 문항)"
        g,_=group_for(it, ch if len(ch)==5 else None)
        if g=="미분류":
            f=it["분야"]
            g = "화법: 내용 이해·평가" if f.startswith("화법") and not f.startswith("화법·작문") else ("작문: 내용 생성·조직" if area=="화법과 작문" else g)
        it["유형묶음"]=g; it["유형갈래"]=GROUP_OF.get(g,"미분류")
        it["역량"]=SKILL_OF.get(g,[])
        it["개편매핑_과목"]=reform(area,g)
        if r=="(독립 문항)":
            it["소재"]=f"{g.replace('화법: ','').replace('작문: ','')} (독립 문항)"
        it["갈래"]=genres(area,it["분야"])
        key=f"{ex}||{area}||{r}"
        txt=""
        if r!="(독립 문항)" and (ex,r) in [(e,rr) for e,rr in [(ex,r)]] and r in RAW.get(ex,{}):
            lines=RAW[ex][r]["lines"]
            while lines and re.fullmatch(r"(답?하)?시오\.", lines[0]["t"].strip()): lines=lines[1:]   # 안내문 끝 조각
            txt=para_text2(lines, area, it["갈래"])[0] if lines else ""
            if len(re.sub(r"\s","",txt))<20: txt=""
        if txt: PAS[key]=txt
        it["작품"]=works_in(txt) if txt else []
        if any("각색" in w for w in it["작품"]) and "극·시나리오" not in it["갈래"]: it["갈래"].append("극·시나리오")
        if len(ch)==5: CHO[f"{ex}||{area}||{it['문항번호']}"]=ch
        NEW.append(it)

# 지문 길이·낱말 풀이
FN=re.compile(r"\*\s?([^\s*:：][^*:：\n]{0,28}?)\s*[:：]\s*([^*\n]+?)(?=\s*\*\s?[^\s*:：][^*:：\n]{0,28}?\s*[:：]|\s*\n|\s*$)")
WORD_OK=re.compile(r"^[가-힣A-Za-z0-9◯ㄱ-ㅎ][^’‘“”\"]{0,20}$")
NOTES={}; LEN={}
for k,v in PAS.items():
    notes=[[m.group(1).strip(),m.group(2).strip(),m.group(0)] for m in FN.finditer(v) if WORD_OK.match(m.group(1).strip()) and len(m.group(2))<=150]
    body=v
    for n in notes: body=body.replace(n[2],"")
    if notes: NOTES[k]=notes
    LEN[k]=len(body.strip())
for it in NEW:
    L=LEN.get(f'{it["exam_id"]}||{it["영역"]}||{it["지문범위"]}',0)
    it["지문길이"]=L if L>=100 else 0

print(DECISIONS)
print("items",len(NEW),"passages",len(PAS),"choices",len(CHO),"notes",sum(len(v) for v in NOTES.values()))
print(Counter(it["유형갈래"] for it in NEW)); print("no answer",sum(1 for it in NEW if not it["정답"]))
print(Counter(g for it in NEW for g in it["갈래"]))
json.dump({"items":NEW,"passages":PAS,"choices":CHO,"notes":NOTES},open("old_bundle.json","w",encoding="utf-8"),ensure_ascii=False)

# ==================== merge_old.py ====================
# -*- coding: utf-8 -*-
"""site_v33.html + old/old_bundle.json(2009~2017학년도) → site_v34.html"""
import json, re
SRC = "/home/claude/site_v33.html"; DST = "/home/claude/site_v34.html"
lines = open(SRC, encoding="utf-8").read().split("\n")
def idx(n): return [k for k, l in enumerate(lines) if l.startswith(f"const {n} = ")][0]
def load(n): return json.loads(lines[idx(n)][len(f"const {n} = "):].rstrip(";"))
def save(n, v): lines[idx(n)] = f"const {n} = " + json.dumps(v, ensure_ascii=False) + ";"

B = json.load(open("/home/claude/old/old_bundle.json", encoding="utf-8"))
ITEMS = load("ITEMS"); PASSAGES = load("PASSAGES"); CHOICES = load("CHOICES"); NOTES = load("PASSAGE_NOTES")
assert not any(i["exam_id"] in {x["exam_id"] for x in B["items"]} for i in ITEMS)
for k in B["passages"]: assert k not in PASSAGES
ITEMS += B["items"]; PASSAGES.update(B["passages"]); CHOICES.update(B["choices"]); NOTES.update(B["notes"])
save("ITEMS", ITEMS); save("PASSAGES", PASSAGES); save("CHOICES", CHOICES); save("PASSAGE_NOTES", NOTES)
s = "\n".join(lines)
# 한글 문서 글꼴의 사용자 정의 영역 겹낫표 → 『 』
s = s.replace("\U000f0854", "『").replace("\U000f0855", "』")

def rep(old, new, cnt=1):
    global s
    assert s.count(old) == cnt, (s.count(old), old[:80])
    s = s.replace(old, new)

# ---- 회차 표기·정렬 ----
rep("""function examShort(it){
  if(it.exam_id === '2028-예시') return {code:'2028', kind:'예시문항'};
  const [y,m] = it.exam_id.split('-');
  return {code:`${y}.${m}`, kind: it.시행유형==='대학수학능력시험' ? '수능' : `${Number(m)}월 모평`};
}""", """function examShort(it){
  if(it.exam_id === '2028-예시') return {code:'2028', kind:'예시문항'};
  const [y,m,f] = it.exam_id.split('-');
  const form = f ? ` ${f}형` : '';
  if(m === '예비') return {code:`${y}`, kind:`예비 시행${form}`};
  return {code:`${y}.${m}`, kind: (it.시행유형==='대학수학능력시험' ? '수능' : `${Number(m)}월 모평`) + form};
}
/* 회차 순서 값: 학년도 → 예비 시행 → 6월 → 9월 → 수능 (큰 값이 최신). 같은 회차에서는 A형 값이 더 커서 최신순 목록에서 A형이 먼저 나온다. */
function examRank(id){
  const [y,m,f] = String(id).split('-');
  const mm = m === '예비' ? 0 : (Number(m) || 0);
  return Number(y)*1000 + mm*10 + (f === 'A' ? 2 : f === 'B' ? 1 : 0);   // 최신순 정렬에서 A형이 B형보다 먼저 오도록
}""")
rep("const exams = [...new Set(items.map(i=>i.exam_id))].sort().reverse();",
    "const exams = [...new Set(items.map(i=>i.exam_id))].sort((a,b)=>examRank(b)-examRank(a));")
rep("    b.exam_id.localeCompare(a.exam_id) ||", "    examRank(b.exam_id) - examRank(a.exam_id) ||")
rep("// 최신 회차부터(학년도 내림차순, 같은 학년도는 수능→9월→6월), 회차 안에서는 문항 번호 순.",
    "// 최신 회차부터(학년도 내림차순, 같은 학년도는 수능→9월→6월→예비 시행, 같은 회차는 A형→B형), 회차 안에서는 문항 번호 순.")

# ---- 회차별 표 ----
old_tbl = s[s.index("  const byYear = {};\n  items.forEach(i=>{ (byYear[i.연도] ??= {})[i.시행월] = i; });"):s.index("examTableWrap.addEventListener('click'")]
new_tbl = """  // byYear[학년도][6|9|11|'pre'] = [exam_id, …] (A형·B형이 있으면 두 개)
  const byYear = {};
  items.forEach(i=>{
    const m = i.exam_id.split('-')[1];
    const col = m === '예비' ? 'pre' : Number(m);
    const arr = ((byYear[i.연도] ??= {})[col] ??= []);
    if(!arr.includes(i.exam_id)) arr.push(i.exam_id);
  });
  Object.values(byYear).forEach(o=>Object.values(o).forEach(a=>a.sort((x,y)=>examRank(y)-examRank(x))));   // A형 → B형
  const years = Object.keys(byYear).sort((a,b)=>b-a);
  const shown = state.allYears ? years : years.slice(0,5);
  const LABEL = {6:'6월 모의평가', 9:'9월 모의평가', 11:'수능', pre:'예비 시행'};
  const btns = (y, col, ids)=> ids.map(id=>{
    const f = id.split('-')[2];
    const name = `${y}학년도 ${LABEL[col]}${f ? ` ${f}형` : ''}`;
    return f
      ? `<button type="button" class="ylink form" data-exam="${id}" aria-label="${name} 보기">${f}형<span class="n">${countBy[id]}</span></button>`
      : `<button type="button" class="ylink" data-exam="${id}" aria-label="${name} 보기">${countBy[id]}문항 보기</button>`;
  }).join('');
  const cell = (y,m)=>{
    const ids = byYear[y][m];
    if(ids) return `<td>${btns(y, m, ids)}</td>`;
    const miss = MISSING_EXAMS[`${y}-${m}`];
    if(miss) return `<td><span class="y-miss" title="${escapeHtml(miss)}">미수록</span></td>`;
    return `<td><span class="y-none">–</span></td>`;
  };
  const rows = shown.map(y=>{
    let h = `<tr><td>${y}학년도</td>${cell(y,6)}${cell(y,9)}${cell(y,11)}</tr>`;
    if(byYear[y].pre) h += `<tr class="pre-row"><td>${y}학년도 <small>예비 시행</small></td><td colspan="3" class="pre-cell">${btns(y,'pre',byYear[y].pre)}<span class="pre-note">수준별 국어 도입 전 ${Number(y)-2}년에 시행</span></td></tr>`;
    return h;
  }).join('');
  examTableWrap.innerHTML = `
    <table class="year-table">
      <thead><tr><th>학년도</th><th>6월 모의평가</th><th>9월 모의평가</th><th>대학수학능력시험</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
    ${years.length>5 ? `<button type="button" class="more-years" id="moreYears">${state.allYears ? '최근 5개 학년도만 보기 ▴' : `이전 학년도 펼치기 (${years[years.length-1]}~${years[5]}) ▾`}</button>` : ''}
    ${state.allYears ? `<p class="table-note">2014~2016학년도는 수준별 시험(A형·B형)으로 두 유형이 따로 출제되어 각각 수록했습니다. 미수록 회차는 원본 문제지가 스캔 이미지뿐이라 글자를 옮기지 못한 회차입니다.</p>` : ''}`;
}
const MISSING_EXAMS = {
  '2009-9': '2009학년도 9월 모의평가: 확보한 문제지가 스캔 이미지뿐이라 아직 싣지 못했습니다.',
  '2009-11': '2009학년도 수능: 확보한 문제지가 스캔 이미지뿐이라 아직 싣지 못했습니다.',
  '2014-11': '2014학년도 수능(A형·B형): 확보한 문제지가 스캔 이미지뿐이라 아직 싣지 못했습니다.',
};
"""
s = s.replace(old_tbl, new_tbl)

# ---- 이용 안내 ----
def sub_between(start, end, new):
    global s
    i = s.index(start); j = s.index(end, i)
    s = s[:i] + new + s[j:]
sub_between("<p>2018~2027학년도 6월·9월 모의평가와 11월 수능 국어영역 기출(총 29개 회차", "</p>",
  "<p>2009~2027학년도 평가원 6월·9월 모의평가와 11월 대학수학능력시험 국어(언어) 영역 기출, 그리고 2014학년도 수준별 국어 예비 시행까지 모두 63개 회차 3,022문항을 지문 소재와 문항 유형으로 찾아볼 수 있게 정리했습니다. 시험 체제는 시기마다 다릅니다 — 2009~2013학년도는 언어 영역(1~5번 듣기 문항은 싣지 않고 6~50번 45문항만 수록), 2014~2016학년도는 수준별 국어 A형·B형(두 유형을 각각 수록), 2017~2021학년도는 화법·작문·문법·독서·문학 45문항 체제, 2022학년도부터는 공통 과목(독서·문학)과 선택 과목(화법과 작문·언어와 매체) 체제입니다. 문법 문항은 시기와 상관없이 \"언어와 매체\" 영역으로 묶어 두었습니다. \"회차별 기출문제\" 표에서 회차를 누르면 그 회차 문항을 지문별로 묶어서 볼 수 있습니다. \"개편 매핑\" 표시는 2028학년도 개편 예시문항 안내자료집 분석을 바탕으로 각 문항이 개편 후 신설 과목 중 어디에 해당할지 참고용으로 붙인 것으로, 문항 자체가 2028학년도 개편 형식이라는 뜻은 아닙니다.")
rep("<p>2018~2021학년도 6월·9월 평가원 모의평가·11월 대학수학능력시험(화법·작문·문법 고정 순서 체제)",
    "<p><b>2009~2017학년도</b>(34개 회차, 1,530문항): 2009학년도 6월, 2010~2013학년도 6월·9월·수능, 2014학년도 6월·9월(A·B형)과 예비 시행(A·B형), 2015·2016학년도 6월·9월·수능(A·B형), 2017학년도 6월·9월·수능. 2009학년도 9월·수능과 2014학년도 수능은 확보한 문제지가 스캔 이미지뿐이라 아직 싣지 못했습니다(표에 \"미수록\"으로 표시). 정답은 확보한 정답표로 1,440문항에 반영했고, 2014학년도 예비 시행 90문항은 정답표를 구하지 못해 정답이 없습니다.</p>\n        <p><b>2018~2027학년도</b>: 2018~2021학년도 6월·9월 평가원 모의평가·11월 대학수학능력시험(화법·작문·문법 고정 순서 체제)")
rep("<p>소재·분야 태그는 지문을 직접 읽고 붙인 것이고,",
    "<p>소재·분야 태그는 지문을 직접 읽고 붙인 것입니다(2009~2017학년도 지문의 태그는 이번에 새로 붙인 초안이라 아직 검토 중입니다). ")
rep("<p>공식·사설 해설 자료와 대조해 유형을 검증했습니다(총 1,120/1,492, 약 75%).",
    "<p>2018~2027학년도 문항은 공식·사설 해설 자료와 대조해 유형을 검증했습니다(총 1,120/1,492, 약 75%). 2009~2017학년도 1,530문항은 아직 해설 자료와 대조하지 않아 모두 발문 패턴에 따른 자동 분류이며 \"유형 확인\" 표시가 없습니다.")
rep("전체 1,537문항 중 1,497문항(약 97%)에 역량 태그가 붙어 있으며, 나머지 40문항은 유형 자체가 \"미분류(수동 확인 필요)\"로 남아 있어 태그를 붙일 근거가 없는 문항입니다.",
    "2018~2027학년도와 2028 예시문항 1,537문항 중 1,497문항(약 97%)에 역량 태그가 붙어 있으며, 나머지 40문항은 유형 자체가 \"미분류(수동 확인 필요)\"로 남아 있어 태그를 붙일 근거가 없는 문항입니다. 2009~2017학년도 문항은 같은 유형 묶음의 문항에 절반 이상 함께 붙은 역량을 옮겨 붙였습니다(1,530문항 중 1,216문항). 그래서 역량이 고르게 갈리는 묶음의 문항에는 역량 태그가 없습니다.")
rep("<summary>제시 자료(&lt;보기&gt;·&lt;자료&gt;·&lt;학습 활동&gt; 등)</summary>",
    """<summary>2009~2017학년도 기출 정리 방법</summary>
        <p>지문·발문·선택지·&lt;보기&gt;는 문제지 PDF에서 글자 단위로 다시 뽑았습니다. PDF에는 줄이 낱말 경계에서 바뀌었는지(줄 끝 공백) 기록이 남아 있어, 이를 읽어 줄 바뀜 자리의 띄어쓰기를 되살렸습니다. 다만 2010학년도 6월·9월 모의평가 문제지는 이 기록이 없어 다른 기출 지문에서 익힌 띄어쓰기 규칙으로 추정했습니다. 그래서 이 두 회차에는 줄 바뀜 자리의 띄어쓰기가 틀린 곳이 조금 있을 수 있습니다(시험해 본 결과 약 90% 정확). 처음 받은 문항 자료에 섞여 있던 쪽 머리글(\"국어\", \"언어 영역\", \"홀수형\" 등)과 확인 사항 문구는 선택지에서 걷어 냈습니다. 위첨자·작은 글자 때문에 낱말 순서가 뒤섞였던 곳(예: f1, f2)은 PDF 글자 위치 순서대로 바로잡았습니다. 이 과정에서 글자를 새로 지어 넣지는 않았습니다. 옛 한글 글꼴로 찍힌 글자는 □로 표시됩니다. 문단 나눔과 시의 행·연 나눔도 같은 방식으로 들여쓰기·줄 길이를 읽어 되살렸습니다.</p>
      </details>
      <details>
        <summary>제시 자료(&lt;보기&gt;·&lt;자료&gt;·&lt;학습 활동&gt; 등)</summary>""")

# ---- CSS ----
rep(".y-none{color:var(--text-faint)}", """.y-none{color:var(--text-faint)}
.y-miss{color:var(--text-faint);font-size:12.5px;border-bottom:1px dotted var(--text-faint);cursor:help}
.ylink.form{min-width:0;padding:5px 10px;margin:2px 3px}
.pre-row td{background:var(--bg-sub)}
.pre-row td:first-child small{font-weight:500;color:var(--text-sub);margin-left:2px}
.pre-cell{text-align:left!important}
.pre-note{font-size:12px;color:var(--text-faint);margin-left:8px}
.table-note{font-size:12.5px;color:var(--text-sub);margin:8px 2px 0;line-height:1.6}""")

open(DST, "w", encoding="utf-8").write(s)
print("items", len(ITEMS), "passages", len(PASSAGES), "choices", len(CHOICES), "notes", len(NOTES))
