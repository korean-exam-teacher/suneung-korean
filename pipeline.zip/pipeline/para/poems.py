import json, re, sys, os, glob, statistics
sys.path.insert(0,".")
import pdfplumber
from detect import page_lines
SRC="/home/claude/site_v31.html"
s=open(SRC,encoding="utf-8").read().split("\n")
def load(n):
    i=[k for k,l in enumerate(s) if l.startswith(f"const {n} = ")][0]; return json.loads(s[i][len(f"const {n} = "):].rstrip(";"))
items=load("ITEMS")
P=json.load(open("passages_para.json",encoding="utf-8"))
POEM={"현대시","고전시가"}
poemkeys={}
for it in items:
    if it["영역"]=="문학" and it["갈래"] and set(it["갈래"])<=POEM:
        poemkeys[f'{it["exam_id"]}||{it["영역"]}||{it["지문범위"]}']=1
pdfdir="/mnt/user-data/uploads/평가원 기출 문제 모음"
def exam_of(fn):
    m=re.match(r"(\d{4})\.\s?(\d{2})",fn); return f"{m.group(1)}-{m.group(2)}"
def norm_map(t):
    chars=[];idx=[]
    for i,c in enumerate(t):
        if not c.isspace(): chars.append(c); idx.append(i)
    return "".join(chars), idx
report={}
for f in sorted(glob.glob(pdfdir+"/20*.pdf")):
    ex=exam_of(os.path.basename(f))
    keys=[k for k in poemkeys if k.startswith(ex+"||")]
    if not keys: continue
    seq=[]
    with pdfplumber.open(f) as pdf:
        for pi,pg in enumerate(pdf.pages):
            cols=page_lines(pg)
            for side in ("L","R"):
                for ln in cols[side]: seq.append((pi,side,ln))
    for k in keys:
        N,idx=norm_map(P[k])
        breaks={}  # orig index -> "\n" or "\n\n"
        ptr=None; prev=None; misses=0; gaps=[]
        matched=[]
        for (pi,side,ln) in seq:
            t=re.sub(r"\s","",ln["text"])
            if not t: continue
            snip=t[:8]
            if ptr is None:
                if len(t)>=6:
                    pos=N.find(snip)
                    if 0<=pos<=8: ptr=pos; matched.append((pos,pi,side,ln)); ptr=pos+len(t); misses=0
                continue
            pos=N.find(snip, max(0,ptr-6), ptr+30)
            if pos>=0:
                matched.append((pos,pi,side,ln)); ptr=max(ptr,pos+len(t)); misses=0
            else:
                misses+=1
                if misses>60: break
        # spacing for stanza gaps
        sp=[b[3]["top"]-a[3]["top"] for a,b in zip(matched,matched[1:]) if a[1]==b[1] and a[2]==b[2] and 0<b[3]["top"]-a[3]["top"]<60]
        med=statistics.median(sp) if sp else 18
        for j,(pos,pi,side,ln) in enumerate(matched):
            if pos==0: continue
            gap = j>0 and matched[j-1][1]==pi and matched[j-1][2]==side and ln["top"]-matched[j-1][3]["top"]>med*1.6
            breaks[idx[pos]]="\n\n" if gap else "\n"
        t=P[k]
        for i in sorted(breaks,reverse=True):
            j=i
            while j>0 and t[j-1]==" ": j-=1
            if t[j-1:j]=="\n": continue
            t=t[:j]+breaks[i]+t[i:]
        cover = (matched[-1][0]/len(N)) if matched else 0
        report[k]=(len(matched), round(cover,2))
        P[k]=t
for k,v in report.items(): print(k,v)
json.dump(P,open("passages_para2.json","w",encoding="utf-8"),ensure_ascii=False)
