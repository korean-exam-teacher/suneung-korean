# -*- coding: utf-8 -*-
"""문제지 PDF에서 '문단 첫 줄'(들여쓰기된 줄)을 찾아 그 줄의 앞부분 글자를 돌려준다.
2단 편집이라 왼쪽/오른쪽 단을 나눠서 보고, 같은 단 안 주변 줄의 왼쪽 끝(가장 흔한 x0)보다
대략 한 글자(6~16pt) 안쪽에서 시작하는 줄을 문단 첫 줄로 본다."""
import pdfplumber, re
from collections import Counter, defaultdict

SKIP = re.compile(r"^(\[|［|①|②|③|④|⑤|\d+\.|\(가\)|\(나\)|\(다\)|\(라\)|<|＜|\*|※|-)")

def page_lines(pg):
    words = pg.extract_words(use_text_flow=False, keep_blank_chars=False)
    mid = pg.width/2
    cols = {"L":defaultdict(list),"R":defaultdict(list)}
    for w in words:
        side = "L" if w["x0"] < mid else "R"
        cols[side][round(w["top"]/3)].append(w)
    out = {}
    for side, d in cols.items():
        lines=[]
        for k in sorted(d):
            ws = sorted(d[k], key=lambda w:w["x0"])
            lines.append({"x0":ws[0]["x0"], "top":ws[0]["top"], "text":"".join(w["text"] for w in ws)})
        out[side]=lines
    return out

def para_starts(path):
    starts=[]
    with pdfplumber.open(path) as pdf:
        for pg in pdf.pages:
            for side, lines in page_lines(pg).items():
                for i, ln in enumerate(lines):
                    if SKIP.match(ln["text"]) or len(ln["text"]) < 6: continue
                    ref = None
                    # 같은 문단의 다음 줄(바로 아래, 줄 간격 이내)이 기준 왼쪽 끝이 된다
                    for nx in lines[i+1:i+3]:
                        if 0 < nx["top"] - ln["top"] < 30 and not SKIP.match(nx["text"]):
                            ref = nx["x0"]; break
                    if ref is None and i > 0 and 0 < ln["top"] - lines[i-1]["top"] < 30:
                        ref = lines[i-1]["x0"]
                    if ref is None: continue
                    d = ln["x0"] - ref
                    if 6 <= d <= 16:
                        starts.append(ln["text"])
    return starts
