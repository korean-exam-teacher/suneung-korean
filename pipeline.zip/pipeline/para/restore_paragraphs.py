# ===== detect.py =====
# -*- coding: utf-8 -*-
"""문제지 PDF에서 '문단 첫 줄'(들여쓰기된 줄)을 찾아 그 줄의 앞부분 글자를 돌려준다.
2단 편집이라 왼쪽/오른쪽 단을 나눠서 보고, 같은 단 안 주변 줄의 왼쪽 끝(가장 흔한 x0)보다
대략 한 글자(6~16pt) 안쪽에서 시작하는 줄을 문단 첫 줄로 본다."""
import pdfplumber, re
from collections import Counter, defaultdict

SKIP = re.compile(r"^(\[|［|①|②|③|④|⑤|\d+\.|\(가\)|\(나\)|\(다\)|\(라\)|<|＜|\*|※|-)")

def page_lines(pg):
    words = pg.extract_words(use_text_flow=False, keep_blank_chars=False)
    mid = pg.width/2
    cols = {"L":defaultdict(list),"R":defaultdict(list)}
    for w in words:
        side = "L" if w["x0"] < mid else "R"
        cols[side][round(w["top"]/3)].append(w)
    out = {}
    for side, d in cols.items():
        lines=[]
        for k in sorted(d):
            ws = sorted(d[k], key=lambda w:w["x0"])
            lines.append({"x0":ws[0]["x0"], "top":ws[0]["top"], "text":"".join(w["text"] for w in ws)})
        out[side]=lines
    return out

def para_starts(path):
    starts=[]
    with pdfplumber.open(path) as pdf:
        for pg in pdf.pages:
            for side, lines in page_lines(pg).items():
                for i, ln in enumerate(lines):
                    if SKIP.match(ln["text"]) or len(ln["text"]) < 6: continue
                    ref = None
                    # 같은 문단의 다음 줄(바로 아래, 줄 간격 이내)이 기준 왼쪽 끝이 된다
                    for nx in lines[i+1:i+3]:
                        if 0 < nx["top"] - ln["top"] < 30 and not SKIP.match(nx["text"]):
                            ref = nx["x0"]; break
                    if ref is None and i > 0 and 0 < ln["top"] - lines[i-1]["top"] < 30:
                        ref = lines[i-1]["x0"]
                    if ref is None: continue
                    d = ln["x0"] - ref
                    if 6 <= d <= 16:
                        starts.append(ln["text"])
    return starts

# ===== apply.py (산문 문단) =====
import json, re, sys, os, glob
sys.path.insert(0,".")
from detect import para_starts
SRC="/home/claude/site_v31.html"
s=open(SRC,encoding="utf-8").read().split("\n")
pi=[k for k,l in enumerate(s) if l.startswith("const PASSAGES = ")][0]
P=json.loads(s[pi][len("const PASSAGES = "):].rstrip(";"))
pdfdir="/mnt/user-data/uploads/평가원 기출 문제 모음"
def exam_of(fn):
    m=re.match(r"(\d{4})\.\s?(\d{2})",fn); return f"{m.group(1)}-{m.group(2)}"
END=set(".?!”’\"')」』…")
stats={}; newP=dict(P)
def norm_map(t):
    chars=[];idx=[]
    for i,c in enumerate(t):
        if not c.isspace(): chars.append(c); idx.append(i)
    return "".join(chars), idx
for f in sorted(glob.glob(pdfdir+"/20*.pdf")):
    ex=exam_of(os.path.basename(f))
    if int(ex[:4])<2018: continue
    keys=[k for k in P if k.startswith(ex+"||")]
    if not keys: stats[ex]="no passages"; continue
    starts=para_starts(f)
    normed={k:norm_map(newP[k]) for k in keys}
    ins={k:set() for k in keys}; hit=0
    for st in starts:
        snip=st[:14]
        if len(snip)<10: continue
        found=[(k,m.start()) for k in keys for m in re.finditer(re.escape(snip), normed[k][0])]
        if len(found)!=1: continue
        k,pos=found[0]
        if pos==0: continue
        prev=normed[k][0][pos-1]
        if prev not in END: continue
        ins[k].add(normed[k][1][pos]); hit+=1
    for k in keys:
        t=newP[k]
        for i in sorted(ins[k],reverse=True):
            # 앞쪽 공백을 줄바꿈으로 바꾼다(글자는 그대로)
            j=i
            while j>0 and t[j-1]==" ": j-=1
            if j>0 and t[j-1]=="\n": continue
            t=t[:j]+"\n"+t[i:]
        newP[k]=t
    stats[ex]=(len(starts),hit,sum(1 for k in keys if ins[k]),len(keys))
for k,v in stats.items(): print(k,v)
json.dump(newP,open("/home/claude/para/passages_para.json","w",encoding="utf-8"),ensure_ascii=False)

# ===== poems.py (시·시가 행/연) =====
import json, re, sys, os, glob, statistics
sys.path.insert(0,".")
import pdfplumber
from detect import page_lines
SRC="/home/claude/site_v31.html"
s=open(SRC,encoding="utf-8").read().split("\n")
def load(n):
    i=[k for k,l in enumerate(s) if l.startswith(f"const {n} = ")][0]; return json.loads(s[i][len(f"const {n} = "):].rstrip(";"))
items=load("ITEMS")
P=json.load(open("passages_para.json",encoding="utf-8"))
POEM={"현대시","고전시가"}
poemkeys={}
for it in items:
    if it["영역"]=="문학" and it["갈래"] and set(it["갈래"])<=POEM:
        poemkeys[f'{it["exam_id"]}||{it["영역"]}||{it["지문범위"]}']=1
pdfdir="/mnt/user-data/uploads/평가원 기출 문제 모음"
def exam_of(fn):
    m=re.match(r"(\d{4})\.\s?(\d{2})",fn); return f"{m.group(1)}-{m.group(2)}"
def norm_map(t):
    chars=[];idx=[]
    for i,c in enumerate(t):
        if not c.isspace(): chars.append(c); idx.append(i)
    return "".join(chars), idx
report={}
for f in sorted(glob.glob(pdfdir+"/20*.pdf")):
    ex=exam_of(os.path.basename(f))
    keys=[k for k in poemkeys if k.startswith(ex+"||")]
    if not keys: continue
    seq=[]
    with pdfplumber.open(f) as pdf:
        for pi,pg in enumerate(pdf.pages):
            cols=page_lines(pg)
            for side in ("L","R"):
                for ln in cols[side]: seq.append((pi,side,ln))
    for k in keys:
        N,idx=norm_map(P[k])
        breaks={}  # orig index -> "\n" or "\n\n"
        ptr=None; prev=None; misses=0; gaps=[]
        matched=[]
        for (pi,side,ln) in seq:
            t=re.sub(r"\s","",ln["text"])
            if not t: continue
            snip=t[:8]
            if ptr is None:
                if len(t)>=6:
                    pos=N.find(snip)
                    if 0<=pos<=8: ptr=pos; matched.append((pos,pi,side,ln)); ptr=pos+len(t); misses=0
                continue
            pos=N.find(snip, max(0,ptr-6), ptr+30)
            if pos>=0:
                matched.append((pos,pi,side,ln)); ptr=max(ptr,pos+len(t)); misses=0
            else:
                misses+=1
                if misses>60: break
        # spacing for stanza gaps
        sp=[b[3]["top"]-a[3]["top"] for a,b in zip(matched,matched[1:]) if a[1]==b[1] and a[2]==b[2] and 0<b[3]["top"]-a[3]["top"]<60]
        med=statistics.median(sp) if sp else 18
        for j,(pos,pi,side,ln) in enumerate(matched):
            if pos==0: continue
            gap = j>0 and matched[j-1][1]==pi and matched[j-1][2]==side and ln["top"]-matched[j-1][3]["top"]>med*1.6
            breaks[idx[pos]]="\n\n" if gap else "\n"
        t=P[k]
        for i in sorted(breaks,reverse=True):
            j=i
            while j>0 and t[j-1]==" ": j-=1
            if t[j-1:j]=="\n": continue
            t=t[:j]+breaks[i]+t[i:]
        cover = (matched[-1][0]/len(N)) if matched else 0
        report[k]=(len(matched), round(cover,2))
        P[k]=t
for k,v in report.items(): print(k,v)
json.dump(P,open("passages_para2.json","w",encoding="utf-8"),ensure_ascii=False)
