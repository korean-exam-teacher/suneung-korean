import json, re, sys, os, glob
sys.path.insert(0,".")
from detect import para_starts
SRC="/home/claude/site_v31.html"
s=open(SRC,encoding="utf-8").read().split("\n")
pi=[k for k,l in enumerate(s) if l.startswith("const PASSAGES = ")][0]
P=json.loads(s[pi][len("const PASSAGES = "):].rstrip(";"))
pdfdir="/mnt/user-data/uploads/평가원 기출 문제 모음"
def exam_of(fn):
    m=re.match(r"(\d{4})\.\s?(\d{2})",fn); return f"{m.group(1)}-{m.group(2)}"
END=set(".?!”’\"')」』…")
stats={}; newP=dict(P)
def norm_map(t):
    chars=[];idx=[]
    for i,c in enumerate(t):
        if not c.isspace(): chars.append(c); idx.append(i)
    return "".join(chars), idx
for f in sorted(glob.glob(pdfdir+"/20*.pdf")):
    ex=exam_of(os.path.basename(f))
    if int(ex[:4])<2018: continue
    keys=[k for k in P if k.startswith(ex+"||")]
    if not keys: stats[ex]="no passages"; continue
    starts=para_starts(f)
    normed={k:norm_map(newP[k]) for k in keys}
    ins={k:set() for k in keys}; hit=0
    for st in starts:
        snip=st[:14]
        if len(snip)<10: continue
        found=[(k,m.start()) for k in keys for m in re.finditer(re.escape(snip), normed[k][0])]
        if len(found)!=1: continue
        k,pos=found[0]
        if pos==0: continue
        prev=normed[k][0][pos-1]
        if prev not in END: continue
        ins[k].add(normed[k][1][pos]); hit+=1
    for k in keys:
        t=newP[k]
        for i in sorted(ins[k],reverse=True):
            # 앞쪽 공백을 줄바꿈으로 바꾼다(글자는 그대로)
            j=i
            while j>0 and t[j-1]==" ": j-=1
            if j>0 and t[j-1]=="\n": continue
            t=t[:j]+"\n"+t[i:]
        newP[k]=t
    stats[ex]=(len(starts),hit,sum(1 for k in keys if ins[k]),len(keys))
for k,v in stats.items(): print(k,v)
json.dump(newP,open("/home/claude/para/passages_para.json","w",encoding="utf-8"),ensure_ascii=False)
