import pdfplumber, re, json, sys
F = "/root/.claude/uploads/7b612bc6-ce88-5a44-acc7-f627887d12f2/263908d1-______2014_______________.pdf"
out = []
with pdfplumber.open(F) as pdf:
    for pi, pg in enumerate(pdf.pages):
        pg = pg.dedupe_chars(); W = pg.width; H = pg.height
        body = [c for c in pg.chars if 60 <= c["top"] <= H - 45 and c["text"].strip()]
        cov = [0] * (int(W) + 2)
        for c in body:
            for x in range(int(c["x0"]), int(c["x1"]) + 1): cov[x] += 1
        # 쪽 가운데 1/3, 2/3 근처에서 글자가 없는 세로 띠(단 사이 여백)를 찾는다
        def gutter(lo, hi):
            best = None; run = 0
            for x in range(int(lo), int(hi)):
                if cov[x] == 0:
                    run += 1
                    if best is None or run > best[1]: best = (x - run + 1, run)
                else: run = 0
            return best[0] + best[1] / 2 if best else (lo + hi) / 2
        g1 = gutter(W * 0.25, W * 0.42); g2 = gutter(W * 0.58, W * 0.75)
        cols = {0: [], 1: [], 2: []}
        for c in pg.chars:
            if c["top"] < 60 or c["top"] > H - 45: continue
            xc = (c["x0"] + c["x1"]) / 2
            k = 0 if xc < g1 else 1 if xc < g2 else 2
            cols[k].append(c)
        for k in range(3):
            cs = sorted(cols[k], key=lambda c: c["top"]); cl = []
            for c in cs:
                if cl and c["top"] - cl[-1][0] <= 3: cl[-1][1].append(c)
                else: cl.append([c["top"], [c]])
            for top, g in cl:
                g.sort(key=lambda c: c["x0"])
                t = ""; prev = None
                for c in g:
                    if prev is not None and c["text"] != " " and not t.endswith(" "):
                        if c["x0"] - prev["x1"] > 0.25 * c["size"]: t += " "
                    t += c["text"]; prev = c
                vis = [c for c in g if c["text"].strip()]
                if not vis: continue
                out.append({"pg": pi, "col": k, "top": round(top, 1), "x0": round(vis[0]["x0"], 1), "x1": round(vis[-1]["x1"], 1),
                            "size": round(max(c["size"] for c in vis), 1), "endsp": g[-1]["text"] == " ", "t": t.strip()})
json.dump(out, open("/home/claude/pre/lines.json", "w"), ensure_ascii=False)
print(len(out))
