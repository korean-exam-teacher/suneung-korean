# -*- coding: utf-8 -*-
"""2014학년도 수능 예비시행 국어 정답 및 해설(이투스청솔) → 문항별 해설·정답표.
입력: lines.json(ext.py 결과) → 출력: pre_explain.json {"2014-예비-A": {...}, "2014-예비-B": {...}}"""
import json, re
L = json.load(open("/home/claude/pre/lines.json"))
L.sort(key=lambda l: (l["pg"], l["col"], l["top"]))
CIR = "①②③④⑤"
ROW = re.compile(r"(\d{1,2})\s*([①-⑤])")
SET = re.compile(r"^\[(\d{1,2})\s*[~∼～]\s*(\d{1,2})\]\s*(.*)$")
form = None; out = {}; cur = None; cur_set = None; stray = []
def new_par(t): return bool(re.match(r"^([①-⑤㉠-㉦]|\(해설\)|\(출제의도\)|\[|<|※)", t))
for i, l in enumerate(L):
    t = l["t"].strip(); sz = l["size"]
    if "2교시" in t: break
    if not t or l["top"] >= 980: continue   # 쪽 번호·머리글 광고(“2014 입시의 리더! [이투스청솔 …]”)
    if sz >= 11:
        m = re.match(r"^([AB])\s*형$", t)
        if m:
            form = m.group(1); out[form] = {"table": {}, "items": [], "sets": []}; cur = None; cur_set = None
        continue
    if form is None: continue
    D = out[form]
    # 정답표(형 표시 바로 뒤, 크기 8, '번호 ○' 다섯 쌍)
    rows = ROW.findall(t)
    if sz == 8.0 and len(rows) == 5 and re.fullmatch(r"(\s*\d{1,2}\s*[①-⑤])+", t):
        for n, c in rows: D["table"][int(n)] = CIR.index(c) + 1
        continue
    if sz == 9.0:   # 세트 머리(두 줄일 수 있음)
        m = SET.match(t)
        if m:
            cur_set = {"range": [int(m.group(1)), int(m.group(2))], "head": m.group(3)}; D["sets"].append(cur_set); cur = None; continue
        if cur_set is not None and cur is None: cur_set["head"] += " " + t; continue
    m = re.fullmatch(r"(\d{1,2})\.\s*([①-⑤])?", t)
    if sz == 10.0 and m:
        cur = {"num": int(m.group(1)), "ans": CIR.index(m.group(2)) + 1 if m.group(2) else None, "lines": []}; D["items"].append(cur); continue
    if cur is None: stray.append((form, l["pg"], l["col"], t)); continue
    if cur["ans"] is None and not cur["lines"] and re.fullmatch(r"[①-⑤]", t):
        cur["ans"] = CIR.index(t) + 1; continue
    cur["lines"].append((t, l["endsp"]))

def join(lines):
    s = ""
    for k, (t, sp) in enumerate(lines):
        if k == 0: s = t; continue
        if new_par(t): s = s.rstrip() + "\n" + t
        else:
            # 앞줄 끝 공백 여부로 이어 붙인다
            s = s + (" " if lines[k-1][1] else "") + t
        # (출제의도)/(해설) 머리 뒤 줄바꿈 없이 이어 쓰기
    s = re.sub(r"\(해설\)\s*\n?", "(해설) ", s)
    s = s.replace("\u3000", " ")
    s = re.sub(r"\s*-\s*\d{1,2}\s*-[ \t]*(?=\n|$)", "", s)
    s = re.sub(r"[ \t]+", " ", s)
    return s.strip()

res = {}
for f, D in out.items():
    items = []
    for it in D["items"]:
        txt = join(it["lines"])
        items.append({"sec": "공통", "num": it["num"], "label": None, "ans": it["ans"], "text": txt})
    nums = [x["num"] for x in items]
    print(f, "table", len(D["table"]), "items", len(items), "seq ok", nums == list(range(1, 46)))
    mis = [(x["num"], x["ans"], D["table"].get(x["num"])) for x in items if x["ans"] != D["table"].get(x["num"])]
    print("  item-answer vs table mismatches:", mis)
    print("  sets:", [(s["range"], s["head"]) for s in D["sets"]])
    short = [(x["num"], len(x["text"])) for x in items if len(x["text"]) < 80]
    print("  short texts:", short)
    res[f"2014-예비-{f}"] = {"items": items, "sets": [], "table": {str(k): v for k, v in D["table"].items()}, "set_heads": D["sets"]}
print("stray", stray[:20])
json.dump(res, open("/home/claude/pre/pre_explain.json", "w"), ensure_ascii=False, indent=0)
