
# ==================== fixpdf/fix2.py ====================
# -*- coding: utf-8 -*-
"""한글이 텍스트로 추출되지 않는 해설 PDF 고치기.
원인: 본문 글꼴이 사용자 정의 인코딩 CMap(WinCharSetFFFF)을 쓰고, ToUnicode가 없거나(2018) 코드 기준이 어긋나(2012) 추출기가 글자를 잃는다.
방법: (1) 글꼴 인코딩을 Identity-H로 바꾸고 본문 문자열의 코드를 CID로 다시 쓴다.
      (2) CID→유니코드 표(ToUnicode)를 새로 만든다.
         - 기존 ToUnicode가 있으면(코드 기준) 그대로 CID 기준으로 옮긴다.
         - 없으면 같은 글꼴 파일을 공유하는 다른 글꼴의 ToUnicode(GID 기준)와,
           함초롬바탕 계열의 한글 글리프 배열(GID = 기준값 + (코드포인트 - U+AC00))로 채운다.
           기준값은 같은 글꼴을 공유하는 글꼴의 ToUnicode에서 확인하거나, 지정한 값으로 둔다."""
import pikepdf, re, sys, json
from collections import Counter

def parse_enc_cmap(data):
    m = {}; txt = data.decode("latin-1")
    for blk in re.findall(r"begincidrange(.*?)endcidrange", txt, re.S):
        for a, b, c in re.findall(r"<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>\s*(\d+)", blk):
            a, b, c = int(a, 16), int(b, 16), int(c)
            for k in range(a, b+1): m[k] = c + (k - a)
    for blk in re.findall(r"begincidchar(.*?)endcidchar", txt, re.S):
        for a, c in re.findall(r"<([0-9a-fA-F]+)>\s*(\d+)", blk): m[int(a, 16)] = int(c)
    return m

def tounicode(stream):
    t = stream.read_bytes().decode("latin-1"); m = {}
    for blk in re.findall(r"beginbfchar(.*?)endbfchar", t, re.S):
        for a, b in re.findall(r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", blk):
            try: m[int(a, 16)] = bytes.fromhex(b).decode("utf-16-be")
            except Exception: pass
    for blk in re.findall(r"beginbfrange(.*?)endbfrange", t, re.S):
        for a, b, c in re.findall(r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", blk):
            a, b = int(a, 16), int(b, 16); base = int(c, 16)
            for k in range(a, b+1): m[k] = chr(base + k - a)
    return m

def c2g_of(d):
    m = d.get("/CIDToGIDMap")
    if m is None or isinstance(m, pikepdf.Name): return None
    raw = m.read_bytes(); return [int.from_bytes(raw[i:i+2], "big") for i in range(0, len(raw), 2)]

def make_tounicode(pdf, cid2u):
    lines = ["/CIDInit /ProcSet findresource begin", "12 dict begin", "begincmap",
             "/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def",
             "/CMapName /Fixed-UCS def", "/CMapType 2 def", "1 begincodespacerange", "<0000> <FFFF>", "endcodespacerange"]
    items = sorted(cid2u.items())
    for i in range(0, len(items), 100):
        chunk = items[i:i+100]
        lines.append(f"{len(chunk)} beginbfchar")
        for c, u in chunk: lines.append(f"<{c:04X}> <{u.encode('utf-16-be', 'surrogatepass').hex().upper()}>")
        lines.append("endbfchar")
    lines += ["endcmap", "CMapName currentdict /CMap defineresource pop", "end", "end"]
    return pdf.make_stream("\n".join(lines).encode())

def fix(src, dst, hangul_base=None):
    pdf = pikepdf.open(src)
    # 1) 글꼴 파일(Descendant)별 GID→유니코드 단서 모으기
    gid_u = {}      # descendant objgen -> {gid: u}
    for page in pdf.pages:
        for name, f in page.Resources.get("/Font", {}).items():
            if f.get("/Subtype") != "/Type0" or "/ToUnicode" not in f: continue
            d = f.DescendantFonts[0]; c2g = c2g_of(d); tu = tounicode(f.ToUnicode)
            enc = f.Encoding
            code2cid = parse_enc_cmap(enc.read_bytes()) if isinstance(enc, pikepdf.Stream) else None
            for code, u in tu.items():
                cid = code2cid.get(code) if code2cid is not None else code
                if cid is None: continue
                g = c2g[cid] if c2g and cid < len(c2g) else cid
                gid_u.setdefault(d.FontDescriptor.objgen, {})[g] = u
    # 한글 글리프 기준값 확인(같은 글꼴의 한글 단서에서)
    bases = {}
    for k, m in gid_u.items():
        offs = Counter(g - (ord(u) - 0xAC00) for g, u in m.items() if len(u) == 1 and "가" <= u <= "힣")
        if offs: bases[k] = offs.most_common(1)[0][0]
    report = []
    # 2) 사용자 정의 인코딩 글꼴 고치기
    fixed = {}
    for page in pdf.pages:
        fonts = page.Resources.get("/Font", {})
        targets = {}
        for name, f in fonts.items():
            if f.get("/Subtype") != "/Type0": continue
            key = f.objgen
            enc = f.Encoding
            if key in fixed: targets[str(name)] = fixed[key]; continue
            if not isinstance(enc, pikepdf.Stream): continue
            if key not in fixed:
                code2cid = parse_enc_cmap(enc.read_bytes())
                d = f.DescendantFonts[0]; c2g = c2g_of(d); fd = d.FontDescriptor.objgen
                base = bases.get(fd, hangul_base)
                known = gid_u.get(fd, {})
                own = tounicode(f.ToUnicode) if "/ToUnicode" in f else {}
                cid2u = {}
                for code, cid in code2cid.items():
                    u = own.get(code)
                    if u is None:
                        g = c2g[cid] if c2g and cid < len(c2g) else cid
                        u = known.get(g)
                        if u is None and base is not None and 0 <= g - base < 11172: u = chr(0xAC00 + g - base)
                    if u: cid2u[cid] = u
                f.Encoding = pikepdf.Name("/Identity-H")
                f.ToUnicode = make_tounicode(pdf, cid2u)
                fixed[key] = code2cid
                report.append((str(name), len(code2cid), len(cid2u), base))
            targets[str(name)] = fixed[key]
        if not targets: continue
        # 3) 본문 문자열을 코드→CID로 다시 쓰기
        ops = pikepdf.parse_content_stream(page)
        cur = None; out = []
        def conv(b, m):
            r = bytearray()
            for i in range(0, len(b) - 1, 2):
                c = int.from_bytes(b[i:i+2], "big"); cid = m.get(c, 0)
                r += cid.to_bytes(2, "big")
            return pikepdf.String(bytes(r))
        for operands, op in ops:
            o = str(op)
            if o == "Tf": cur = str(operands[0])
            elif cur in targets and o in ("Tj", "'", '"'):
                operands = list(operands); operands[-1] = conv(bytes(operands[-1]), targets[cur])
            elif cur in targets and o == "TJ":
                arr = pikepdf.Array([conv(bytes(x), targets[cur]) if isinstance(x, pikepdf.String) else x for x in operands[0]])
                operands = [arr]
            out.append((operands, op))
        page.Contents = pdf.make_stream(pikepdf.unparse_content_stream(out))
    pdf.save(dst)
    return report, bases

if __name__ == "__main__":
    rep, bases = fix(sys.argv[1], sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else None)
    print(rep); print({str(k): v for k, v in bases.items()})

# ==================== hsj/extra2.py ====================
import json, re, sys, pdfplumber
sys.path.insert(0, "/home/claude/hsj")
src = open("/home/claude/hsj/dump.py").read().split("out = {}")[0]
ns = {}; exec(src, ns); lines_page = ns["lines_page"]
H = json.load(open("/home/claude/hsj/hsj_lines.json"))
# 2018 수능 해설: 글꼴에 유니코드 정보가 없던 글자(문맥으로 확정 가능한 것만 치환, 나머지는 □)
CID_FIX = {"24858": "「", "24859": "」", "24786": " :", "24788": "<", "1347": "艱", "3664": "風", "3268": "霜", "3152": "隨", "2948": "關"}
def clean(t):
    return re.sub(r"\(cid:(\d+)\)", lambda m: CID_FIX.get(m.group(1), "□"), t)
for ex, path in [("2012-11", "/home/claude/fixpdf/2012-11_fixed.pdf"), ("2018-11", "/home/claude/fixpdf/2018-11_fixed.pdf")]:
    with pdfplumber.open(path) as pdf:
        sample = "".join(c["text"] for pg in pdf.pages[1:3] for c in pg.chars)
        hs = sample.count(" ") / max(len(sample), 1) > 0.08
        pages = []
        for pg in pdf.pages:
            L = lines_page(pg.dedupe_chars(), hs)[0]
            for l in L: l["t"] = clean(l["t"])
            pages.append(L)
    H[ex] = {"file": path, "has_space": hs, "pages": pages, "ncol": [1]*len(pages)}
    print(ex, hs, len(pages))
json.dump(H, open("/home/claude/hsj/hsj_lines.json", "w"), ensure_ascii=False)

# ==================== hwp/build_new.py ====================
# -*- coding: utf-8 -*-
"""HWP 문제지(2009 수능, 2014 수능 A/B)로 사이트 형식의 문항·지문·선택지 묶음을 만든다 → new_bundle.json"""
import json, re, sys
from collections import Counter, defaultdict
sys.path.insert(0, "/home/claude/hwp"); sys.path.insert(0, "/home/claude/typegroup"); sys.path.insert(0, "/home/claude/old")
from parse_items import parse, passage_text
from para2 import pua
import type_groups as TG

P = json.load(open("/home/claude/hwp/hwp_paras.json"))
T = json.load(open("/home/claude/hsj/answer_tables.json"))

EXAMS = {
    "2014-11-A": dict(y=2014, form="A", name="2014학년도 대학수학능력시험(A형)", first=1),
    "2014-11-B": dict(y=2014, form="B", name="2014학년도 대학수학능력시험(B형)", first=1),
    "2009-11": dict(y=2009, form="", name="2009학년도 대학수학능력시험", first=6),
    "2009-09": dict(y=2009, form="", name="2009학년도 9월 모의평가", first=6, mon=9, kind="평가원 모의평가", paras="2009-09n"),
}
def area_of(ex, n):
    if ex == "2009-09":
        if n <= 10: return "화법과 작문"
        if n <= 12: return "언어와 매체"
        if 20 <= n <= 23 or 28 <= n <= 33 or 38 <= n <= 40 or n >= 47: return "문학"
        return "독서"
    if ex == "2009-11":
        if n <= 10: return "화법과 작문"
        if n <= 12: return "언어와 매체"
        if 20 <= n <= 23 or 28 <= n <= 33 or 37 <= n <= 39 or n >= 47: return "문학"
        return "독서"
    lang_end = 15 if ex.endswith("A") else 16
    if n <= 10: return "화법과 작문"
    if n <= lang_end: return "언어와 매체"
    return "독서" if n <= 30 else "문학"

# 지문 묶음별 소재·분야·작품 (분야·제목은 해당 회차 「정답 및 해설」의 지문 머리말을 따름)
W38 = ["왕방연, 「천만리 머나먼 길에」", "임제, 「청초 우거진 골에」", "원천석, 「흥망이 유수하니」"]
L = {
 ("2014-11-A", 1): ("전교 학생 회장 선거 출마를 고민하는 친구 간의 대화", "화법(대화)", []),
 ("2014-11-A", 4): ("엑스선으로 밝혀낸 고흐 작품의 비밀 학생 발표", "화법(발표)", []),
 ("2014-11-A", 6): ("청소년 UCC 제작 기술 프로그램 제작 건의 글 초고", "작문(건의문)", []),
 ("2014-11-A", 9): ("나눔 도서관을 소개하는 게시판 글과 고쳐 쓰기", "작문(소개하는 글)", []),
 ("2014-11-A", 16): ("분광 분석법의 창안과 과학적 성과", "과학(화학)", []),
 ("2014-11-A", 19): ("선암사 승선교에 담긴 미의식", "예술(건축)", []),
 ("2014-11-A", 22): ("토인비의 문명 단위 역사 연구", "인문(역사학)", []),
 ("2014-11-A", 24): ("간접 광고(PPL)의 이해", "사회(광고)", []),
 ("2014-11-A", 28): ("CD 드라이브의 정보 판독 원리", "기술(정보 저장)", []),
 ("2014-11-A", 31): ("꽃이 지는 모습에서 발견한 이별과 성숙(현대시)", "현대시", ["이형기, 「낙화(洛花)」"]),
 ("2014-11-A", 34): ("아파트 입주권 문제로 고통받는 난장이 가족(현대소설)", "현대소설", ["조세희, 「난장이가 쏘아 올린 작은 공」"]),
 ("2014-11-A", 38): ("임과의 이별·죽음, 왕조의 흥망에 대한 회한(시조)", "고전시가(시조)", W38),
 ("2014-11-A", 41): ("임금에게 자신의 처지를 아뢰고 하직하는 길동(고전소설)", "고전소설", ["허균, 「홍길동전」"]),
 ("2014-11-A", 44): ("소를 바라보며 느끼는 권태(수필)", "수필", ["이상, 「권태」"]),
 ("2014-11-B", 1): ("공장 이전을 둘러싼 회사와 시청의 모의 협상", "화법(협상)", []),
 ("2014-11-B", 4): ("엑스선으로 밝혀낸 고흐 작품의 비밀 학생 발표", "화법(발표)", []),
 ("2014-11-B", 6): ("생태 관광의 문제점과 개선 방안 논설문 자료와 개요", "작문(논설문)", []),
 ("2014-11-B", 9): ("나눔 도서관을 소개하는 게시판 글과 고쳐 쓰기", "작문(소개하는 글)", []),
 ("2014-11-B", 17): ("이덕무 「사소절」에 나타난 독서 태도", "인문(독서 이론)", []),
 ("2014-11-B", 19): ("심신 이원론과 심신 일원론", "인문(철학)", []),
 ("2014-11-B", 22): ("간접 광고(PPL)의 이해", "사회(광고)", []),
 ("2014-11-B", 26): ("지구 상에서 운동하는 물체에 작용하는 전향력", "과학(지구과학)", []),
 ("2014-11-B", 28): ("베토벤 교향곡의 음악사적 의의", "예술(음악)", []),
 ("2014-11-B", 31): ("꿈속에서 보살을 만난 강남홍(고전소설)", "고전소설", ["남영로, 「옥루몽」"]),
 ("2014-11-B", 35): ("어둠과 전짓불을 두려워하는 박준(현대소설)", "현대소설", ["이청준, 「소문의 벽」"]),
 ("2014-11-B", 38): ("임과의 이별·죽음, 왕조의 흥망에 대한 회한(시조)", "고전시가(시조)", W38),
 ("2014-11-B", 41): ("비 오는 저녁의 그리움과 막차를 기다리는 대합실 풍경(현대시)", "현대시", ["조지훈, 「파초우(芭蕉雨)」", "곽재구, 「사평역에서」"]),
 ("2014-11-B", 44): ("소를 바라보며 느끼는 권태(수필)", "수필", ["이상, 「권태」"]),
 ("2009-09", 13): ("디지털 영상 처리 기술과 사진의 조작", "기술(영상 처리)", []),
 ("2009-09", 16): ("영웅의 창조와 전승 과정", "인문(역사학)", []),
 ("2009-09", 20): ("가난한 흥보 가족의 해학적인 대화(고전소설)", "고전소설(판소리계)", ["작자 미상, 「박흥보전」"]),
 ("2009-09", 24): ("영화의 리얼리즘 미학에 관한 바쟁의 영화관", "예술(영화)", []),
 ("2009-09", 28): ("이상 세계에 대한 동경과 삶의 성찰(현대시·고전시가)", "현대시·고전시가 복합", ["서정주, 「꽃밭의 독백-사소(娑蘇) 단장」", "신경림, 「나무를 위하여」", "안조원, 「만언사」"]),
 ("2009-09", 34): ("화행 이론에서 발화의 적절성 조건", "인문(언어학)", []),
 ("2009-09", 38): ("허구의 이리 떼로 유지되는 마을의 질서(희곡)", "희곡", ["이강백, 「파수꾼」"]),
 ("2009-09", 41): ("과거의 대기 성분과 기온 변화를 알려 주는 남극 빙하", "과학(지구과학)", []),
 ("2009-09", 44): ("여론 조사 결과 공표가 선거에 미치는 영향", "사회(정치·언론)", []),
 ("2009-09", 47): ("밀회 약속과 어머니 곁 사이에서 갈등하는 '그'(현대소설)", "현대소설", ["오상원, 「모반」"]),
 ("2009-11", 9): ("공공건물 벽화 그리기 축제 프로그램 제안서 초고", "작문(제안서)", []),
 ("2009-11", 13): ("옛 문헌의 문장 부호", "인문(국어학)", []),
 ("2009-11", 16): ("각 시대의 음악 양식에 적용된 반복의 양상", "예술(음악)", []),
 ("2009-11", 20): ("성벽의 돌을 맨손으로 옮기는 서씨를 목격한 '나'(현대소설)", "현대소설", ["김승옥, 「역사(力士)」"]),
 ("2009-11", 24): ("창조 도시의 근본 동력과 환경", "사회(도시)", []),
 ("2009-11", 28): ("이별한 임에 대한 그리움(현대시·고전시가)", "현대시·고전시가 복합", ["한용운, 「님의 침묵」", "김광규, 「나뭇잎 하나」", "작자 미상, 「춘면곡(春眠曲)」"]),
 ("2009-11", 34): ("공룡 발자국 화석 연구와 그 의미", "과학(지구과학)", []),
 ("2009-11", 37): ("철거민 가족의 삶(시나리오)", "시나리오", ["홍파 각색, 「난쟁이가 쏘아 올린 작은 공」"]),
 ("2009-11", 40): ("집단 수준의 인과: 필연성과 개연성", "인문(철학)", []),
 ("2009-11", 43): ("동영상 압축 기술의 원리", "기술(정보 통신)", []),
 ("2009-11", 47): ("박 처사의 청혼과 상공 집안의 혼인(고전소설)", "고전소설", ["작자 미상, 「박씨전」"]),
}
def genres(area, f):
    g = []
    if area == "문학":
        if "현대시" in f: g.append("현대시")
        if "현대소설" in f: g.append("현대소설")
        if "고전시가" in f: g.append("고전시가")
        if "고전소설" in f: g.append("고전소설")
        if "극" in f or "시나리오" in f or "희곡" in f: g.append("극·시나리오")
        if "수필" in f: g.append("수필")
    elif area == "독서":
        if f.startswith(("인문", "예술")): g.append("인문·예술")
        elif f.startswith("사회"): g.append("사회·문화")
        elif f.startswith(("과학", "기술")): g.append("과학·기술")
    return g
def reform(area, grp):
    if area == "독서": return "독서와 작문"
    if area == "문학": return "문학"
    if area == "언어와 매체": return "화법과 언어"
    return "화법과 언어" if grp.startswith("화법") else "독서와 작문"

FN = re.compile(r"\*\s?([^\s*:：][^*:：\n]{0,28}?)\s*[:：]\s*([^*\n]+?)(?=\s*\*\s?[^\s*:：][^*:：\n]{0,28}?\s*[:：]|\s*\n|\s*$)")
WORD_OK = re.compile(r"^[가-힣A-Za-z0-9◯ㄱ-ㅎ][^’‘“”\"]{0,20}$")

ITEMS = []; PAS = {}; CHO = {}; NOTES = {}; REPORT = Counter()
for ex, meta in EXAMS.items():
    sets, items = parse(P[meta.get("paras", ex)])
    tb = T.get(ex, {}).get("공통", {})
    setinfo = {s["range"]: s for s in sets}
    for it in items:
        n = it["num"]
        if n < meta["first"]: continue
        area = area_of(ex, n)
        rng = it["set"]
        r = f"{rng[0]}~{rng[1]}" if rng else "(독립 문항)"
        stem = pua(it["stem"])
        pts = 3 if "[3점]" in stem else 1 if "[1점]" in stem else 2
        rec = {"연도": meta["y"], "시행월": meta.get("mon", 11), "시행유형": meta.get("kind", "대학수학능력시험"), "명칭": meta["name"], "exam_id": ex,
               "문항번호": n, "영역": area, "지문범위": r, "발문": stem, "배점": pts,
               "정답": tb.get(str(n)), "보기": pua("\n".join(it["bogi"])).strip()}
        if meta["form"]: rec["형"] = meta["form"]
        if rng:
            lab = L.get((ex, rng[0]))
            rec["소재"], rec["분야"], rec["작품"] = lab if lab else ("(미분류)", "(미분류)", [])
            if not lab: REPORT["no label " + r] += 1
        else:
            rec["소재"], rec["분야"], rec["작품"] = "", "", []
        rec["작품"] = list(rec["작품"]); rec["갈래"] = genres(area, rec["분야"])
        ch = it["choices"]
        if len(ch) == 5:
            CHO[f"{ex}||{area}||{n}"] = [pua(ch[k]).strip() for k in range(1, 6)]
        else: REPORT["no choices"] += 1
        ITEMS.append(rec)
    for s in sets:
        a, b = s["range"]
        if a < meta["first"]: continue
        t = pua(passage_text(s["lines"]))
        if len(re.sub(r"\s", "", t)) < 150: REPORT["passage too short (image) " + ex + f" {a}~{b}"] += 1; continue
        PAS[f"{ex}||{area_of(ex, a)}||{a}~{b}"] = t

# 배점은 정답표(answer_keys_2009_2017.json)를 따른다
K = json.load(open("/mnt/user-data/outputs/answer_keys_2009_2017.json"))
for it in ITEMS:
    ak = K.get(it["exam_id"], {}).get(str(it["문항번호"]))
    if ak:
        if it["정답"] is None: it["정답"] = ak[0]
        assert it["정답"] == ak[0], (it["exam_id"], it["문항번호"])
        if it["배점"] != ak[1]: REPORT["배점 보정"] += 1; it["배점"] = ak[1]

# 낱말 풀이·지문 길이
LEN = {}
for k, v in PAS.items():
    notes = [[m.group(1).strip(), m.group(2).strip(), m.group(0)] for m in FN.finditer(v) if WORD_OK.match(m.group(1).strip()) and len(m.group(2)) <= 150]
    body = v
    for nt in notes: body = body.replace(nt[2], "")
    if notes: NOTES[k] = notes
    LEN[k] = len(body.strip())
for it in ITEMS:
    L_ = LEN.get(f'{it["exam_id"]}||{it["영역"]}||{it["지문범위"]}', 0)
    it["지문길이"] = L_ if L_ >= 100 else 0
print("items", len(ITEMS), "passages", len(PAS), "choices", len(CHO), "notes", sum(len(v) for v in NOTES.values()))
print(REPORT)
print(Counter((i["exam_id"], i["정답"] is not None) for i in ITEMS))
print("배점 합계", {ex: sum(i["배점"] for i in ITEMS if i["exam_id"] == ex) for ex in EXAMS})
json.dump({"items": ITEMS, "passages": PAS, "choices": CHO, "notes": NOTES}, open("/home/claude/hwp/new_bundle.json", "w"), ensure_ascii=False)

# ==================== hsj/integrate.py ====================
# -*- coding: utf-8 -*-
"""정답 및 해설(원자료)로 정답·유형·해설을 사이트 데이터에 반영한다.
입력: site_v34.html, explains.json, answer_tables.json  →  출력: integ.json"""
import json, re, sys
from collections import Counter, defaultdict
sys.path.insert(0, "/home/claude/typegroup")
import type_groups as TG

s = open("/home/claude/site_v34.html", encoding="utf-8").read().split("\n")
def load(n): return json.loads([l for l in s if l.startswith(f"const {n} = ")][0][len(f"const {n} = "):].rstrip(";"))
ITEMS = load("ITEMS"); PASSAGES = load("PASSAGES"); CHOICES = load("CHOICES")
E = json.load(open("/home/claude/hsj/explains.json"))
T = json.load(open("/home/claude/hsj/answer_tables.json"))

def hkey(ex): return "2012-06?" if ex == "2012-06" else ex
def sec_of(it):
    if it["exam_id"] >= "2022": return "공통" if it["영역"] in ("독서", "문학") else it["영역"]
    return "공통"
def src_for(it):
    k = hkey(it["exam_id"])
    if it["exam_id"] >= "2022" and it["영역"] == "언어와 매체": k += "#B"
    return E.get(k)

# ---------- 해설 유형 이름 → 유형 묶음 ----------
def has(t, *ws): return any(w in t for w in ws)
ALLOWED = {"독서": {"독서"}, "문학": {"문학"}, "화법과 작문": {"화법", "작문"}, "언어와 매체": {"문법", "매체"}}
def label_group(label, it):
    area = it["영역"]
    if label in TG.RAW_MAP and TG.GROUP_OF.get(TG.RAW_MAP[label]) in ALLOWED.get(area, set()):
        g = TG.RAW_MAP[label]
        # 화법과 작문 영역에서는 지문 분야(화법/작문)와 묶음이 어긋나면 키워드 규칙으로 다시 판정
        indep = it.get("지문범위") == "(독립 문항)"
        if area != "화법과 작문" or indep or (TG.GROUP_OF[g] == "화법") == str(it.get("분야", "")).startswith("화법"):
            return g
    t = label
    if area == "독서":
        if has(t, "어휘", "단어의 의미", "바꿔 쓰", "바꾸어 쓰", "사전적 의미", "문맥적 의미"): return "어휘의 문맥적 의미"
        if has(t, "전개 방식", "서술 방식", "글의 구조", "전개 양상", "서술상"): return "글의 구조·전개 방식"
        if has(t, "관점", "견해", "입장"): return "견해·관점 비교"
        if has(t, "적용", "사례", "상황"): return "구체적 사례·상황 적용"
        if has(t, "비판", "평가", "타당", "반박", "비평"): return "비판적 이해·평가"
        if has(t, "관계", "인과", "상관", "비교", "대조"): return "정보 간의 관계 파악"
        if has(t, "추론", "미루어", "추리", "전제"): return "내용 추론"
        if has(t, "독서 방법", "읽기 방법", "독서 활동", "독서 과정", "읽기 과정", "독서의 방법"): return "독서 방법·활동"
        if has(t, "세부", "핵심", "중심", "정보", "일치", "내용 파악", "내용 이해", "내용 확인", "화제"): return "세부·핵심 내용 파악"
        return None
    if area == "문학":
        if has(t, "외적 준거", "외재적", "<보기>", "보기를"): return "외적 준거에 따른 감상"
        if has(t, "공통점", "차이점", "작품 간", "작품의 비교", "비교"): return "작품 간 비교"
        if has(t, "화자", "서술자", "어조", "정서"): return "화자·서술자의 태도·정서"
        if has(t, "인물", "심리", "성격"): return "인물의 심리·태도·성격"
        if has(t, "표현", "서술상", "서술 방식", "서술의 특징", "수사", "형식", "구성"): return "표현·서술상의 특징"
        if has(t, "시어", "시구", "구절", "어구", "단어의 의미", "의미 파악"): return "시어·시구·구절의 의미"
        if has(t, "소재", "배경", "기능", "역할", "공간"): return "소재·배경의 기능"
        if has(t, "주제", "작가", "의도"): return "주제 의식·작가의 관점"
        if has(t, "감상", "반응", "수용", "평가", "이해와 감상"): return "작품 감상·수용"
        if has(t, "내용", "상황", "사건", "종합적 이해", "이해", "줄거리"): return "작품 내용·상황 이해"
        return None
    if area == "화법과 작문":
        f = "" if it.get("지문범위") == "(독립 문항)" else str(it.get("분야", ""))
        speech = f.startswith("화법") if (f.startswith("화법") or f.startswith("작문")) and not f.startswith("화법·작문") and not f.startswith("화법과 작문") else \
                 has(t + it["발문"], "말하기", "듣기", "화법", "토론", "토의", "발표", "대화", "면접", "협상", "강연", "연설", "청중", "발화", "담화")
        if speech:
            if has(t, "자료", "매체"): return "화법: 자료·매체 활용"
            if has(t, "계획", "내용 생성", "조직", "구성"): return "화법: 내용 생성·조직"
            if has(t, "전략", "방식", "표현", "태도"): return "화법: 말하기 방식·표현 전략"
            return "화법: 내용 이해·평가"
        if has(t, "고쳐", "퇴고", "수정", "점검", "비문", "어휘 선택", "문장 다듬"): return "작문: 점검·고쳐쓰기"
        if has(t, "자료"): return "작문: 자료·매체 활용"
        if has(t, "계획", "맥락", "독자", "목적"): return "작문: 계획·맥락 반영"
        if has(t, "표현", "조건", "전략", "제목", "글쓰기"): return "작문: 표현 전략"
        if has(t, "내용 생성", "개요", "조직", "내용", "생성"): return "작문: 내용 생성·조직"
        return None
    if area == "언어와 매체":
        if has(t, "매체"):
            if has(t, "표현"): return "매체 언어의 표현 방법"
            if has(t, "수용", "제작", "생산"): return "매체 자료의 수용·제작"
            return "매체의 특성·정보 구성"
        if has(t, "음운", "발음", "음절", "자음", "모음"): return "음운·음운 변동"
        if has(t, "중세", "국어사", "변천", "옛", "고대", "근대 국어", "훈민정음"): return "중세 국어·국어의 변천"
        if has(t, "맞춤법", "표준어", "표기", "로마자", "외래어", "띄어쓰기", "사이시옷", "어문 규범"): return "한글 맞춤법·표준어 규정"
        if has(t, "형태소", "단어 형성", "단어의 형성", "파생", "합성", "조어", "단어의 구조"): return "형태소·단어 형성"
        if has(t, "높임", "시제", "시간 표현", "피동", "사동", "부정 표현", "문법 요소", "인용", "종결 표현"): return "문법 요소"
        if has(t, "문장 성분", "문장의 짜임", "안은", "이어진", "홑문장", "겹문장", "서술어", "자릿수", "문장 구조", "문장의 구조"): return "문장 성분·문장의 짜임"
        if has(t, "품사", "용언", "활용", "어미", "조사", "체언"): return "품사·용언의 활용"
        if has(t, "의미 관계", "어휘", "다의어", "동음이의어", "반의어", "유의어", "사전", "단어의 의미"): return "어휘와 의미"
        if has(t, "담화", "지시 표현"): return "담화의 특성"
        return None
    return None

# 역량: 같은 유형 묶음 문항에 절반 이상 붙은 역량
gs = defaultdict(Counter); gn = Counter()
for it in ITEMS:
    if it["exam_id"] >= "2022":
        gn[it["유형묶음"]] += 1
        for sk in it.get("역량", []): gs[it["유형묶음"]][sk] += 1
SKILL_OF = {g: [sk for sk, c in gs[g].most_common() if c >= gn[g]*0.5] for g in gn}

# 새로 합류하는 회차(HWP 문제지: 2009 수능, 2014 수능 A/B)
NB = json.load(open("/home/claude/hwp/new_bundle.json"))
for it in NB["items"]:
    ch = NB["choices"].get(f'{it["exam_id"]}||{it["영역"]}||{it["문항번호"]}')
    it["유형"] = "미분류(수동 확인 필요)"
    g, _ = TG.group_for(it, ch)
    if g == "미분류":
        g = "화법: 내용 이해·평가" if it["영역"] == "화법과 작문" and str(it.get("분야","")).startswith("화법") else ("작문: 내용 생성·조직" if it["영역"] == "화법과 작문" else g)
    it["유형묶음"] = g; it["유형갈래"] = TG.GROUP_OF.get(g, "미분류")
    it["역량"] = SKILL_OF.get(g, [])
    it["개편매핑_과목"] = ("독서와 작문" if it["영역"] == "독서" else "문학" if it["영역"] == "문학" else "화법과 언어" if it["영역"] == "언어와 매체" else ("화법과 언어" if g.startswith("화법") else "독서와 작문"))
    ITEMS.append(it)
PASSAGES.update(NB["passages"])

stat = Counter(); changes = []; EXPLAIN = {}; LABELMISS = Counter()
for it in ITEMS:
    ex = it["exam_id"]; key = f'{ex}||{it["영역"]}||{it["문항번호"]}'
    sec = sec_of(it)
    # 1) 정답
    tb = T.get(hkey(ex), {}).get(sec, {})
    a = tb.get(str(it["문항번호"]))
    if a:
        if it["정답"] is None: it["정답"] = a; stat["answer filled"] += 1; changes.append((key, None, a))
        elif it["정답"] != a:
            src0 = src_for(it); ea = None
            if src0:
                c = [x for x in src0["items"] if x["num"] == it["문항번호"] and x["sec"] == sec]
                if len(c) == 1: ea = c[0]["ans"]
            if ea == it["정답"]:
                stat["table typo kept existing"] += 1   # 해설 본문 정답과 기존 정답이 같으면 정답표 쪽 오타로 본다
            else:
                changes.append((key, it["정답"], a)); it["정답"] = a; stat["answer corrected"] += 1
        else: stat["answer same"] += 1
        it["_정답출처"] = "정답및해설(원자료)"
    else:
        stat["answer no table"] += 1
    # 2) 해설
    src = src_for(it)
    hit = None
    if src:
        cands = [x for x in src["items"] if x["num"] == it["문항번호"] and x["sec"] == sec]
        if len(cands) == 1: hit = cands[0]
    if not hit: stat["no explanation"] += 1; continue
    if hit["ans"] and a and hit["ans"] != a: stat["explain-answer conflict"] += 1
    txt = hit["text"].strip()
    if len(txt) >= 40: EXPLAIN[key] = txt; stat["explanation"] += 1
    # 3) 유형 (2009~2021학년도만: 2022~는 이미 원자료로 확인됨)
    if ex < "2022" and hit["label"] and len(hit["label"]) <= 60:
        lab = re.sub(r"\s+", " ", hit["label"]).strip(" .")
        g = label_group(lab, it)
        it["유형_해설확인"] = lab
        if g:
            old = it["유형묶음"]
            it["유형"] = lab; it["유형묶음"] = g; it["유형갈래"] = TG.GROUP_OF.get(g, it["유형갈래"])
            it["_유형출처"] = "정답및해설(원자료)"
            it.pop("_유형재분류", None); it.pop("_ebs_매칭", None); it.pop("유형_EBS", None)
            if old != g:
                stat["group changed"] += 1
                it["역량"] = SKILL_OF.get(g, it.get("역량", []))
            stat["type verified"] += 1
        else:
            LABELMISS[(it["영역"], lab)] += 1; stat["label unmapped"] += 1

# 독립 문항의 분야·소재는 최종 유형 묶음에 맞춘다(화법 독립 문항이 '작문'으로 잘못 붙어 있던 것 바로잡기)
for it in ITEMS:
    if it["지문범위"] != "(독립 문항)" or it["exam_id"] >= "2018": continue
    g = it["유형묶음"]
    if it["영역"] == "화법과 작문":
        f = "화법(독립 문항)" if g.startswith("화법") else "작문(독립 문항)"
        if it.get("분야") != f: stat["indep field fixed"] += 1
        it["분야"] = f
    elif it["영역"] == "언어와 매체":
        it["분야"] = "문법(독립 문항)"
    it["소재"] = f"{g.replace('화법: ','').replace('작문: ','')} (독립 문항)"
    it["개편매핑_과목"] = "화법과 언어" if it["영역"] == "언어와 매체" or g.startswith("화법") else "독서와 작문"

# 2018~2021학년도: 공식 해설 유형 이름을 못 얻은 문항은 EBS 대조 결과도 믿기 어려우므로 '유형 확인' 표시를 뗀다
for it in ITEMS:
    if "2018" <= it["exam_id"] < "2022" and it.get("_유형출처") != "정답및해설(원자료)":
        if it.get("_유형출처") or it.get("_ebs_매칭"):
            it["_유형재분류"] = True; stat["2018-21 ebs type unverified"] += 1

# 해설 원문의 정답 표기가 정답표와 다르면(해설 쪽 오기) 안내를 붙인다
CIRC = "①②③④⑤"
for it in ITEMS:
    key = f'{it["exam_id"]}||{it["영역"]}||{it["문항번호"]}'
    t = EXPLAIN.get(key)
    if not t or not it["정답"]: continue
    m = re.search(r"(?:\[정답\]|정답|\[답\])\s*:?\s*([①-⑤])", t)
    if m and CIRC.index(m.group(1)) + 1 != it["정답"]:
        EXPLAIN[key] = t + f"\n※ 해설 원문에 적힌 정답({m.group(1)})이 정답표의 정답({CIRC[it['정답']-1]})과 다릅니다. 해설 원문의 오기로 보이며, 정답표 기준 정답은 {CIRC[it['정답']-1]}입니다."
        stat["explain answer typo noted"] += 1; print("typo note", key, m.group(1), it["정답"])

# 지문 해설
PEXPLAIN = {}
area_of = {}
for it in ITEMS: area_of[(it["exam_id"], sec_of(it), it["문항번호"])] = it["영역"]
for ex in sorted({i["exam_id"] for i in ITEMS}):
    for k in [hkey(ex), hkey(ex) + "#B"]:
        if k not in E: continue
        for st in E[k]["sets"]:
            if "지문해설" not in st["text"][:20]: continue
            a, b = st["range"]
            area = area_of.get((ex, st["sec"], a))
            if not area: continue
            pk = f"{ex}||{area}||{a}~{b}"
            if pk in PASSAGES and pk not in PEXPLAIN:
                PEXPLAIN[pk] = st["text"].strip()
print(stat); print("passage explanations", len(PEXPLAIN))
print("unmapped labels", len(LABELMISS)); print(LABELMISS.most_common(40))
json.dump({"items": ITEMS, "explain": EXPLAIN, "pexplain": PEXPLAIN, "changes": changes}, open("/home/claude/hsj/integ.json", "w"), ensure_ascii=False)

# ==================== merge_v36.py ====================
# -*- coding: utf-8 -*-
"""merge_v35(정답·유형·해설 반영)을 다시 돌린 뒤, HWP로 새로 합류한 회차(2009 수능, 2014 수능 A/B)의 지문·선택지를 넣고 안내문을 고친다 → site_v36.html"""
import json, subprocess, re
subprocess.run(["python3", "/home/claude/merge_v35.py"], check=True)
SRC = "/home/claude/site_v35.html"; DST = "/home/claude/site_v36.html"
NB = json.load(open("/home/claude/hwp/new_bundle.json", encoding="utf-8"))
lines = open(SRC, encoding="utf-8").read().split("\n")
def idx(n): return [k for k, l in enumerate(lines) if l.startswith(f"const {n} = ")][0]
def load(n): return json.loads(lines[idx(n)][len(f"const {n} = "):].rstrip(";"))
def save(n, v): lines[idx(n)] = f"const {n} = " + json.dumps(v, ensure_ascii=False) + ";"
PAS = load("PASSAGES"); CHO = load("CHOICES"); NOTES = load("PASSAGE_NOTES")
for k in NB["passages"]: assert k not in PAS, k
PAS.update(NB["passages"]); CHO.update(NB["choices"]); NOTES.update(NB["notes"])
save("PASSAGES", PAS); save("CHOICES", CHO); save("PASSAGE_NOTES", NOTES)
s = "\n".join(lines)
ITEMS = load("ITEMS")
n_all = len(ITEMS); n_old = sum(1 for i in ITEMS if i["exam_id"] < "2018")
n_exams = len({i["exam_id"] for i in ITEMS}); n_old_exams = len({i["exam_id"] for i in ITEMS if i["exam_id"] < "2018"})
ans_old = sum(1 for i in ITEMS if i["exam_id"] < "2018" and i["정답"])
def ver(i): return (not i.get("_유형재분류")) and bool(i.get("_유형출처") or i.get("_ebs_매칭") == "passage_anchor")
v_all = sum(1 for i in ITEMS if ver(i)); v_old = sum(1 for i in ITEMS if i["exam_id"] < "2018" and ver(i))
v_1821 = sum(1 for i in ITEMS if "2018" <= i["exam_id"] < "2022" and ver(i))
n_h = sum(1 for i in ITEMS if i.get("_h"))
f = lambda n: f"{n:,}"

def rep(old, new, cnt=1):
    global s
    assert s.count(old) == cnt, (s.count(old), old[:80])
    s = s.replace(old, new)

rep("""  '2009-9': '2009학년도 9월 모의평가: 확보한 문제지가 스캔 이미지뿐이라 아직 싣지 못했습니다.',
  '2009-11': '2009학년도 수능: 확보한 문제지가 스캔 이미지뿐이라 아직 싣지 못했습니다.',
  '2014-11': '2014학년도 수능(A형·B형): 확보한 문제지가 스캔 이미지뿐이라 아직 싣지 못했습니다.',
""", "")
rep(" 미수록 회차는 원본 문제지가 스캔 이미지뿐이라 글자를 옮기지 못한 회차입니다.", "")
rep("모두 63개 회차 3,022문항을", f"모두 {n_exams}개 회차 {f(n_all)}문항을")
rep("<p><b>2009~2017학년도</b>(34개 회차, 1,530문항): 2009학년도 6월, 2010~2013학년도 6월·9월·수능, 2014학년도 6월·9월(A·B형)과 예비 시행(A·B형), 2015·2016학년도 6월·9월·수능(A·B형), 2017학년도 6월·9월·수능. 2009학년도 9월·수능과 2014학년도 수능은 확보한 문제지가 스캔 이미지뿐이라 아직 싣지 못했습니다(표에 \"미수록\"으로 표시). 정답은 확보한 정답표로 1,440문항에 반영했고,",
    f"<p><b>2009~2017학년도</b>({n_old_exams}개 회차, {f(n_old)}문항): 2009학년도 6월·9월·수능, 2010~2013학년도 6월·9월·수능, 2014학년도 6월·9월·수능(A·B형)과 예비 시행(A·B형), 2015·2016학년도 6월·9월·수능(A·B형), 2017학년도 6월·9월·수능. 2009학년도 9월·수능과 2014학년도 수능(A·B형)은 PDF가 스캔 이미지라 한글(HWP) 문제지 파일에서 옮겼습니다. 2014학년도 수능(A·B형)의 9~10번 지문(신문 기사·게시판 글)과 9번 선택지는 원본 파일에서도 그림이라 싣지 못했습니다. 정답은 확보한 정답표로 {f(ans_old)}문항에 반영했고,")
rep("(\"유형 확인\" 표시, 전체 3,022문항 중 2,593문항). 2009~2017학년도는 1,530문항 중 1,273문항, 2018~2021학년도는 540문항 중 438문항을",
    f"(\"유형 확인\" 표시, 전체 {f(n_all)}문항 중 {f(v_all)}문항). 2009~2017학년도는 {f(n_old)}문항 중 {f(v_old)}문항, 2018~2021학년도는 540문항 중 {v_1821}문항을")
rep("「정답 및 해설」로 확인하지 못한 문항(2018학년도 6월·수능 등 해설 파일의 글자가 그림이라 읽을 수 없는 회차)은",
    "「정답 및 해설」에 유형 이름이 없거나 유형 이름을 묶음에 대응시키지 못한 문항은")
rep("2009~2027학년도 문항 중 2,678문항에 해설이 있습니다. 해설 파일의 글자가 그림이라 읽을 수 없는 회차(2012학년도·2017학년도·2018학년도 수능, 2018학년도 6월), 해설 파일이 없는 회차(2023학년도 9월, 2014학년도 예비 시행)와 일부 문항은 해설이 없습니다.",
    f"2009~2027학년도 문항 중 {f(n_h)}문항에 해설이 있습니다. 해설 파일이 없는 회차(2023학년도 9월, 2014학년도 예비 시행)와 일부 문항은 해설이 없습니다. 2017학년도 수능 해설은 EBS 해설 파일, 2018학년도 6월 해설은 한글(HWP) 해설 파일에서 옮겼고, 2012·2018학년도 수능 해설은 PDF 안 글꼴의 글자 정보가 깨져 있어 글꼴 내부의 글자 배열로 되살렸습니다(되살리지 못한 옛한글 몇 글자는 □로 표시). 해설 원문의 정답 표기가 정답표와 다른 경우(해설 쪽 오기)에는 해설 아래에 안내를 붙였습니다.")
open(DST, "w", encoding="utf-8").write(s)
print("ok", n_all, n_exams, "verified", v_all, "explained", n_h, len(s.encode())/1e6, "MB")
