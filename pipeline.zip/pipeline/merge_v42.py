#!/usr/bin/env python3
"""Version 49: 2022학년도 수능 예시문항(공통+선택 체제, 56문항)을 전개년 기출문제에 넣는다.
merge_v41.py → site_v41.html → (이 단계) → site_v42.html. 자료: /home/claude/ex22/out.json (ex22/assemble.py)"""
import json, re, sys, subprocess
subprocess.run([sys.executable, '/home/claude/merge_v41.py'], check=True)
s = open('/home/claude/site_v41.html', encoding='utf-8').read()
D = json.load(open('/home/claude/ex22/out.json', encoding='utf-8'))
def setconst(name, fn):
    global s
    m = re.search(rf'^const {name} = (.*);$', s, re.M)
    v = fn(json.loads(m.group(1)))
    s = s[:m.start(1)] + json.dumps(v, ensure_ascii=False) + s[m.end(1):]
def rep(old, new, count=1):
    global s
    n = s.count(old)
    if n != count: sys.exit(f'patch miss ({n} != {count}): {old[:80]!r}')
    s = s.replace(old, new)
setconst('ITEMS', lambda v: [i for i in v if i['exam_id'] != '2022-예시'] + D['items'])
setconst('PASSAGES', lambda v: {**v, **D['passages']})
setconst('CHOICES', lambda v: {**v, **D['choices']})
setconst('PASSAGE_NOTES', lambda v: {**v, **D['notes']})
# 회차 이름·순서·표
rep("  if(m === '예비') return {code:`${y}`, kind:`예비 시행${form}`};",
    "  if(m === '예비') return {code:`${y}`, kind:`예비 시행${form}`};\n  if(m === '예시') return {code:`${y}`, kind:'예시문항'};")
rep("  const mm = m === '예비' ? 0 : (Number(m) || 0);", "  const mm = (m === '예비' || m === '예시') ? 0 : (Number(m) || 0);")
rep("    const col = m === '예비' ? 'pre' : Number(m);", "    const col = (m === '예비' || m === '예시') ? 'pre' : Number(m);")
rep("    const name = `${y}학년도 ${LABEL[col]}${f ? ` ${f}형` : ''}`;",
    "    const name = `${y}학년도 ${id.includes('예시') ? '예시문항' : LABEL[col]}${f ? ` ${f}형` : ''}`;")
rep("""    if(byYear[y].pre) h += `<tr class="pre-row"><td>${y}학년도 <small>예비 시행</small></td><td colspan="3" class="pre-cell">${btns(y,'pre',byYear[y].pre)}<span class="pre-note">수준별 국어 도입 전 ${Number(y)-2}년에 시행</span></td></tr>`;""",
    """    if(byYear[y].pre){
      const ex = byYear[y].pre.some(id=>id.includes('예시'));
      h += `<tr class="pre-row"><td>${y}학년도 <small>${ex ? '예시문항' : '예비 시행'}</small></td><td colspan="3" class="pre-cell">${btns(y,'pre',byYear[y].pre)}<span class="pre-note">${ex ? '공통+선택 과목 체제 도입을 앞두고 평가원이 공개한 예시문항(실제 시행되지 않음)' : `수준별 국어 도입 전 ${Number(y)-2}년에 시행`}</span></td></tr>`;
    }""")
# 이용 안내
rep('모두 67개 회차 3,202문항을', '모두 68개 회차 3,258문항(2022학년도 수능 예시문항 56문항 포함)을')
rep('3,202문항 중 2,924문항', '3,258문항 중 2,924문항')
rep('3,202문항 중 3,194문항의 선택지', '3,258문항 중 3,250문항의 선택지')
rep('<b>2018~2027학년도</b>:', '<b>2022학년도 수능 예시문항</b>: 공통 과목(독서·문학) 34문항과 선택 과목(화법과 작문·언어와 매체) 각 11문항, 모두 56문항입니다. 평가원 예시문항 문제지 PDF에서 글자 단위로 옮겼고, 정답·배점은 평가원 「2022학년도 대학수학능력시험 예시문항 정답표」로 넣었습니다(공통 과목 배점 합 76점 일치 확인). 표·도식·그래프·매체 화면은 원본 문제지에서 잘라 낸 그림으로 함께 보여 줍니다. 유형과 소재 표시는 해설 자료 없이 문항 내용을 보고 붙인 것이라 "유형 확인" 표시가 없습니다. 실제로 시행된 시험이 아니므로 회차 표에서는 "예시문항" 줄로 따로 보입니다.</p>\n        <p><b>2018~2027학년도</b>:')
open('/home/claude/site_v42.html', 'w', encoding='utf-8').write(s)
print('ok', len(s))
