# ===== pre/ext.py (3단 PDF → 줄) =====
import pdfplumber, re, json, sys
F = "/root/.claude/uploads/7b612bc6-ce88-5a44-acc7-f627887d12f2/263908d1-______2014_______________.pdf"
out = []
with pdfplumber.open(F) as pdf:
    for pi, pg in enumerate(pdf.pages):
        pg = pg.dedupe_chars(); W = pg.width; H = pg.height
        body = [c for c in pg.chars if 60 <= c["top"] <= H - 45 and c["text"].strip()]
        cov = [0] * (int(W) + 2)
        for c in body:
            for x in range(int(c["x0"]), int(c["x1"]) + 1): cov[x] += 1
        # 쪽 가운데 1/3, 2/3 근처에서 글자가 없는 세로 띠(단 사이 여백)를 찾는다
        def gutter(lo, hi):
            best = None; run = 0
            for x in range(int(lo), int(hi)):
                if cov[x] == 0:
                    run += 1
                    if best is None or run > best[1]: best = (x - run + 1, run)
                else: run = 0
            return best[0] + best[1] / 2 if best else (lo + hi) / 2
        g1 = gutter(W * 0.25, W * 0.42); g2 = gutter(W * 0.58, W * 0.75)
        cols = {0: [], 1: [], 2: []}
        for c in pg.chars:
            if c["top"] < 60 or c["top"] > H - 45: continue
            xc = (c["x0"] + c["x1"]) / 2
            k = 0 if xc < g1 else 1 if xc < g2 else 2
            cols[k].append(c)
        for k in range(3):
            cs = sorted(cols[k], key=lambda c: c["top"]); cl = []
            for c in cs:
                if cl and c["top"] - cl[-1][0] <= 3: cl[-1][1].append(c)
                else: cl.append([c["top"], [c]])
            for top, g in cl:
                g.sort(key=lambda c: c["x0"])
                t = ""; prev = None
                for c in g:
                    if prev is not None and c["text"] != " " and not t.endswith(" "):
                        if c["x0"] - prev["x1"] > 0.25 * c["size"]: t += " "
                    t += c["text"]; prev = c
                vis = [c for c in g if c["text"].strip()]
                if not vis: continue
                out.append({"pg": pi, "col": k, "top": round(top, 1), "x0": round(vis[0]["x0"], 1), "x1": round(vis[-1]["x1"], 1),
                            "size": round(max(c["size"] for c in vis), 1), "endsp": g[-1]["text"] == " ", "t": t.strip()})
json.dump(out, open("/home/claude/pre/lines.json", "w"), ensure_ascii=False)
print(len(out))

# ===== pre/parse.py (줄 → 문항별 해설·정답표) =====
# -*- coding: utf-8 -*-
"""2014학년도 수능 예비시행 국어 정답 및 해설(이투스청솔) → 문항별 해설·정답표.
입력: lines.json(ext.py 결과) → 출력: pre_explain.json {"2014-예비-A": {...}, "2014-예비-B": {...}}"""
import json, re
L = json.load(open("/home/claude/pre/lines.json"))
L.sort(key=lambda l: (l["pg"], l["col"], l["top"]))
CIR = "①②③④⑤"
ROW = re.compile(r"(\d{1,2})\s*([①-⑤])")
SET = re.compile(r"^\[(\d{1,2})\s*[~∼～]\s*(\d{1,2})\]\s*(.*)$")
form = None; out = {}; cur = None; cur_set = None; stray = []
def new_par(t): return bool(re.match(r"^([①-⑤㉠-㉦]|\(해설\)|\(출제의도\)|\[|<|※)", t))
for i, l in enumerate(L):
    t = l["t"].strip(); sz = l["size"]
    if "2교시" in t: break
    if not t or l["top"] >= 980: continue   # 쪽 번호·머리글 광고(“2014 입시의 리더! [이투스청솔 …]”)
    if sz >= 11:
        m = re.match(r"^([AB])\s*형$", t)
        if m:
            form = m.group(1); out[form] = {"table": {}, "items": [], "sets": []}; cur = None; cur_set = None
        continue
    if form is None: continue
    D = out[form]
    # 정답표(형 표시 바로 뒤, 크기 8, '번호 ○' 다섯 쌍)
    rows = ROW.findall(t)
    if sz == 8.0 and len(rows) == 5 and re.fullmatch(r"(\s*\d{1,2}\s*[①-⑤])+", t):
        for n, c in rows: D["table"][int(n)] = CIR.index(c) + 1
        continue
    if sz == 9.0:   # 세트 머리(두 줄일 수 있음)
        m = SET.match(t)
        if m:
            cur_set = {"range": [int(m.group(1)), int(m.group(2))], "head": m.group(3)}; D["sets"].append(cur_set); cur = None; continue
        if cur_set is not None and cur is None: cur_set["head"] += " " + t; continue
    m = re.fullmatch(r"(\d{1,2})\.\s*([①-⑤])?", t)
    if sz == 10.0 and m:
        cur = {"num": int(m.group(1)), "ans": CIR.index(m.group(2)) + 1 if m.group(2) else None, "lines": []}; D["items"].append(cur); continue
    if cur is None: stray.append((form, l["pg"], l["col"], t)); continue
    if cur["ans"] is None and not cur["lines"] and re.fullmatch(r"[①-⑤]", t):
        cur["ans"] = CIR.index(t) + 1; continue
    cur["lines"].append((t, l["endsp"]))

def join(lines):
    s = ""
    for k, (t, sp) in enumerate(lines):
        if k == 0: s = t; continue
        if new_par(t): s = s.rstrip() + "\n" + t
        else:
            # 앞줄 끝 공백 여부로 이어 붙인다
            s = s + (" " if lines[k-1][1] else "") + t
        # (출제의도)/(해설) 머리 뒤 줄바꿈 없이 이어 쓰기
    s = re.sub(r"\(해설\)\s*\n?", "(해설) ", s)
    s = s.replace("\u3000", " ")
    s = re.sub(r"\s*-\s*\d{1,2}\s*-[ \t]*(?=\n|$)", "", s)
    s = re.sub(r"[ \t]+", " ", s)
    return s.strip()

res = {}
for f, D in out.items():
    items = []
    for it in D["items"]:
        txt = join(it["lines"])
        items.append({"sec": "공통", "num": it["num"], "label": None, "ans": it["ans"], "text": txt})
    nums = [x["num"] for x in items]
    print(f, "table", len(D["table"]), "items", len(items), "seq ok", nums == list(range(1, 46)))
    mis = [(x["num"], x["ans"], D["table"].get(x["num"])) for x in items if x["ans"] != D["table"].get(x["num"])]
    print("  item-answer vs table mismatches:", mis)
    print("  sets:", [(s["range"], s["head"]) for s in D["sets"]])
    short = [(x["num"], len(x["text"])) for x in items if len(x["text"]) < 80]
    print("  short texts:", short)
    res[f"2014-예비-{f}"] = {"items": items, "sets": [], "table": {str(k): v for k, v in D["table"].items()}, "set_heads": D["sets"]}
print("stray", stray[:20])
json.dump(res, open("/home/claude/pre/pre_explain.json", "w"), ensure_ascii=False, indent=0)

# ===== hsj/pre_hsj.py (explains.json·answer_tables.json에 넣기) =====
# -*- coding: utf-8 -*-
"""2014학년도 수능 예비시행(A·B형) 해설·정답표를 explains.json, answer_tables.json에 넣는다.
원자료: 이투스청솔 교육평가연구소 「2014 수능 예비시험 정답 및 해설」(사용 허락 받음) → /home/claude/pre/parse.py 결과(pre_explain.json).
answers.py 다음, integrate.py 앞에 돌린다."""
import json
P = json.load(open("/home/claude/pre/pre_explain.json"))
E = json.load(open("/home/claude/hsj/explains.json"))
T = json.load(open("/home/claude/hsj/answer_tables.json"))
NOTE = "\n※ 2014학년도 예비 시행의 정답과 해설은 이투스청솔 교육평가연구소의 「2014 수능 예비시험 정답 및 해설」에서 옮겼습니다(평가원 공식 해설이 아닙니다)."
for ex, D in P.items():
    items = []
    for x in D["items"]:
        assert x["ans"] == D["table"][str(x["num"])], (ex, x["num"])   # 문항별 정답 표기 = 정답표
        items.append({**x, "text": x["text"] + NOTE})
    E[ex] = {"items": items, "sets": []}
    T[ex] = {"공통": {k: v for k, v in D["table"].items()}}
    print(ex, len(items), "answers", len(D["table"]))
json.dump(E, open("/home/claude/hsj/explains.json", "w"), ensure_ascii=False)
json.dump(T, open("/home/claude/hsj/answer_tables.json", "w"), ensure_ascii=False)

# ===== hsj/extra3.py (2023학년도 9월 해설 PDF → hsj_lines.json) =====
import json, re, sys, pdfplumber
src = open("/home/claude/hsj/dump.py").read().split("out = {}")[0]
ns = {}; exec(src, ns); lines_page = ns["lines_page"]
H = json.load(open("/home/claude/hsj/hsj_lines.json"))
U = "/root/.claude/uploads/7b612bc6-ce88-5a44-acc7-f627887d12f2/"
for ex, f in [("2023-09", "e282a7a4-2023____9________________.pdf"), ("2023-09#B", "ff4cd4fb-2023____9________________.pdf")]:
    with pdfplumber.open(U + f) as pdf:
        sample = "".join(c["text"] for pg in pdf.pages[1:3] for c in pg.chars)
        hs = sample.count(" ") / max(len(sample), 1) > 0.08
        pages = []; nc = []
        for pg in pdf.pages:
            L, k = lines_page(pg.dedupe_chars(), hs); pages.append(L); nc.append(k)
    H[ex] = {"file": f, "has_space": hs, "pages": pages, "ncol": nc}
    print(ex, hs, len(pages), "".join(map(str, nc)))
json.dump(H, open("/home/claude/hsj/hsj_lines.json", "w"), ensure_ascii=False)
