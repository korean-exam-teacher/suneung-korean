import json, re, sys
sys.path.insert(0, '/home/claude/chk'); sys.path.insert(0, '/home/claude/fig/tools')
from openpyxl import load_workbook
from pua_map import READ, compose, EXTRA
from box import HDR
wb = load_workbook("/home/claude/chk/직접확인_목록_원본.xlsx"); ws = wb["2 옛한글·기호(글자별)"]
CODE = {}
for r in ws.iter_rows(min_row=2, values_only=True):
    num, code, typed = r[0].split("-")[1], r[2], r[6]
    if typed: CODE[chr(int(code[2:], 16))] = typed
    elif num in READ: CODE[chr(int(code[2:], 16))] = compose(READ[num])
CODE["\U000f0854"] = "『"; CODE["\U000f0855"] = "』"; CODE.update(EXTRA)
def fix(t): return ''.join(CODE.get(c, '□' if (0xE000 <= ord(c) <= 0xF8FF or ord(c) >= 0xF0000) else c) for c in t)
L = json.load(open('/home/claude/chk/streams2/2022-예시.json'))
L.sort(key=lambda l: (l['pg'], l['col'], l['top']))
def junk(l):
    t = l['t'].strip()
    if not t: return True
    if l['top'] < 140 and (HDR.match(t) or len(t) <= 30 and re.search(r'(예시문항 문제지|제 1 교시|홀수형|국어 영역)', t)): return True
    if '저작권' in t and '평가원' in t: return True
    if re.fullmatch(r'\d{1,2}(\s+\d{1,2})?', t): return True
    return False
def area(pg, n):
    if pg <= 11: return '공통'
    return '화법과 작문' if pg <= 15 else '언어와 매체'
lines = []
stop = False
for l in L:
    if junk(l): continue
    t = l['t'].strip()
    if t.startswith('* 확인 사항') or t.startswith('◦ 답안지') or t == '하시오.' and lines and '확인' in lines[-1]['t']:
        continue
    t2 = fix(t); ts2 = fix(l.get('ts', t)).strip()
    if (re.search(r'[가-힣]{12,}', t2) and ts2.count(' ') > t2.count(' ')) or ts2.count(' ') >= t2.count(' ') + 3:
        u = ts2
        u = re.sub(r'^(\d{1,2}\.)(?=\S)', r'\1 ', u)
        u = re.sub(r'([①②③④⑤])(?=\S)', r'\1 ', u)
        u = re.sub(r'([㉠-㉦ⓐ-ⓔ㉮-㉲]):(?=\S)', r'\1: ', u)
        t2 = u
    lines.append(dict(l, t=t2, ts=ts2))
json.dump(lines, open('/home/claude/ex22/lines.json', 'w', encoding='utf-8'), ensure_ascii=False)
# 덩어리 나누기
SET = re.compile(r'^\[(\d{1,2})\s*[～~∼]\s*(\d{1,2})\]\s*(.*)')
ITEM = re.compile(r'^(\d{1,2})\.\s*(.*)')
blocks = []; cur = None; part = None; expect = {}
for l in lines:
    t = l['t']; ar = area(l['pg'], 0)
    m = SET.match(t)
    if m:
        cur = {'kind': 'set', 'area': ar, 'range': (int(m.group(1)), int(m.group(2))), 'head': [l], 'body': []}; blocks.append(cur); part = 'head'; expect[ar] = int(m.group(1)); continue
    m = ITEM.match(t)
    if m and int(m.group(1)) == expect.get(ar, 1):
        expect[ar] = int(m.group(1)) + 1
        cur = {'kind': 'item', 'area': ar, 'num': int(m.group(1)), 'lines': [l]}; blocks.append(cur); continue
    if cur is None: continue
    if cur['kind'] == 'set':
        if part == 'head' and not re.match(r'^(\(가\)|\[|<|\()', t) and len(cur['head']) < 3 and cur['head'][-1]['t'].rstrip().endswith(('하여','이고,','따라','는','과','와','고,','이며,','메신저로','인터넷', '서로')) :
            cur['head'].append(l); continue
        part = 'body'; cur['body'].append(l)
    else:
        cur['lines'].append(l)
json.dump(blocks, open('/home/claude/ex22/blocks.json', 'w', encoding='utf-8'), ensure_ascii=False)
for b in blocks:
    if b['kind'] == 'set': print('SET', b['area'], b['range'], ' / '.join(x['t'] for x in b['head'])[:90], len(b['body']))
    else: print('  ', b['area'], b['num'], b['lines'][0]['t'][:50], len(b['lines']))
