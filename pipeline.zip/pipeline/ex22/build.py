import json, re, collections
blocks = json.load(open('/home/claude/ex22/blocks.json', encoding='utf-8'))
lines = json.load(open('/home/claude/ex22/lines.json', encoding='utf-8'))
colR = collections.defaultdict(float); colL = collections.defaultdict(lambda: 9999)
for l in lines:
    k = (l['pg'], l['col']); colR[k] = max(colR[k], l['x1']); colL[k] = min(colL[k], l['x0'])
def join(ls, verse=False):
    out = ''
    for i, l in enumerate(ls):
        t = l['t']
        if i == 0: out = t; continue
        p = ls[i-1]; k = (p['pg'], p['col'])
        samecol = (l['pg'], l['col']) == k
        gap = l['top'] - p['top'] if samecol else 18.4
        short = p['x1'] < colR[k] - 14
        indent = l['x0'] - colL[(l['pg'], l['col'])] > 6
        if gap > 30: out += '\n\n' + t if verse else '\n' + t
        elif short or (indent and not verse and re.match(r'^\S', t) and p['t'].rstrip().endswith(('.', '다', '?', '!', '”', '’', ')'))):
            out += '\n' + t
        else:
            out += (' ' if p.get('te') else '') + t
    return out
res = {'sets': [], 'items': []}
cur_set = None
for b in blocks:
    if b['kind'] == 'set':
        cur_set = b
        res['sets'].append({'area': b['area'], 'range': b['range'], 'head': ' '.join(x['t'] for x in b['head']), 'text': join(b['body'], verse=True), 'n': len(b['body'])})
        continue
    ls = b['lines']
    # 발문 끝
    j = 0
    while j < len(ls) - 1 and not re.search(r'(\?|\[3점\])\s*$', ls[j]['t']): j += 1
    stem = join(ls[:j+1]).replace('\n', ' ')
    k = j + 1
    while k < len(ls) and not ls[k]['t'].startswith('①'): k += 1
    bogi = join(ls[j+1:k]) if k > j + 1 else ''
    chtxt = ' '.join(x['t'] for x in ls[k:])
    parts = re.split(r'\s*([①②③④⑤])\s*', chtxt)
    ch = {}
    for a, c in zip(parts[1::2], parts[2::2]): ch.setdefault('①②③④⑤'.index(a) + 1, c.strip())
    # 줄 단위 이어 붙이기(선택지 안 줄 바꿈은 te 기준)
    chl = []; curc = None
    for x in ls[k:]:
        segs = re.split(r'(?=[①②③④⑤])', x['t'])
        for sg in segs:
            if not sg.strip(): continue
            if sg[0] in '①②③④⑤': curc = [sg[1:].strip()]; chl.append(curc)
            elif curc is not None: curc.append(('\x01' if not prevte else ' ') + sg.strip())
        prevte = x.get('te')
    choices = [''.join(c).replace('\x01', '') for c in chl]
    res['items'].append({'area': b['area'], 'num': b['num'], 'set': list(cur_set['range']) if cur_set and cur_set['area'] == b['area'] and cur_set['range'][0] <= b['num'] <= cur_set['range'][1] else None,
                         'stem': stem, 'bogi': bogi, 'choices': choices, 'pg': ls[0]['pg']})
json.dump(res, open('/home/claude/ex22/raw.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
for it in res['items']:
    flag = '' if len(it['choices']) == 5 else f' !!{len(it["choices"])}'
    print(it['area'][:2], it['num'], it['set'], flag, '|', it['stem'][:60], '| bogi', len(it['bogi']))
