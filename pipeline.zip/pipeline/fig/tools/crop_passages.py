import re, json, os, sys
sys.path.insert(0, "/home/claude/fig/tools")
from box import lines, seg_img, body, page, SC, trim, unrule
from PIL import Image, ImageOps
s = open('/home/claude/site_v40.html', encoding='utf-8').read()
items = json.loads(re.search(r'^const ITEMS = (.*);$', s, re.M).group(1))
ONLY_EX = os.environ.get('ONLY_EX')
if ONLY_EX:
    items = [i for i in items + json.loads(re.search(r'^const ITEMS_2028 = (.*);$', s, re.M).group(1)) if i['exam_id'] == ONLY_EX]
MAN_SUFFIX = ('_' + ONLY_EX) if ONLY_EX else ''
if os.environ.get('ITEMS_JSON'): items = json.load(open(os.environ['ITEMS_JSON'], encoding='utf-8'))
OUT = "/home/claude/fig/pass/"; os.makedirs(OUT, exist_ok=True)
def tight(im, pad=10, thr=235):
    im = unrule(im)
    inv = ImageOps.invert(im.point(lambda v: 255 if v > thr else v)); bb = inv.getbbox()
    if not bb: return None
    x0, y0, x1, y1 = bb
    return im.crop((max(0, x0-pad), max(0, y0-pad), min(im.width, x1+pad), min(im.height, y1+pad)))
groups = {}
for it in items:
    r = it['지문범위']
    if not r or r == '(독립 문항)': continue
    groups.setdefault((it['exam_id'], it['영역'], r), []).append(it)
# 같은 회차에서 같은 범위가 여러 영역에 있으면 시험지 순서(영역 첫 문항 등장 순)대로 몇 번째인지
order = {}
for (ex, ar, r), its in groups.items():
    order.setdefault((ex, r), []).append(ar)
AREA_SEQ = ['화법과 작문', '독서', '문학', '언어와 매체']
FORCE = set(os.environ.get('FORCE','').split(',')) - {''}
man = json.load(open(f'/home/claude/fig/pass_manifest{MAN_SUFFIX}.json')) if FORCE else {}
cache = {}
for (ex, ar, r), its in sorted(groups.items()):
    if FORCE and f'{ex}||{ar}||{r}' not in FORCE: continue
    if ex not in cache:
        try: cache[ex] = lines(ex)
        except Exception: cache[ex] = None
    L = cache[ex]
    if not L: continue
    a, b = r.split('~') if '~' in r else (r, r)
    hs = [i for i, l in enumerate(L) if re.match(rf"^\s*\[\s*{a}\s*[~～∼]\s*{b}\s*\]", l['t'])]
    if not hs: continue
    areas = order[(ex, r)]
    if len(areas) > 1 and len(hs) > 1:
        # 2022학년도 이후 선택과목: 화법과 작문이 먼저, 언어와 매체가 나중
        idx = 0 if ar == '화법과 작문' else len(hs)-1
    else: idx = 0
    i0 = hs[min(idx, len(hs)-1)]
    first = min(i['문항번호'] for i in its)
    i1 = None
    for k in range(i0+1, min(len(L), i0+400)):
        m = re.search(rf"(^|\s){first}\s*\.\s*\S", L[k]['t'])
        if m and m.start() < 12: i1 = k; break
    if i1 is None: continue
    while i0+1 < i1 and '답하시오' not in L[i0]['t'] and '답하라' not in L[i0]['t'] and (L[i0+1]['pg'], L[i0+1]['col']) == (L[i0]['pg'], L[i0]['col']) and 0 < L[i0+1]['top'] - L[i0]['top'] < 26:
        i0 += 1
    h, e = L[i0], L[i1]
    segs = []; cur = (h['pg'], h['col']); top = h.get('bot', h['top']+14) + 2
    while True:
        bt, bb, _, _ = body(L, cur[0], cur[1])
        if cur == (e['pg'], e['col']): segs.append((cur[0], cur[1], max(top, bt), e['top']-4)); break
        segs.append((cur[0], cur[1], max(top, bt), bb)); cur = (cur[0], 1) if cur[1] == 0 else (cur[0]+1, 0); top = 0
        if len(segs) > 6: break
    figs = []
    for (pg, col, t0, t1) in segs:
        ls = [l for l in L[i0+1:i1] if l['pg'] == pg and l['col'] == col and t0 - 2 <= l['top'] <= t1]
        ys = [(t0, None)] + [(l['top'], l) for l in ls] + [(t1, None)]
        prev_bot = t0; prev_line = None
        for (y, l) in ys[1:]:
            if y - prev_bot > 50:
                im = seg_img(ex, L, pg, col, prev_bot + 1, y - 2)
                ti = tight(im)
                if ti is not None and ti.height > 60 and ti.width > 150:
                    hist = ti.histogram(); ink = sum(hist[:128]) / (ti.width*ti.height)
                    if ink >= 0.02:
                        figs.append({'pg': pg, 'col': col, 'top': prev_bot+1, 'bot': y-2, 'ink': round(ink,3)})
            if l is not None: prev_bot = l.get('bot', l['top']+14); prev_line = l
    if figs or FORCE:
        out = []
        for si, sg in enumerate(segs):
            ti = trim(seg_img(ex, L, *sg))
            if ti.height < 40: continue
            fn = f"{ex}_{ar}_{r}_s{si}.png".replace(' ', '')
            ti.save(OUT + fn, optimize=True); out.append({'file': fn, 'w': ti.width, 'h': ti.height, 'seg': sg})
        man[f"{ex}||{ar}||{r}"] = {'segs': out, 'figs': figs}
json.dump(man, open(f'/home/claude/fig/pass_manifest{MAN_SUFFIX}.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
print(len(man), sum(len(v) for v in man.values()))
