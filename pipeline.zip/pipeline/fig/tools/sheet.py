import json, sys, math
from PIL import Image, ImageDraw, ImageFont
man = json.load(open(sys.argv[1])); src = sys.argv[2]; out = sys.argv[3]; start = int(sys.argv[4]); n = int(sys.argv[5])
keys = list(man.keys())[start:start+n]
try: font = ImageFont.truetype("/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc", 18)
except Exception: font = ImageFont.load_default()
TW = 330; cols = 4
cells = []
for k in keys:
    v = man[k]; fs = v if isinstance(v, list) else [v]
    for f in fs:
        im = Image.open(src + f['file']).convert('L'); s = TW / im.width
        im = im.resize((TW, max(1, int(im.height * s))))
        lab = k.replace('||', ' ')
        cells.append((lab, im))
rows = math.ceil(len(cells) / cols); H = 0; rowh = []
for r in range(rows):
    h = max(c[1].height for c in cells[r*cols:(r+1)*cols]) + 26; rowh.append(h); H += h
sheet = Image.new('L', (cols*(TW+12), H), 150); d = ImageDraw.Draw(sheet); y = 0
for r in range(rows):
    for c, (lab, im) in enumerate(cells[r*cols:(r+1)*cols]):
        x = c*(TW+12); d.rectangle([x, y, x+TW, y+24], fill=255); d.text((x+4, y+2), lab, font=font, fill=0)
        sheet.paste(im, (x, y+26))
    y += rowh[r]
sheet.save(out); print(out, sheet.size, len(cells))
