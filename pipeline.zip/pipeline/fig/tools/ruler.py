# python3 ruler.py EX PG COL TOP BOT out  -> 단 영역을 pt 눈금과 함께
import sys
sys.path.insert(0, "/home/claude/fig/tools")
from box import lines, page, body, SC
from PIL import Image, ImageDraw, ImageFont
ex, pg, col, top, bot, out = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), float(sys.argv[4]), float(sys.argv[5]), sys.argv[6]
L = lines(ex); im = page(ex, pg); bt, bb, x0, x1 = body(L, pg, col)
c = im.crop((int(x0*SC), int(top*SC), int(x1*SC), int(bot*SC))).convert('RGB')
s = 0.55; c = c.resize((int(c.width*s), int(c.height*s)))
o = Image.new('RGB', (c.width+60, c.height), 'white'); o.paste(c, (60, 0)); d = ImageDraw.Draw(o)
f = ImageFont.truetype("/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc", 13)
y = (int(top)//20+1)*20
while y < bot:
    py = (y-top)*SC*s; d.line([(40, py), (o.width, py)], fill=(255,0,0) if y%100==0 else (255,180,180)); d.text((2, py-8), str(y), font=f, fill=(200,0,0)); y += 20
o.save(out); print(out, o.size)
