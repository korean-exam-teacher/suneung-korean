import sys
from PIL import Image
fs=sys.argv[2:]; out=sys.argv[1]
ims=[Image.open(f).convert('L') for f in fs]; s=float(__import__('os').environ.get('S','0.5'))
ims=[i.resize((int(i.width*s),int(i.height*s))) for i in ims]
W=sum(i.width for i in ims)+10*len(ims);H=max(i.height for i in ims)
c=Image.new('L',(W,H),170);x=0
for i in ims: c.paste(i,(x,0)); x+=i.width+10
c.save(out); print(c.size)
