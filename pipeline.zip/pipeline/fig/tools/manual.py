# 수동 좌표로 자르기: python3 manual.py PDF PAGE(1-base) x0 y0 x1 y1 (pt) out
import sys, subprocess, os
sys.path.insert(0, "/home/claude/fig/tools")
from PIL import Image
from box import trim
f, p = sys.argv[1], int(sys.argv[2]); x0,y0,x1,y1 = map(float, sys.argv[3:7]); out = sys.argv[7]
base = f"/tmp/claude-0/M200_{abs(hash(f))}_{p}"
if not os.path.exists(base+".png"):
    subprocess.run(["pdftoppm","-r","200","-f",str(p),"-l",str(p),"-png","-singlefile",f,base],check=True,stderr=subprocess.DEVNULL)
im = Image.open(base+".png").convert("L"); sc = 200/72
o = trim(im.crop((int(x0*sc),int(y0*sc),int(x1*sc),int(y1*sc))))
o.save(out, optimize=True); print(out, o.size)
