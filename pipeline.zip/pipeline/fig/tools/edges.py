import json, sys
from PIL import Image, ImageDraw, ImageFont
man = json.load(open(sys.argv[1])); src = sys.argv[2]; out = sys.argv[3]; start=int(sys.argv[4]); n=int(sys.argv[5])
font = ImageFont.truetype("/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc", 16)
cells = []
for k in list(man)[start:start+n]:
    v = man[k]; segs = v['segs'] if isinstance(v, dict) else [v]
    for i, sg in enumerate(segs):
        im = Image.open(src + sg['file']).convert('L'); s = 440 / im.width
        im = im.resize((440, int(im.height*s)))
        t = im.crop((0, 0, 440, min(110, im.height))); b = im.crop((0, max(0, im.height-110), 440, im.height))
        c = Image.new('L', (440, 22+t.height+6+b.height), 120); c.paste(t, (0, 22)); c.paste(b, (0, 22+t.height+6))
        ImageDraw.Draw(c).rectangle([0,0,440,21], fill=255); ImageDraw.Draw(c).text((3,1), f"{k} s{i}", font=font, fill=0)
        cells.append(c)
cols = 3; rows = (len(cells)+cols-1)//cols; H = max(c.height for c in cells)
sheet = Image.new('L', (cols*450, rows*(H+8)), 80)
for i, c in enumerate(cells): sheet.paste(c, ((i%cols)*450, (i//cols)*(H+8)))
sheet.save(out); print(out, sheet.size, len(cells))
