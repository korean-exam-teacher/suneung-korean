# 페이지 단 렌더: python3 pg.py EX PG COL [top] [bot] [dpi] out
import sys, subprocess, os, json
sys.path.insert(0, "/home/claude/chk")
from streams import fname, SRC
from PIL import Image
ex, pg, col = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
top = float(sys.argv[4]) if len(sys.argv)>4 else 0; bot = float(sys.argv[5]) if len(sys.argv)>5 else 99999
dpi = int(sys.argv[6]) if len(sys.argv)>6 else 130; out = sys.argv[7] if len(sys.argv)>7 else f"/home/claude/fig/v_{ex}_{pg}_{col}.png"
base = f"/tmp/claude-0/F{dpi}_{ex}_{pg}"
if not os.path.exists(base+".png"):
    subprocess.run(["pdftoppm","-r",str(dpi),"-f",str(pg+1),"-l",str(pg+1),"-png","-singlefile",SRC+fname(ex),base],check=True,stderr=subprocess.DEVNULL)
im = Image.open(base+".png"); W,H = im.size; sc = dpi/72
x0,x1 = {0:(0,W//2+6), 1:(W//2-6,W), 2:(0,W)}[col]
im.crop((x0,int(top*sc),x1,int(min(H,bot*sc)))).save(out); print(out, im.size)
