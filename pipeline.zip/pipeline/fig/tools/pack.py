import json, os
from PIL import Image
import numpy as np
im_m = json.load(open('items_manifest.json')); p_m = json.load(open('pass_manifest.json'))
SKIP = {'2016-09-B||문학||36', '2016-09-B||문학||38'}
SEGSKIP = {'2024-11_언어와매체_35~36_s1.png'}
PSKIP = {'2016-09-B||문학||42~45', '2016-06-A||화법과 작문||8~10', '2015-09-B||화법과 작문||6~8', '2015-11-B||화법과 작문||9~10'}
OUT = 'pub/fig/'
def cuts(img):
    a = np.asarray(img); white = (a > 225).all(axis=1)
    res = []; y = 0; H = len(white)
    while y < H:
        if white[y]:
            y0 = y
            while y < H and white[y]: y += 1
            if y - y0 >= 3: res.append((y0 + y)//2)
        else: y += 1
    return res
def save(src, name):
    img = Image.open(src).convert('L')
    q = img.point(lambda v: min(255, (v // 17) * 17 + (0 if v < 238 else 255)))
    q = q.quantize(16, dither=Image.Dither.NONE) if hasattr(Image, 'Dither') else q.quantize(16)
    q.save(OUT + name, optimize=True)
    return {'f': 'fig/' + name, 'w': img.width, 'h': img.height, 'c': cuts(img)}
FIG = {'i': {}, 'p': {}}
n = 0
for k, v in im_m.items():
    if k in SKIP: continue
    n += 1; d = save('items/' + v['file'], f'i{n:03d}.png'); d['m'] = v.get('mode', 'bogi'); FIG['i'][k] = d
n = 0
for k, v in p_m.items():
    if k in PSKIP: continue
    segs = []
    for sg in v['segs']:
        if sg['h'] < 80 or sg['file'] in SEGSKIP: continue
        n += 1; segs.append(save('pass/' + sg['file'], f'p{n:03d}.png'))
    if segs: FIG['p'][k] = segs
json.dump(FIG, open('fig_index.json', 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
print(len(FIG['i']), len(FIG['p']), sum(len(x) for x in FIG['p'].values()))
