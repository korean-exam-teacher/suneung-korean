import re, json, os, sys
sys.path.insert(0, "/home/claude/fig/tools")
from box import lines, seg_img, trim, body
from PIL import Image
s = open('/home/claude/site_v40.html', encoding='utf-8').read()
items = json.loads(re.search(r'^const ITEMS = (.*);$', s, re.M).group(1))
ONLY_EX = os.environ.get('ONLY_EX')
if ONLY_EX:
    items = [i for i in items + json.loads(re.search(r'^const ITEMS_2028 = (.*);$', s, re.M).group(1)) if i['exam_id'] == ONLY_EX]
MAN_SUFFIX = ('_' + ONLY_EX) if ONLY_EX else ''
if os.environ.get('ITEMS_JSON'): items = json.load(open(os.environ['ITEMS_JSON'], encoding='utf-8'))
OUT = "/home/claude/fig/items/"; os.makedirs(OUT, exist_ok=True)
cache = {}; man = {}
OVR = {
 '2011-11||화법과 작문||8': [(3,0,213.4,530)], '2010-11||독서||21': [(5,1,195.1,455)],
 '2014-예비-B||화법과 작문||2': [(0,1,454.4,565)], '2015-06-A||언어와 매체||14': [(4,1,195.1,598)],
 '2015-06-B||언어와 매체||15': [(5,0,195.1,598)], '2020-06||화법과 작문||2': [(0,1,265.2,398)],
 '2020-11||화법과 작문||2': [(0,1,265.2,398)],
 '2024-06||화법과 작문||40': 'ch', '2019-11||독서||27': 'ch',
 '2010-09||독서||38': 'ch', '2010-11||독서||49': 'ch', '2012-06||독서||48': 'ch', '2013-06||독서||25': 'ch',
 '2013-09||독서||18': 'ch', '2014-09-A||독서||21': 'ch',
}
def locate(L, it):
    n = it['문항번호']
    stem = re.sub(r'^\s*\d+\s*\.\s*', '', it['발문']).replace(' ', '')
    for i, l in enumerate(L):
        t = l['t']; m = re.search(rf"(^|\s){n}\s*\.\s*", t)
        if not m or m.start() > 12: continue
        rest = t[m.end():].replace(' ', '')
        if rest[:6] and (stem.startswith(rest[:6]) or rest[:6].startswith(stem[:6])): return i
        h1 = re.sub(r'[^가-힣]', '', rest)[:5]; h2 = re.sub(r'[^가-힣]', '', stem)[:5]
        if len(h1) >= 4 and h1 == h2: return i
    return None
def run(only=None):
    for it in items:
        ex = it['exam_id']; key = f"{ex}||{it['영역']}||{it['문항번호']}"
        if only and key not in only: continue
        if ex not in cache:
            try: cache[ex] = lines(ex)
            except Exception: cache[ex] = None
        L = cache[ex]
        if not L: continue
        i0 = locate(L, it)
        if i0 is None: continue
        j = i0
        while j+1 < len(L) and (L[j+1]['pg'], L[j+1]['col']) == (L[j]['pg'], L[j]['col']) and L[j+1]['top']-L[j]['top'] < 26 and not L[j+1]['t'].strip().startswith('①') and not re.match(r"^\s*[<〈]\s*[^<>〈〉]{1,10}\s*[>〉]\s*$", L[j+1]['t']): j += 1
        k = j+1
        n1 = it['문항번호'] + 1
        ov = OVR.get(key)
        while k < len(L) and (ov == 'ch' or not L[k]['t'].strip().startswith('①')) and k-j < 120:
            mm = re.search(rf"(^|\s){n1}\s*\.\s*\S", L[k]['t'])
            if (mm and mm.start() < 12) or re.match(r"^\s*\[\s*\d+\s*[~～∼]", L[k]['t']) or '확인 사항' in L[k]['t']: break
            k += 1
        if k >= len(L): continue
        a, b = L[j], L[k]
        same = (a['pg'], a['col']) == (b['pg'], b['col'])
        gap = b['top'] - a.get('bot', a['top']+14) if same else 999
        tl = k-j-1; bogi = len(it.get('보기') or '')
        if not ((same and gap - (tl*18.4 + (30 if bogi else 0)) > 45) or (not same and tl < 3) or only or ov):
            continue
        segs = []
        cur = (a['pg'], a['col']); top = a.get('bot', a['top']+14) + 3
        while True:
            if cur == (b['pg'], b['col']): segs.append((cur[0], cur[1], top, b['top']-4)); break
            segs.append((cur[0], cur[1], top, 1400)); cur = (cur[0], 1) if cur[1] == 0 else (cur[0]+1, 0); top = 0
            if len(segs) > 4: break
        if isinstance(ov, list): segs = [tuple(x) for x in ov]
        ims = [trim(seg_img(ex, L, *sg)) for sg in segs]
        ims = [i for i in ims if i.height > 40]
        if not ims: continue
        W = max(i.width for i in ims); H = sum(i.height for i in ims) + 16*(len(ims)-1)
        o = Image.new('L', (W, H), 255); y = 0
        for im in ims: o.paste(im, (0, y)); y += im.height + 16
        fn = key.replace('||', '_').replace(' ', '') + '.png'
        o.save(OUT + fn, optimize=True)
        man[key] = {'file': fn, 'mode': 'ch' if ov == 'ch' else 'bogi', 'segs': segs, 'gap': gap, 'tl': tl, 'bogi': bogi, 'w': W, 'h': H}
    json.dump(man, open(f'/home/claude/fig/items_manifest{MAN_SUFFIX}.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
    print(len(man))
if __name__ == '__main__': run()
