# 문항의 그림 자리를 원본 PDF에서 잘라 낸다.
# mode 'bogi': 발문 마지막 줄 아래 ~ 첫 선택지(①) 줄 위 ; mode 'ch': 발문 마지막 줄 아래 ~ 다음 문항/세트 머리 위
import sys, json, re, os, subprocess
sys.path.insert(0, "/home/claude/chk")
from streams import fname, SRC
from PIL import Image, ImageOps
DPI = 200; SC = DPI/72
def lines(ex):
    p = f"/home/claude/chk/streams2/{ex}.json"
    return json.load(open(p if os.path.exists(p) else f"/home/claude/chk/streams/{ex}.json"))
def page(ex, pg):
    base = f"/tmp/claude-0/B{DPI}_{ex}_{pg}"
    if not os.path.exists(base+".png"):
        subprocess.run(["pdftoppm","-r",str(DPI),"-f",str(pg+1),"-l",str(pg+1),"-png","-singlefile",SRC+fname(ex),base],check=True,stderr=subprocess.DEVNULL)
    return Image.open(base+".png").convert("L")
class _H:
    R = re.compile(r"^[\d/∕]*((국어|언어|영역|영|역|홀수형|짝수형|\(?화법과작문\)?|\(?언어와매체\)?|\(?독서\)?|\(?문학\)?|\(?[AB]형\)?)[\d/∕]*)*$")
    def match(self, t):
        u = re.sub(r"\s", "", t)
        if self.R.match(u): return True
        if len(u) <= 3 and not re.search(r"[가-힣A-Za-z]", u): return True
        if len(u) <= 22 and re.match(r"^[\d/∕]*(홀수형|짝수형)?[\d/∕]*(국어|언어)?영역", u) and not re.search(r"[.?]$", u): return True
        if re.search(r"문제지[\d]*$", u) and len(u) < 50: return True
        return False
HDR = _H()
def body(L, pg, col):
    hd = lambda l: HDR.match(l["t"]) or (l["top"] < 140 and len(l["t"].strip()) <= 26 and not re.match(r"^\s*(\[\s*\d|\d{1,2}\s*\.)", l["t"]))
    B = [l for l in L if l["pg"]==pg and l["col"]==col and not hd(l)]
    allb = [l for l in L if l["col"]==col and not HDR.match(l["t"]) and "저작권" not in l["t"] and "확인 사항" not in l["t"]]
    bots = sorted(l.get("bot", l["top"]+14) for l in allb)
    xs0 = sorted(l["x0"] for l in allb); xs1 = sorted(l.get("x1", l["x0"]+250) for l in allb)
    H = [l for l in L if l["pg"]==pg and l["col"]==col and hd(l) and l["top"] < 140]
    H2 = [l for l in L if l["pg"]==pg and hd(l) and l["top"] < 140]
    hb = max([l.get("bot", l["top"]+14) for l in H + H2], default=None)
    top = hb + 14 if hb is not None else (min(l["top"] for l in B) - 6 if B else 60)
    if pg == 0:
        st = [l["top"] for l in L if l["pg"] == 0 and re.match(r"^\s*(\[\s*\d+\s*[~～∼]|1\s*\.)", l["t"])]
        if st: top = max(top, min(st) - 6)
    return top, bots[int(len(bots)*0.995)-1] + 6, xs0[int(len(xs0)*0.02)] - 8, xs1[int(len(xs1)*0.98)] + 8
def unrule(im):
    # 가장자리의 세로 단 구분선(높이의 60% 이상 이어진 검은 세로줄)을 지운다
    W, H = im.size; px = im.load(); im = im.copy(); px = im.load()
    for xs in (range(0, min(14, W)), range(max(0, W-14), W)):
        for x in xs:
            dark = sum(1 for y in range(0, H, 2) if px[x, y] < 140)
            if dark > 0.6 * (H/2):
                for y in range(H): px[x, y] = 255
    return im
def trim(im, pad=10, thr=235):
    im = unrule(im)
    inv = ImageOps.invert(im.point(lambda v: 255 if v>thr else v))
    bb = inv.getbbox()
    if not bb: return im
    x0,y0,x1,y1 = bb
    return im.crop((max(0,x0-pad),max(0,y0-pad),min(im.width,x1+pad),min(im.height,y1+pad)))
def seg_img(ex, L, pg, col, top, bot):
    im = page(ex, pg); W,H = im.size
    bt, bb, x0, x1 = body(L, pg, col)
    top = max(top, bt); bot = min(bot, bb)
    y0, y1 = int(max(0,top*SC)), int(min(H,bot*SC))
    if y1 <= y0 + 2: return Image.new("L", (max(1, int((x1-x0)*SC)), 4), 255)
    return im.crop((int(x0*SC), y0, int(x1*SC), y1))
def find_item(L, num, after=0):
    for i in range(after, len(L)):
        if re.match(rf"^\s*{num}\s*\.", L[i]["t"]): return i
    return None
def region(ex, num, mode, area_hint=None, start=0):
    L = lines(ex); i0 = find_item(L, num, start)
    # 발문 끝: 다음 줄이 같은 단에서 20pt 넘게 떨어지면 끝
    j = i0
    while j+1 < len(L) and L[j+1]["pg"]==L[j]["pg"] and L[j+1]["col"]==L[j]["col"] and L[j+1]["top"]-L[j]["top"] < 26 and not L[j+1]["t"].strip().startswith(("①","<")): j += 1
    a = L[j]
    k = j+1
    if mode == "bogi":
        while k < len(L) and not L[k]["t"].strip().startswith("①"): k += 1
    else:
        while k < len(L) and not (re.match(rf"^\s*{num+1}\s*\.", L[k]["t"]) or re.match(r"^\s*\[\s*\d+\s*[~～∼]", L[k]["t"]) or "확인 사항" in L[k]["t"]): k += 1
    b = L[k] if k < len(L) else None
    return L, a, b
def cut(ex, num, mode, out, start=0, extra_bot=None):
    L, a, b = region(ex, num, mode, start=start)
    segs = []
    if b and (b["pg"],b["col"]) == (a["pg"],a["col"]):
        segs.append((a["pg"],a["col"],a.get("bot",a["top"]+14)+3,(extra_bot or b["top"])-4))
    else:
        segs.append((a["pg"],a["col"],a.get("bot",a["top"]+14)+3,1400))
        if b: segs.append((b["pg"],b["col"],0,b["top"]-4))
    ims = [trim(seg_img(ex, L, *s)) for s in segs]
    ims = [i for i in ims if i.height > 40] or ims[:1]
    W = max(i.width for i in ims); H = sum(i.height for i in ims)
    o = Image.new("L",(W,H),255); y=0
    for i in ims: o.paste(i,(0,y)); y+=i.height
    o.save(out, optimize=True); return out, segs, a["t"][:30], (b["t"][:30] if b else None)
if __name__ == "__main__":
    ex, num, mode, out = sys.argv[1], int(sys.argv[2]), sys.argv[3], sys.argv[4]
    print(cut(ex, num, mode, out))

def passage(ex, rng, out, occ=-1, stop_num=None):
    """세트 머리 [a~b] 아래 ~ 첫 문항 발문 위를 단별로 잘라 이어 붙인다."""
    L = lines(ex); a, b = rng.split("~")
    hs = [i for i, l in enumerate(L) if re.match(rf"^\s*\[\s*{a}\s*[~～∼]\s*{b}\s*\]", l["t"])]
    i0 = hs[occ]
    first = int(stop_num or a)
    i1 = find_item(L, first, i0+1)
    h = L[i0]; e = L[i1]
    segs = []; cur = (h["pg"], h["col"]); top = h.get("bot", h["top"]+14) + 2
    while True:
        if cur == (e["pg"], e["col"]):
            segs.append((cur[0], cur[1], top, e["top"]-4)); break
        segs.append((cur[0], cur[1], top, 1400))
        cur = (cur[0], 1) if cur[1] == 0 else (cur[0]+1, 0); top = 0
    ims = [trim(seg_img(ex, L, *s)) for s in segs]
    ims = [i for i in ims if i.height > 40]
    W = max(i.width for i in ims); H = sum(i.height for i in ims) + 16*(len(ims)-1)
    o = Image.new("L", (W, H), 255); y = 0
    for i in ims: o.paste(i, (0, y)); y += i.height + 16
    o.save(out, optimize=True); return out, segs, o.size
