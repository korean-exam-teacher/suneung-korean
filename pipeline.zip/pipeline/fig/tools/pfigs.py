# 지문 속 그림만 잘라 내고, 그림 바로 앞 줄 글자를 기록한다(지문 글자 속 끼울 자리 찾기용)
import json, sys, os
sys.path.insert(0, "/home/claude/fig/tools")
from box import lines, seg_img, trim
m = json.load(open('/home/claude/fig/pass_manifest.json'))
OUT = '/home/claude/fig/pfig/'; os.makedirs(OUT, exist_ok=True)
res = {}; cache = {}
for k, v in m.items():
    ex = k.split('||')[0]
    if ex not in cache: cache[ex] = lines(ex)
    L = cache[ex]; out = []
    for i, f in enumerate(v['figs']):
        im = trim(seg_img(ex, L, f['pg'], f['col'], f['top'], f['bot']))
        fn = f"{k.replace('||','_').replace(' ','')}_f{i}.png"
        im.save(OUT + fn, optimize=True)
        prev = [l for l in L if l['pg'] == f['pg'] and l['col'] == f['col'] and l.get('bot', l['top']+14) <= f['top'] + 2]
        nxt = [l for l in L if l['pg'] == f['pg'] and l['col'] == f['col'] and l['top'] >= f['bot'] - 2]
        b = max(prev, key=lambda l: l['top']) if prev else None
        a = min(nxt, key=lambda l: l['top']) if nxt else None
        out.append({'file': fn, 'w': im.width, 'h': im.height, 'before': b['t'] if b else None, 'after': a['t'] if a else None, 'ink': f['ink']})
    res[k] = out
json.dump(res, open('/home/claude/fig/pfig_manifest.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
print(len(res), sum(len(v) for v in res.values()))
