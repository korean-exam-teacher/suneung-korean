import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page()
        await pg.goto("file:///home/claude/test/p41.html"); await pg.wait_for_timeout(800)
        r = await pg.evaluate("""()=>{ const out=[]; ITEMS.concat(ITEMS_2028).forEach(it=>{ const solo=!it.지문범위||it.지문범위==='(독립 문항)'; const g={solo, examId:it.exam_id, 영역:it.영역, 지문범위:it.지문범위}; const w=bkWarnings(it,g).filter(x=>x!=='정답 없음'); if(w.length) out.push([it.exam_id,it.영역,it.문항번호,w.join(' / ')]); }); return out; }""")
        for x in r: print(x)
        await b.close()
asyncio.run(main())
