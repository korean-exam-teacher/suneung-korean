import asyncio, json
from playwright.async_api import async_playwright
async def main():
    html=open("/home/claude/site_v40.html",encoding="utf-8").read()
    open("/home/claude/test/p40.html","w",encoding="utf-8").write("<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"+html+"</head></html>")
    async with async_playwright() as p:
        b=await p.chromium.launch()
        pg=await b.new_page(viewport={"width":1280,"height":900})
        errs=[]; pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("file:///home/claude/test/p40.html"); await pg.wait_for_timeout(800)
        r = await pg.evaluate("""()=>{ const out=[]; ITEMS.concat(ITEMS_2028).forEach(it=>{ const solo=!it.지문범위||it.지문범위==='(독립 문항)'; const g={solo, examId:it.exam_id, 영역:it.영역, 지문범위:it.지문범위}; const w=bkWarnings(it,g).filter(x=>x!=='정답 없음'); if(w.length) out.push([it.명칭,it.영역,it.문항번호,it.지문범위,w.join(' / ')]); }); return out; }""")
        json.dump(r, open('/home/claude/test/warn.json','w',encoding='utf-8'), ensure_ascii=False)
        print(len(r))
        await pg.evaluate("""()=>{ bkAdd(ITEMS.filter(i=>i.exam_id==='2024-11' && i.영역==='언어와 매체' && i.문항번호>=40 || (i.exam_id==='2023-11' && i.영역==='독서' && i.문항번호>=14) || (i.exam_id==='2010-09' && i.문항번호>=36 && i.문항번호<=39)).map(itemKey)); }""")
        await pg.click("#bkLink"); await pg.wait_for_timeout(1500)
        for face in ['hy','shin','custom']:
            await pg.select_option('#bkFace', face); await pg.wait_for_timeout(1200)
            print(face, await pg.inner_text('#bkFaceInfo'), '|', await pg.inner_text('#bkInfo'))
        await pg.select_option('#bkFace', 'noto'); await pg.wait_for_timeout(1200)
        await pg.click('#bkPrevBtn'); await pg.wait_for_timeout(800)
        await pg.evaluate("""()=>{document.documentElement.classList.add('bk-print'); let st=document.createElement('style'); st.textContent='@media print{'+bkPageCss()+'}'; document.head.appendChild(st);}""")
        await pg.emulate_media(media="print"); await pg.pdf(path="/home/claude/test/w.pdf", prefer_css_page_size=True)
        print(await pg.inner_text('#bkInfo'))
        print("errors", errs)
        await b.close()
asyncio.run(main())
