import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page()
        await pg.goto("file:///home/claude/test/p40.html"); await pg.wait_for_timeout(800)
        print(await pg.evaluate("[bkFontInstalled('Noto Serif CJK KR'), bkFontInstalled('없는글꼴XYZ'), bkFontInstalled('DejaVu Serif')]"))
        await b.close()
asyncio.run(main())
