import asyncio
from playwright.async_api import async_playwright
async def main():
    html=open("/home/claude/site_v40.html",encoding="utf-8").read()
    open("/home/claude/test/p40.html","w",encoding="utf-8").write("<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"+html+"</head></html>")
    async with async_playwright() as p:
        b=await p.chromium.launch()
        for vw,name,scheme in [(390,'m','light'),(1280,'d','dark')]:
            pg=await b.new_page(viewport={"width":vw,"height":900}, color_scheme=scheme)
            errs=[]; pg.on("pageerror", lambda e: errs.append(str(e)))
            await pg.goto("file:///home/claude/test/p40.html"); await pg.wait_for_timeout(800)
            await pg.evaluate("""()=>{ bkAdd(ITEMS.filter(i=>i.exam_id==='2023-06' && (i.문항번호<=9 || i.문항번호==40)).map(itemKey)); }""")
            await pg.click("#bkLink"); await pg.wait_for_timeout(1500)
            await pg.screenshot(path=f"/home/claude/test/{name}_list.png")
            print(name, await pg.inner_text("#bkInfo"))
            print("hscroll", await pg.evaluate("document.documentElement.scrollWidth"), vw)
            await pg.click("#bkSolve"); await pg.wait_for_timeout(600)
            await pg.screenshot(path=f"/home/claude/test/{name}_solve.png")
            # exam view group button
            await pg.click('.gnb-link[data-mode="legacy"]'); await pg.wait_for_timeout(300)
            await pg.evaluate("enterExamView('2023-06')"); await pg.wait_for_timeout(500)
            print(name, "groupbtn:", await pg.locator("#examView .bk-group").first.inner_text())
            await pg.locator("#examView .pg").first.screenshot(path=f"/home/claude/test/{name}_exam.png")
            print("errors", errs)
            await pg.close()
        await b.close()
asyncio.run(main())
