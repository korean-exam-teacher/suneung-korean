import asyncio, sys, re
from playwright.async_api import async_playwright
SRC="/home/claude/site_v40.html"
EXAM = sys.argv[1] if len(sys.argv)>1 else "2024-11"
async def main():
    html=open(SRC,encoding="utf-8").read()
    page_html="<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"+html+"</head></html>"
    open("/home/claude/test/p40.html","w",encoding="utf-8").write(page_html)
    async with async_playwright() as p:
        b=await p.chromium.launch()
        pg=await b.new_page(viewport={"width":1280,"height":1000})
        errs=[]; pg.on("pageerror", lambda e: errs.append(str(e))); pg.on("console", lambda m: m.type=="error" and errs.append(m.text))
        await pg.goto("file:///home/claude/test/p40.html"); await pg.wait_for_timeout(1500)
        print("fonts:", await pg.evaluate("document.fonts.status"), await pg.evaluate("[...document.fonts].filter(f=>f.status==='loaded').length"))
        # 검색 결과에서 하나 담기
        await pg.fill("#searchInput", "열팽창"); await pg.keyboard.press("Enter"); await pg.wait_for_timeout(600)
        await pg.locator("#resultList .result-row").first.click()
        await pg.locator("#resultList .do-basket").first.click(); await pg.wait_for_timeout(200)
        print("toast:", await pg.inner_text("#bkToast"), "| count", await pg.inner_text("#bkCount"))
        print("mark visible:", await pg.locator("#resultList .bk-mark:not([hidden])").count())
        # 회차 화면에서 지문별 모두 담기
        if not await pg.locator(f'.ylink[data-exam="{EXAM}"]').count():
            await pg.click("#moreYears"); await pg.wait_for_timeout(300)
        await pg.locator(f'.ylink[data-exam="{EXAM}"]').first.click(); await pg.wait_for_timeout(800)
        n = await pg.locator("#examView .bk-group").count()
        mode = sys.argv[2] if len(sys.argv)>2 else "all"
        for i in range(n):
            t = await pg.locator("#examView .bk-group").nth(i).inner_text()
            # 선택과목 둘 다 있으면 하나(첫 번째 것)만
            await pg.locator("#examView .bk-group").nth(i).click()
        await pg.wait_for_timeout(200)
        print("groups:", n, "count", await pg.inner_text("#bkCount"))
        await pg.click("#bkLink"); await pg.wait_for_timeout(300)
        for _ in range(60):
            info = await pg.inner_text("#bkInfo")
            if "계산" not in info: break
            await pg.wait_for_timeout(500)
        print("info:", info)
        print("head:", (await pg.inner_text("#basket .exam-title p")))
        await pg.click("#bkPrevBtn"); await pg.wait_for_timeout(800)
        print("preview pages:", await pg.locator("#bkPreview .bk-pv").count())
        await pg.screenshot(path="/home/claude/test/v40_basket.png", full_page=False)
        await pg.locator("#bkPreview").screenshot(path="/home/claude/test/v40_prev.png")
        # PDF
        await pg.evaluate("""()=>{document.documentElement.classList.add('bk-print'); let st=document.createElement('style'); st.textContent='@media print{'+bkPageCss()+'}'; document.head.appendChild(st);}""")
        await pg.emulate_media(media="print")
        await pg.pdf(path="/home/claude/test/v40.pdf", prefer_css_page_size=True, print_background=True)
        await pg.emulate_media(media="screen")
        await pg.evaluate("document.documentElement.classList.remove('bk-print')")
        # 모아 풀기
        await pg.click("#bkSolve"); await pg.wait_for_timeout(500)
        items = await pg.locator(".bk-solve-item").count()
        for i in range(min(items,5)):
            await pg.locator(".bk-solve-item").nth(i).locator(".ch").nth(i%5).click()
        await pg.click("#bkGradeAll"); await pg.wait_for_timeout(300)
        print("solve items:", items, "result:", (await pg.inner_text("#bkResult"))[:300])
        print("nb count:", await pg.inner_text("#nbCount"))
        print("stem1:", (await pg.locator(".bk-solve-item .d-stem").first.inner_text())[:60])
        await pg.click("#bkBack"); await pg.wait_for_timeout(300)
        # 다른 메뉴로 이동
        await pg.click('.gnb-link[data-mode="legacy"]'); await pg.wait_for_timeout(300)
        print("basket hidden after nav:", await pg.evaluate("document.getElementById('basket').hidden"), await pg.evaluate("document.getElementById('results').hidden"))
        print("errors:", [e for e in errs if 'explain' not in e and 'fetch' not in e.lower()][:5], len(errs))
        await b.close()
asyncio.run(main())
