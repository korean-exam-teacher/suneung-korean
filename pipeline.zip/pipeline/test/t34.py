import asyncio, sys
from playwright.async_api import async_playwright
SRC="/home/claude/site_v34.html"
async def main():
    html=open(SRC,encoding="utf-8").read()
    page_html="<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"+html+"</head></html>" if "<html" not in html[:200] else html
    open("/home/claude/test/p.html","w",encoding="utf-8").write(page_html)
    async with async_playwright() as p:
        b=await p.chromium.launch()
        pg=await b.new_page(viewport={"width":1280,"height":900})
        errs=[]; pg.on("pageerror", lambda e: errs.append(str(e))); pg.on("console", lambda m: m.type=="error" and errs.append(m.text))
        await pg.goto("file:///home/claude/test/p.html"); await pg.wait_for_timeout(1500)
        print("stat:", await pg.inner_text("#statLine"))
        await pg.click("#moreYears"); await pg.wait_for_timeout(300)
        rows=await pg.eval_on_selector_all("#examTableWrap tbody tr", "rs=>rs.map(r=>r.innerText.replace(/\\s+/g,' '))")
        for r in rows: print(" ", r)
        await pg.locator("#examTableWrap").screenshot(path="/home/claude/test/table.png")
        await pg.click('.ylink[data-exam="2015-06-A"]'); await pg.wait_for_timeout(800)
        hdr=await pg.inner_text("#examView"); print("examView head:", hdr[:200].replace("\n"," | "))
        await pg.locator("#examView").screenshot(path="/home/claude/test/ev.png", clip=None) if False else None
        await pg.screenshot(path="/home/claude/test/ev.png", full_page=False)
        # 예비
        await pg.click("text=← 목록으로"); await pg.wait_for_timeout(500)
        await pg.click('.ylink[data-exam="2014-예비-B"]'); await pg.wait_for_timeout(800)
        await pg.screenshot(path="/home/claude/test/pre.png")
        print("pre:", (await pg.inner_text("#examView"))[:120].replace("\n"," | "))
        # 검색
        await pg.fill("#searchInput", "신기루"); await pg.keyboard.press("Enter"); await pg.wait_for_timeout(800)
        print("search count:", await pg.inner_text("#countNum"))
        rws=await pg.eval_on_selector_all("#resultList .c-exam", "rs=>rs.slice(0,12).map(r=>r.innerText.replace(/\\s+/g,' '))"); print(rws)
        await pg.screenshot(path="/home/claude/test/search.png")
        print("errors:", errs)
        await b.close()
asyncio.run(main())
