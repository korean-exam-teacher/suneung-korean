import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={"width":390,"height":844})
        await pg.goto("file:///home/claude/test/p.html"); await pg.wait_for_timeout(1500)
        await pg.click("#moreYears"); await pg.wait_for_timeout(300)
        el=pg.locator("#examTableWrap tr:has-text('2014학년도')").first
        await el.scroll_into_view_if_needed()
        await pg.screenshot(path="/home/claude/test/m_table.png")
        await pg.click('.ylink[data-exam="2016-09-A"]'); await pg.wait_for_timeout(800)
        pb=pg.locator("#examView .pg:has-text('꽃덤불')").first
        await pb.scroll_into_view_if_needed(); await pg.screenshot(path="/home/claude/test/m_poem.png")
        sw=await pg.evaluate("document.documentElement.scrollWidth"); print("scrollWidth",sw)
        await b.close()
asyncio.run(main())
