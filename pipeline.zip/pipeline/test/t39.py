import asyncio
from playwright.async_api import async_playwright
SRC="/home/claude/site_v39.html"
async def main():
    html=open(SRC,encoding="utf-8").read()
    page_html="<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"+html+"</head></html>" if "<html" not in html[:200] else html
    open("/home/claude/test/p.html","w",encoding="utf-8").write(page_html)
    async with async_playwright() as p:
        b=await p.chromium.launch()
        pg=await b.new_page(viewport={"width":1280,"height":1000})
        errs=[]; pg.on("pageerror", lambda e: errs.append(str(e))); pg.on("console", lambda m: m.type=="error" and errs.append(m.text))
        await pg.goto("file:///home/claude/test/p.html"); await pg.wait_for_timeout(1500)
        print("stat:", await pg.inner_text("#statLine"))
        for q in ["학가", "성호사설", "듣ᄉᆞᄇᆞ며"]:
            await pg.fill("#searchInput", q); await pg.keyboard.press("Enter"); await pg.wait_for_timeout(700)
            print(q, "count:", await pg.inner_text("#countNum"))
        await pg.fill("#searchInput", "피미일인"); await pg.keyboard.press("Enter"); await pg.wait_for_timeout(700)
        print("피미일인 count:", await pg.inner_text("#countNum"))
        await pg.locator("#resultList .c-exam").first.click(); await pg.wait_for_timeout(800)
        await pg.locator("text=지문과 함께 보기").first.click(); await pg.wait_for_timeout(1200)
        await pg.screenshot(path="/home/claude/test/v39a.png", full_page=False)
        txt = await pg.inner_text("body")
        i = txt.find("이런들 엇더"); print(repr(txt[i:i+200]))
        print("errors:", [e for e in errs if 'explain' not in e and 'fetch' not in e.lower()][:5], len(errs))
        await b.close()
asyncio.run(main())
