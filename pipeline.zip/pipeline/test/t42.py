import asyncio
from playwright.async_api import async_playwright
async def main():
    html=open("/home/claude/site_v42.html",encoding="utf-8").read()
    open("/home/claude/test/p42.html","w",encoding="utf-8").write("<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"+html+"</head></html>")
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={"width":1280,"height":1000})
        errs=[]; pg.on("pageerror", lambda e: errs.append(str(e)))
        bad=[]; pg.on("requestfailed", lambda r: bad.append(r.url))
        await pg.goto("file:///home/claude/test/p42.html"); await pg.wait_for_timeout(1000)
        print(await pg.inner_text('#statLine'))
        await pg.click('#moreYears'); await pg.wait_for_timeout(300)
        row = pg.locator('tr.pre-row', has_text='2022')
        print('row:', await row.inner_text())
        await row.locator('.ylink').click(); await pg.wait_for_timeout(1500)
        print(await pg.inner_text('#examView .exam-title'))
        print('pg count', await pg.locator('#examView .pg').count(), 'pfig', await pg.locator('#examView .pfig-wrap').count())
        await pg.locator('#examView .pg').nth(4).screenshot(path='/home/claude/test/e22a.png')
        # 검색
        await pg.click('#exitExamView'); await pg.fill('#searchInput','하기야키'); await pg.keyboard.press('Enter'); await pg.wait_for_timeout(600)
        print('search 하기야키', await pg.inner_text('#countNum'), await pg.locator('#resultList .c-exam').first.inner_text())
        await pg.fill('#searchInput','충전지'); await pg.keyboard.press('Enter'); await pg.wait_for_timeout(600)
        print('search 충전지', await pg.inner_text('#countNum'))
        # 채점
        await pg.evaluate("enterExamView('2022-예시','2022-예시||독서||30')"); await pg.wait_for_timeout(800)
        d=pg.locator('#examView .detail[data-key="2022-예시||독서||30"]')
        await d.locator('.ch').nth(1).click(); await d.locator('.do-grade').click(); print(await d.locator('.solve-msg').inner_text())
        r = await pg.evaluate("""()=>{ const out=[]; ITEMS.filter(i=>i.exam_id==='2022-예시').forEach(it=>{ const solo=it.지문범위==='(독립 문항)'; const w=bkWarnings(it,{solo,examId:it.exam_id,영역:it.영역,지문범위:it.지문범위}); if(w.length) out.push([it.영역,it.문항번호,w]); }); return out; }""")
        print('warn', r)
        await pg.evaluate("""()=>{ basket.keys=[]; bkAdd(ITEMS.filter(i=>i.exam_id==='2022-예시' && i.영역!=='언어와 매체').map(itemKey)); }""")
        await pg.click('#bkLink'); await pg.wait_for_timeout(3000); print(await pg.inner_text('#bkInfo'))
        print('errors', errs, 'bad', bad[:3])
        await b.close()
asyncio.run(main())
