import asyncio, sys
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        pg=await b.new_page(viewport={"width":1280,"height":1000})
        await pg.goto("file:///home/claude/test/p41.html"); await pg.wait_for_timeout(1000)
        for ex in ["2024-11","2025-11","2019-11","2012-11","2016-11-B"]:
            r = await pg.evaluate("""async(ex)=>{ basket.keys=[]; const ids=ITEMS.filter(i=>i.exam_id===ex && i.영역!=='언어와 매체').map(itemKey); bkAdd(ids); const out=[];
               for(const paper of ['A4','B4']){ basket.paper=paper; basket.font='auto'; bkLayout=null; const r=await bkComputeLayout(); out.push([paper,r.pt,r.pages,r.forced]); 
                 const r2=[]; for(const f of [10.5,9.5]){ basket.font=String(f); bkLayout=null; const x=await bkComputeLayout(); r2.push(f+':'+x.pages);} out.push(r2.join(' ')); }
               return [ids.length,out]; }""", ex)
            print(ex, r)
        await b.close()
asyncio.run(main())
