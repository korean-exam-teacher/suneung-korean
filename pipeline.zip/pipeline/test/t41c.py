import asyncio
from playwright.async_api import async_playwright
async def main():
    html=open("/home/claude/site_v41.html",encoding="utf-8").read()
    open("/home/claude/test/p41.html","w",encoding="utf-8").write("<!doctype html><html><head><meta charset='utf-8'>"+html+"</head></html>")
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={"width":1100,"height":1000})
        errs=[]; pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("file:///home/claude/test/p41.html"); await pg.wait_for_timeout(800)
        await pg.click('.gnb-link[data-mode="2028"]'); await pg.wait_for_timeout(300)
        await pg.evaluate("enterExamView('2028-예시','2028-예시||화법과 언어||6')"); await pg.wait_for_timeout(1200)
        d=pg.locator('#examView .detail[data-key="2028-예시||화법과 언어||6"]')
        print(await d.locator('img.fig').count()); await d.screenshot(path='/home/claude/test/f6.png'); print(errs)
        await b.close()
asyncio.run(main())
