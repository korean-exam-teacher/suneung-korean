import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={"width":1280,"height":900})
        errs=[]; pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("file:///home/claude/test/p.html"); await pg.wait_for_timeout(1500)
        await pg.fill("#searchInput", "신기루"); await pg.keyboard.press("Enter"); await pg.wait_for_timeout(800)
        print("search 신기루:", await pg.inner_text("#countNum"))
        print(await pg.eval_on_selector_all("#resultList .c-exam", "rs=>rs.slice(0,8).map(r=>r.innerText.replace(/\\s+/g,' '))"))
        await pg.fill("#searchInput", "도산십이곡"); await pg.keyboard.press("Enter"); await pg.wait_for_timeout(800)
        print("search 도산십이곡:", await pg.inner_text("#countNum"), await pg.eval_on_selector_all("#resultList .c-exam", "rs=>rs.slice(0,12).map(r=>r.innerText.replace(/\\s+/g,' '))"))
        # 역량 필터 정렬 확인
        await pg.fill("#searchInput", ""); await pg.keyboard.press("Enter")
        await pg.select_option("#examSelect", "2015-06-B"); await pg.wait_for_timeout(500)
        print("exam select 2015-06-B:", await pg.inner_text("#countNum"))
        opts=await pg.eval_on_selector_all("#examSelect option", "os=>os.slice(0,4).concat(os.slice(28,40)).map(o=>o.textContent)"); print(opts)
        # 풀기: 첫 결과 펼치고 선택지 확인
        await pg.click("#resultList .result-row >> nth=0"); await pg.wait_for_timeout(400)
        det=await pg.inner_text("#resultList li >> nth=0"); print(det[:600])
        await pg.screenshot(path="/home/claude/test/solve.png")
        print("errors", errs); await b.close()
asyncio.run(main())
