import asyncio, time
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        pg=await b.new_page(viewport={"width":1280,"height":1000})
        pg.on("console", lambda m: print("console:", m.text))
        await pg.goto("file:///home/claude/test/p40.html"); await pg.wait_for_timeout(1000)
        await pg.evaluate("""()=>{ const ids=ITEMS.filter(i=>i.exam_id==='2024-11').map(itemKey); bkAdd(ids.slice(0,20)); }""")
        t=time.time()
        r = await pg.evaluate("""async()=>{ const t0=performance.now(); const r=bkLayoutSync(10); return [r, performance.now()-t0]; }""")
        print(r, time.time()-t)
        await b.close()
asyncio.run(main())
