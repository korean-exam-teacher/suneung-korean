import asyncio
from playwright.async_api import async_playwright
async def main():
    html=open("/home/claude/site_v41.html",encoding="utf-8").read()
    open("/home/claude/test/p41.html","w",encoding="utf-8").write("<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"+html+"</head></html>")
    async with async_playwright() as p:
        b=await p.chromium.launch()
        pg=await b.new_page(viewport={"width":1280,"height":1000})
        errs=[]; pg.on("pageerror", lambda e: errs.append(str(e)))
        bad=[]; pg.on("requestfailed", lambda r: bad.append(r.url) if 'fig/' in r.url else None)
        await pg.goto("file:///home/claude/test/p41.html"); await pg.wait_for_timeout(1000)
        # 문항: 그림 선택지 채점
        await pg.evaluate("enterExamView('2010-09','2010-09||독서||38')"); await pg.wait_for_timeout(1500)
        d = pg.locator('#examView .detail[data-key="2010-09||독서||38"]')
        print("fig imgs:", await d.locator('img.fig').count(), "choices:", await d.locator('.ch').count())
        await d.locator('.ch').nth(2).click(); await d.locator('.do-grade').click(); await pg.wait_for_timeout(200)
        print("msg:", await d.locator('.solve-msg').inner_text())
        await d.screenshot(path='/home/claude/test/f1.png')
        # 지문 그림 토글
        await pg.evaluate("enterExamView('2024-11')"); await pg.wait_for_timeout(1500)
        w = pg.locator('#examView .pfig-wrap').first
        print("pfig wraps:", await pg.locator('#examView .pfig-wrap').count())
        await w.locator('.pfig-toggle').click(); print("text visible:", await w.locator('.ptext').is_visible(), await w.locator('.pfig').is_visible())
        await w.locator('.pfig-toggle').click()
        await w.screenshot(path='/home/claude/test/f2.png')
        # 담아서 인쇄
        await pg.evaluate("""()=>{ basket.keys=[]; bkAdd(ITEMS.filter(i=>i.exam_id==='2024-11' && i.영역==='언어와 매체' && i.문항번호>=40 || i.exam_id==='2010-09' && i.문항번호>=36 && i.문항번호<=39 || i.exam_id==='2020-11' && i.영역==='화법과 작문' && i.문항번호<=3).map(itemKey)); }""")
        await pg.click('#bkLink'); await pg.wait_for_timeout(2500)
        print(await pg.inner_text('#bkInfo'))
        print("warn:", await pg.locator('.bk-it .w').all_inner_texts())
        await pg.click('#bkPrevBtn'); await pg.wait_for_timeout(1500)
        await pg.evaluate("bkImagesReady()")
        await pg.wait_for_timeout(1500)
        await pg.evaluate("""()=>{document.documentElement.classList.add('bk-print'); let st=document.createElement('style'); st.textContent='@media print{'+bkPageCss()+'}'; document.head.appendChild(st);}""")
        await pg.emulate_media(media="print"); await pg.pdf(path="/home/claude/test/f.pdf", prefer_css_page_size=True)
        print("bad", bad[:3], "errors", errs)
        await b.close()
asyncio.run(main())
