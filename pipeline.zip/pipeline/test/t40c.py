import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        pg=await b.new_page(viewport={"width":1280,"height":900})
        await pg.goto("file:///home/claude/test/p40.html"); await pg.wait_for_timeout(800)
        r = await pg.evaluate("""async()=>{ bkAdd(ITEMS.filter(i=>i.exam_id==='2014-11-A' || (i.exam_id==='2010-09' && i.문항번호>40)).map(itemKey)); basket.paper='B4'; basket.ansKey=true; basket.title='테스트 반'; bkLayout=null; const r=await bkComputeLayout(); return r; }""")
        print(r)
        html = await pg.evaluate("bkStandaloneHtml()")
        open("/home/claude/test/standalone.html","w",encoding="utf-8").write(html)
        p2=await b.new_page(); await p2.goto("file:///home/claude/test/standalone.html"); await p2.wait_for_timeout(500)
        await p2.pdf(path="/home/claude/test/sa.pdf", prefer_css_page_size=True, print_background=True)
        await p2.screenshot(path="/home/claude/test/sa.png")
        await b.close()
asyncio.run(main())
