# ==================== merge_v39.py ====================
# -*- coding: utf-8 -*-
"""merge_v38 → 남은 □ 되살리기(2차) + 지문·<보기> 낱말 자리 바로잡기 → site_v39.html
1) chk/pass2.json: 원본 글자 흐름(옛한글 판독표로 바꾼 것)과 앞뒤 맥락이 한 곳에서만 맞는 □ 자리
2) chk/movefix.json: 원본(글자 좌표로 다시 읽은 줄)과 낱말 단위로 맞추어, 자리가 밀린 낱말을 원래 자리로 옮기고 □를 채움
3) chk/manual39.json: 원본 그림을 보고 직접 판독한 □와 오류(문자열 바꾸기, 반드시 한 곳만 맞아야 함)"""
import json, re, subprocess, sys, os
STAGE = sys.argv[1] if len(sys.argv) > 1 else "all"
if not os.environ.get("SKIP_V38"): subprocess.run(["python3", "/home/claude/merge_v38.py"], check=True)
SRC = "/home/claude/site_v38.html"; DST = "/home/claude/site_v39.html"
lines = open(SRC, encoding="utf-8").read().split("\n")
def idx(n): return [k for k, l in enumerate(lines) if l.startswith(f"const {n} = ")][0]
def load(n): return json.loads(lines[idx(n)][len(f"const {n} = "):].rstrip(";"))
def save(n, v): lines[idx(n)] = f"const {n} = " + json.dumps(v, ensure_ascii=False) + ";"
ITEMS = load("ITEMS"); CHO = load("CHOICES"); PAS = load("PASSAGES")
IT = {f'{i["exam_id"]}||{i["영역"]}||{i["문항번호"]}': i for i in ITEMS}
def get(kind, key, num):
    if kind == "선지": return CHO[key][num - 1]
    if kind == "지문": return PAS[key]
    return IT[key][kind]
def put(kind, key, num, v):
    if kind == "선지": CHO[key][num - 1] = v
    elif kind == "지문": PAS[key] = v
    else: IT[key][kind] = v
# 1) pass2
P = json.load(open("/home/claude/chk/pass2.json")); n1 = 0; sk = []
by = {}
for r in P: by.setdefault((r["kind"], r["key"], r["num"]), []).append(r)
for k, rs in by.items():
    t = get(*k)
    for r in sorted(rs, key=lambda r: -r["pos"]):
        p, ln = r["pos"], len(r["run"])
        if t[p:p + ln] != r["run"] or (r["L"] and not t[:p].endswith(r["L"])): sk.append(r); continue
        t = t[:p] + r["rep"] + t[p + ln:]; n1 += 1
    put(*k, t)
print("pass2", n1, "skipped", len(sk))
if STAGE == "A":
    json.dump({"CHO": CHO, "PAS": PAS, "BOGI": {k: v.get("보기") for k, v in IT.items() if v.get("보기")}}, open("/home/claude/chk/v39A.json", "w"), ensure_ascii=False)
    sys.exit(0)
# 2) 지문 낱말 자리·옛한글 띄어쓰기·□ 채우기 (chk/movefix.py 결과). 원본 쪽 글자 흐름이 표·그림 배치 때문에 믿기 어려운 지문은 뺀다
EXCL = {"2022-06||언어와 매체||40~42", "2022-11||언어와 매체||44~45", "2025-09||언어와 매체||43~45", "2027-06||독서||10~13", "2027-09||화법과 작문||43~45", "2021-09||화법과 작문||8~10"}
MV = json.load(open("/home/claude/chk/movefix.json")); n2 = 0
for uk, v in MV.items():
    kind, key = uk.split("||", 1)
    if key in EXCL: continue
    if kind == "지문": PAS[key] = v; n2 += 1
print("movefix units", n2)
# 2-1) 문학 지문(2018~): 원본 줄에서 시행·연·각주 줄을 다시 짬(chk/rebuild.py). 글자 꾸러미가 같을 때만
RB = json.load(open("/home/claude/chk/rebuild.json")); n21 = 0
for key, r in RB.items():
    if r["ok"]: PAS[key] = r["new"]; n21 += 1
print("rebuild units", n21)
# 3) 직접 판독
MAN = json.load(open("/home/claude/chk/manual39.json")); n3 = 0; miss = []
for kind, key, num, old, new, why in MAN:
    t = get(kind, key, num)
    if old == "*": put(kind, key, num, new); n3 += 1; continue
    c = t.count(old)
    if c == 1: put(kind, key, num, t.replace(old, new)); n3 += 1
    elif new in t: pass
    else: miss.append((kind, key, num, old, c))
print("manual", n3, "miss", len(miss))
for m in miss: print("  MISS", m)
# 4) <보기> 낱말 자리 바로잡기(2018~, 원본 대조로 맞는 것만 골라 씀)
BACC = {"2027-06||화법과 작문||39", "2027-06||언어와 매체||38", "2027-09||언어와 매체||36", "2022-11||독서||8", "2022-11||화법과 작문||45", "2022-11||언어와 매체||39", "2023-09||언어와 매체||41", "2023-11||언어와 매체||37", "2023-11||언어와 매체||38", "2023-11||언어와 매체||44", "2024-06||언어와 매체||36", "2024-06||언어와 매체||39", "2024-09||언어와 매체||42", "2024-11||독서||7", "2024-11||화법과 작문||45", "2024-11||언어와 매체||37", "2025-06||문학||20", "2025-09||문학||27", "2025-09||독서||6", "2018-06||독서||23", "2018-09||독서||28", "2019-09||언어와 매체||12", "2019-09||언어와 매체||14", "2019-09||독서||24", "2019-11||화법과 작문||4", "2019-11||독서||31", "2021-09||독서||29"}
MB = json.load(open("/home/claude/chk/movefix_bogi.json")); n4 = 0
for uk, v in MB.items():
    kind, key = uk.split("||", 1)
    if key in BACC: IT[key]["보기"] = v; n4 += 1
print("bogi moves", n4)
if STAGE == "B":
    json.dump({"CHO": CHO, "PAS": PAS, "BOGI": {k: v.get("보기") for k, v in IT.items() if v.get("보기")}}, open("/home/claude/chk/v39B.json", "w"), ensure_ascii=False)
    sys.exit(0)
# 5) 마무리 손질
k = "2023-11||언어와 매체||37"; b = IT[k]["보기"]
assert b.count("내용이다. 에서 ⓐ") == 1
b = b.replace("내용이다. 에서 ⓐ", "내용이다. [자료]에서 ⓐ")
if "[자료] ᄢᅵ니" not in b: b = b.rstrip() + "\n[자료] ᄢᅵ니, 붇, 사ᄫᅵ, 스ᄀᆞᄫᆞᆯ, ᄧᆞᆨ, ᄒᆞᆰ"
IT[k]["보기"] = b
# 지수(위 첨자)가 숫자로 풀려 버린 곳, 낱말 풀이(각주) 손질
SUP = str.maketrans("0123456789-", "⁰¹²³⁴⁵⁶⁷⁸⁹⁻")
def exps(t):
    t = re.sub(r"×10-(\d{1,2})(?=[가-힣a-zA-Z·])", lambda m: "×10" + ("-" + m.group(1)).translate(SUP), t)
    t = re.sub(r"(?<![\d.×])10-9(?=토르)", "10⁻⁹", t)
    t = t.replace("6.02×1023개", "6.02×10²³개").replace("3.086×1013km", "3.086×10¹³km")
    return t
nx = 0
for key in PAS:
    v = exps(PAS[key]); nx += v != PAS[key]; PAS[key] = v
for key in CHO:
    for i, c in enumerate(CHO[key]):
        v = exps(c); nx += v != c; CHO[key][i] = v
for it in ITEMS:
    if it.get("보기"):
        v = exps(it["보기"]); nx += v != it["보기"]; it["보기"] = v
k = "2020-11||독서||37~42"
assert PAS[k].count("자기자본 BIS 비율(%)= ×100≥8(%) 위험가중자산") == 1
PAS[k] = PAS[k].replace("자기자본 BIS 비율(%)= ×100≥8(%) 위험가중자산", "BIS 비율(%)=자기자본/위험가중자산×100≥8(%)")
print("exponent fixes(units)", nx)
NOTES = load("PASSAGE_NOTES")
fixn = {"참승□": "참승ᄒᆞᆯ", "소쇄□": "소쇄ᄒᆞᆷ", "쌍□목": "쌍비목", "용여□쟈": "용여ᄒᆞ쟈", "6.02×1023개": "6.02×10²³개", "3.086×1013km": "3.086×10¹³km"}
for key, ents in NOTES.items():
    for e in ents:
        for j, x in enumerate(e):
            for a, b in fixn.items(): x = x.replace(a, b)
            e[j] = x
NOTES["2013-11||독서||29~31"] = [e for e in NOTES["2013-11||독서||29~31"] if not e[0].startswith("의 기체에 대해")]
assert not any("□" in x for ents in NOTES.values() for e in ents for x in e)
save("PASSAGE_NOTES", NOTES)
# 옛 표기 안내 문구: □가 더 이상 없으면 지우고, 남아 있으면 그대로 둔다
NOTE = "\n\n※ 이 지문은 옛 표기(아래아 등 옛 한글 자모)를 원본 그대로 살리지 못했습니다 — 일부 글자가 □로 표시됩니다."
nrm = 0; nkeep = []
for key, v in PAS.items():
    if NOTE in v:
        body = v.replace(NOTE, "")
        PAS[key] = body; nrm += 1   # 남은 □는 원본의 가림 글자(□□고 등)뿐이므로 안내 문구를 모두 지운다
print("note removed", nrm, "kept", nkeep)
# 남은 □ 세기(원본에 있는 빈칸·기호 □ 포함)
def cnt():
    c = sum(v.count("□") for v in PAS.values()) + sum(it.get("보기", "").count("□") for it in ITEMS) + sum(x.count("□") for v in CHO.values() for x in v)
    return c
print("□ left (incl. legit)", cnt())
save("ITEMS", ITEMS); save("CHOICES", CHO); save("PASSAGES", PAS)
s = "\n".join(lines)
A = "원본의 글자 모양을 보고 되살렸습니다."
assert s.count(A) == 1, s.count(A)
s = s.replace(A, A + f" 2차 대조에서 남은 □ 자리도 원본 그림을 크게 보고 모두 채웠고(지금 남은 □는 원본에 있는 빈칸·기호·가림 글자입니다), 지문과 &lt;보기&gt;에서 글꼴이 달라 자리를 벗어나 있던 낱말(각주 * 낱말, 말하는 이 이름, 책 이름 등)을 원본 자리로 옮겼으며, 2018학년도 이후 문학 지문 {n21}개는 원본의 시행·연 나눔대로 다시 짰습니다.")
for a, b in [("(2) 일부 고전시가(옛 가사·시조) 지문은 원본 PDF가 아래아(ㆍ) 등 옛 한글 자모를 특수 글꼴로 표기해, 그 글자가 정확히 복원되지 않고 □로 표시됩니다.",
              "(2) 일부 고전시가(옛 가사·시조)와 중세 국어 자료는 원본 PDF가 아래아(ㆍ) 등 옛 한글 자모를 특수 글꼴로 표기해 글자를 그대로 옮길 수 없었는데, 원본의 글자 모양을 하나하나 보고 옛한글 자모로 되살렸습니다. 옛한글을 지원하지 않는 글꼴에서는 자모가 풀어져 보일 수 있습니다."),
             ("옛 한글 글꼴로 찍힌 글자는 □로 표시됩니다.", "옛 한글 글꼴로 찍힌 글자는 원본의 글자 모양을 보고 옛한글 자모로 되살렸습니다.")]:
    assert s.count(a) == 1, a[:30]
    s = s.replace(a, b)
open(DST, "w", encoding="utf-8").write(s)
print("wrote", DST, len(s) / 1e6, "MB")

# ==================== chk/movefix.py ====================
# -*- coding: utf-8 -*-
"""지문·<보기>를 원본(streams2: 글자 좌표를 세로 겹침으로 다시 묶은 줄)과 낱말 단위로 맞춘다.
 (가) 자리가 밀린 낱말(묶음)을 원본 자리로 옮긴다  (나) 같은 낱말 안의 □를 원본 글자(판독표 적용)로 채운다
입력: v39A.json  출력: movefix.json {kind||key: new_text}, movefix_log.json"""
import json, re, unicodedata, difflib, sys
sys.path.insert(0, "/home/claude/chk")
from pua_map import READ, compose
from openpyxl import load_workbook
from streams import fname
ws = load_workbook("/home/claude/chk/직접확인_목록_원본.xlsx")["2 옛한글·기호(글자별)"]
CODE = {}
for r in ws.iter_rows(min_row=2, values_only=True):
    num, code, typed = r[0].split("-")[1], r[2], r[6]
    if typed: CODE[chr(int(code[2:], 16))] = typed
    elif num in READ: CODE[chr(int(code[2:], 16))] = compose(READ[num])
CODE.update({"\U000f0854": "『", "\U000f0855": "』", "ꡔ": "『", "ꡕ": "』", "​": ""})
import sys as _s; _s.path.insert(0, "/home/claude/chk"); from pua_map import EXTRA as _EX; CODE.update(_EX)
def mapd(t): return "".join(CODE.get(c, c) for c in t)
CIR = "①②③④⑤"
def Nt(t):
    for k, c in enumerate(CIR): t = t.replace(c, f"#{k+1}#")
    t = unicodedata.normalize("NFKC", t)
    for a, b in [("‘", "'"), ("’", "'"), ("“", '"'), ("”", '"'), ("`", "'"), ("ㆍ", "·"), ("・", "·"), ("‧", "·"), ("∙", "·"), ("･", "·"), ("․", "·"), ("～", "~"), ("∼", "~"), ("〜", "~"), ("―", "-"), ("—", "-"), ("–", "-"), ("－", "-"), ("＋", "+")]:
        t = t.replace(a, b)
    return re.sub(r"[\s​□『』「」｢｣<>〈〉-\U000f0000-\U0010ffff]", "", t)
TOK = r"(\d+|국어|언어|영|역|영역|국어\s*영|홀수형|짝수형|[AB]\s*형|\(|\)|화법과\s*작문\)?|언어와\s*매체\)?|제\s*1\s*교시)"
JUNK = re.compile(rf"\s*{TOK}(\s*{TOK})*\s*")
def is_junk(t):
    t = t.strip(); return (not t) or bool(JUNK.fullmatch(t)) or t.startswith("이 문제지에 관한 저작권은")
SRCD = {}
def src(ex):
    if ex not in SRCD:
        try: L = json.load(open(f"/home/claude/chk/streams2/{ex}.json"))
        except Exception: SRCD[ex] = None; return None
        toks = []   # (표시 토큰, 줄끝 여부)
        for l in L:
            if is_junk(l["t"]): continue
            ws_ = mapd(l["t"]).split()
            for i, w in enumerate(ws_): toks.append([w, i == len(ws_) - 1])
        SRCD[ex] = toks
    return SRCD[ex]
def site_tok(t):
    ms = list(re.finditer(r"\S+", t)); toks = [m.group() for m in ms]
    seps = [t[ms[i].end():(ms[i+1].start() if i + 1 < len(ms) else len(t))] for i in range(len(ms))]
    head = t[:ms[0].start()] if ms else t
    return head, toks, seps
def join(head, toks, seps): return head + "".join(a + b for a, b in zip(toks, seps))
def region(stoks, nsrc):
    """사이트 토큰 목록이 원본 토큰 목록의 어디쯤인지: 여러 군데 4토큰 조각을 찾아 범위를 정한다"""
    n = len(stoks); hits = []
    ns = [Nt(x) for x in stoks]
    idx = {}
    for j in range(len(nsrc) - 3):
        idx.setdefault(tuple(nsrc[j:j+4]), []).append(j)
    for i in range(0, max(1, n - 3)):
        k = tuple(ns[i:i+4])
        if len(k) == 4 and all(k) and 1 <= len(idx.get(k, [])) <= 3:
            for j in idx[k]: hits.append((i, j))
    if len(hits) < 2: return None
    from collections import Counter
    bins = Counter((j - i) // 60 for i, j in hits)
    b0 = bins.most_common(1)[0][0]
    good = [(i, j) for i, j in hits if abs((j - i) // 60 - b0) <= 1]
    if len(good) < max(2, min(10, n // 20)): return None
    j0 = min(j - i for i, j in good); j1 = max(j - i for i, j in good) + n
    return max(0, j0 - 3), min(len(nsrc), j1 + 3)
def fill_box(stok, otok):
    """사이트 낱말의 □ 묶음을 원본 낱말의 글자로 채움(나머지 글자가 똑같을 때만)"""
    if "□" not in stok: return None
    parts = re.split(r"(□+)", stok)
    rx = "".join("(.+?)" if p.startswith("□") else re.escape(p) for p in parts if p)
    m = re.fullmatch(rx, otok)
    if not m: return None
    out = ""; g = 1
    for p in parts:
        if not p: continue
        if p.startswith("□"):
            c = m.group(g); g += 1
            if any(0xE000 <= ord(x) <= 0xF8FF or ord(x) >= 0xF0000 or x == "□" for x in c): return None
            out += c
        else: out += p
    return out
def process(t, ex, log, unit):
    S = src(ex)
    if not S: return t, "nosrc"
    nsrc_all = [Nt(w) for w, _ in S]
    head, toks, seps = site_tok(t)
    if len(toks) < 6: return t, "short"
    rg = region(toks, nsrc_all)
    if not rg: return t, "noanchor"
    a, b = rg; O = S[a:b]; no = nsrc_all[a:b]
    moved = 0
    def score(ns_):
        sm_ = difflib.SequenceMatcher(None, ns_, no, autojunk=False)
        return sum(m.size for m in sm_.get_matching_blocks()), sm_
    def okblock(bt):
        txt = " ".join(bt)
        if any(re.fullmatch(r"[\[(（<〈]?[A-Z가-하ㄱ-ㅎ][\])）>〉]?|\[[^\]]{1,8}\]|<[^>]*>|[ⓐ-ⓩⒶ-Ⓩ㉠-㉭㉮-㉻①-⑳]", x) for x in bt): return False
        return bool(re.search(r"[가-힣A-Za-z]", txt))
    def pref(bt):
        txt = " ".join(bt)
        return (2 if "*" in txt else 0) + (1 if re.search(r":$|□|『|○○|△△|◇◇", txt) else 0)
    for it in range(80):
        ns = [Nt(x) for x in toks]
        base, sm = score(ns)
        ops = [o for o in sm.get_opcodes() if o[0] != "equal"]
        if not ops: break
        cand_src = set(); cand_tgt = set()
        for tg, i1, i2, j1, j2 in ops:
            for p in range(max(0, i1 - 3), min(len(toks), i2 + 3)): cand_src.add(p)
            for p in range(max(0, i1 - 3), min(len(toks), i2 + 4)): cand_tgt.add(p)
        best = None
        for s0 in sorted(cand_src):
            for L in (1, 2, 3, 4):
                if s0 + L > len(toks): break
                bt = toks[s0:s0 + L]
                if not okblock(bt): continue
                rest = ns[:s0] + ns[s0 + L:]
                for tgt in sorted(cand_tgt):
                    t2 = tgt if tgt <= s0 else tgt - L
                    if t2 == s0 or t2 < 0 or t2 > len(rest): continue
                    if abs(tgt - s0) > 40: continue
                    sc, _ = score(rest[:t2] + ns[s0:s0 + L] + rest[t2:])
                    gain = sc - base
                    if gain <= 0: continue
                    key = (gain, -L, pref(bt), -abs(tgt - s0))
                    if best is None or key > best[0]: best = (key, s0, L, t2)
        if not best: break
        _, s0, L, t2 = best
        blk_t = toks[s0:s0 + L]
        before = join("", toks[max(0, s0-4):s0+L+4], seps[max(0, s0-4):s0+L+4])
        last_sep = seps[s0 + L - 1]
        del toks[s0:s0 + L]; del seps[s0:s0 + L]
        if s0 > 0 and "\n" in last_sep and "\n" not in seps[s0 - 1]: seps[s0 - 1] = last_sep
        # 원본에서 이 묶음이 줄 끝인지
        ns2 = [Nt(x) for x in toks[:t2]] + [Nt(x) for x in blk_t] + [Nt(x) for x in toks[t2:]]
        _, sm2 = score(ns2); eol = False; nxt_same = True
        for m in sm2.get_matching_blocks():
            if m.a <= t2 + L - 1 < m.a + m.size:
                jj = m.b + (t2 + L - 1 - m.a); eol = O[jj][1]
        ins_s = [" "] * L
        if t2 > 0 and "\n" in seps[t2 - 1] and eol:
            ins_s[-1] = seps[t2 - 1]; seps[t2 - 1] = " "
        toks[t2:t2] = blk_t; seps[t2:t2] = ins_s
        after = join("", toks[max(0, t2-4):t2+L+4], seps[max(0, t2-4):t2+L+4])
        log.append({"unit": unit, "moved": " ".join(blk_t), "before": before.replace("\n", "⏎"), "after": after.replace("\n", "⏎")})
        moved += 1
    # 외톨이 줄 합치기: '*' 낱말만 있는 줄인데 원본에서는 다음 낱말과 같은 줄이면 줄바꿈을 없앤다
    ns = [Nt(x) for x in toks]; _, sm = score(ns); amap = {}
    for m in sm.get_matching_blocks():
        for q in range(m.size): amap[m.a + q] = m.b + q
    starts = [0] + [i + 1 for i in range(len(toks) - 1) if "\n" in seps[i]]
    for st in starts:
        en = st
        while en < len(toks) - 1 and "\n" not in seps[en]: en += 1
        line = toks[st:en + 1]
        if len(line) <= 2 and any("*" in x for x in line) and en + 1 < len(toks) and seps[en].count("\n") == 1:
            if en in amap and en + 1 in amap and amap[en + 1] == amap[en] + 1 and not O[amap[en]][1]:
                log.append({"unit": unit, "join": " ".join(line) + " ⏎ " + toks[en + 1]})
                seps[en] = " "; moved += 1
    # 옛한글 낱말 안의 군 띄어쓰기: 원본에서는 한 낱말인데 사이트에서 갈라진 경우 붙인다
    ns = [Nt(x) for x in toks]; _, sm = score(ns)
    for tg, i1, i2, j1, j2 in reversed(sm.get_opcodes()):
        if tg != "replace" or i2 - i1 < 2: continue
        if "".join(ns[i1:i2]) != "".join(no[j1:j2]) or j2 - j1 >= i2 - i1: continue
        seg = "".join(toks[i1:i2])
        if not re.search(r"[\u1100-\u11ff]", seg): continue
        if any("\n" in x for x in seps[i1:i2 - 1]): continue
        # 원본 낱말 경계대로 다시 나눔
        new = []; p = 0; flat = "".join(toks[i1:i2])
        for j in range(j1, j2):
            L = len(Nt(O[j][0])); q = p; cnt = 0
            while q < len(flat) and cnt < L:
                cnt += len(Nt(flat[q])); q += 1
            new.append(flat[p:q]); p = q
        if p != len(flat) or any(not x for x in new): continue
        log.append({"unit": unit, "space": " ".join(toks[i1:i2]) + " → " + " ".join(new)})
        last = seps[i2 - 1]
        toks[i1:i2] = new; seps[i1:i2] = [" "] * (len(new) - 1) + [last]
    # □ 채우기
    ns = [Nt(x) for x in toks]
    sm = difflib.SequenceMatcher(None, ns, no, autojunk=False); filled = 0
    for tg, i1, i2, j1, j2 in sm.get_opcodes():
        if tg not in ("equal", "replace") or (i2 - i1) != (j2 - j1): continue
        for k in range(i2 - i1):
            st, ot = toks[i1 + k], O[j1 + k][0]
            f = fill_box(st, ot)
            if f and f != st:
                log.append({"unit": unit, "fill": st + " → " + f}); toks[i1 + k] = f; filled += 1
    return join(head, toks, seps), f"moved {moved} filled {filled}"
if __name__ == "__main__":
    A = json.load(open("/home/claude/chk/v39A.json"))
    out = {}; log = []; from collections import Counter; st = Counter()
    import os
    if os.environ.get("BOGI"):
        A = json.load(open("/home/claude/chk/v39B.json"))
        units = [("보기", k, v) for k, v in A["BOGI"].items() if int(k[:4]) >= 2018]
    else:
        units = [("지문", k, v) for k, v in A["PAS"].items() if int(k[:4]) >= 2018]
    only = sys.argv[1:] 
    for kind, k, v in units:
        if only and k not in only: continue
        ex = k.split("||")[0]
        nv, s = process(v, ex, log, f"{kind}||{k}")
        st[s.split()[0] if not s.startswith("moved") else ("changed" if nv != v else "same")] += 1
        if nv != v: out[f"{kind}||{k}"] = nv
    sfx = "_bogi" if os.environ.get("BOGI") else ""
    json.dump(out, open(f"/home/claude/chk/movefix{sfx}.json", "w"), ensure_ascii=False)
    json.dump(log, open(f"/home/claude/chk/movefix{sfx}_log.json", "w"), ensure_ascii=False, indent=0)
    print(st, "moves", sum(1 for l in log if "moved" in l), "fills", sum(1 for l in log if "fill" in l))

# ==================== chk/rebuild.py ====================
# -*- coding: utf-8 -*-
"""문학 지문(2018~)을 원본 줄(streams2)에서 다시 짠다: 시행·연 나눔·각주 줄을 원본대로.
글자 묶음(옛한글·□·공백 뺀 글자 꾸러미)이 지금 사이트 지문과 똑같을 때만 바꾼다(내용이 빠지거나 더해지지 않음을 보장)."""
import json, re, sys, unicodedata
from collections import Counter
_src=open('/home/claude/chk/movefix.py').read(); exec(_src.split('def Nt')[0]); exec('TOK'+_src.split('TOK',1)[1].split('SRCD = {}')[0])
def NC(t):
    t = unicodedata.normalize("NFKC", t)
    for a, b in [("‘", "'"), ("’", "'"), ("“", '"'), ("”", '"'), ("ㆍ", "·"), ("․", "·"), ("∙", "·"), ("～", "~"), ("∼", "~"), ("―", "-"), ("—", "-"), ("–", "-"), ("＋", "+")]: t = t.replace(a, b)
    return re.sub(r"[\s​□『』「」｢｣ᄀ-ᇿ-\U000f0000-\U0010ffff]", "", t)
def lines(ex):
    L = json.load(open(f'/home/claude/chk/streams2/{ex}.json'))
    return [l for l in L if not is_junk(l['t'])]
def build(ex, site):
    L = lines(ex)
    body = site.split("\n\n※")[0]
    ns = NC(body)
    if len(ns) < 40: return None, "short"
    head, tail = ns[:14], ns[-14:]
    cum = []; acc = ""
    for l in L: cum.append(len(acc)); acc += NC(mapd(l['t']))
    i0 = acc.find(head)
    if i0 < 0: return None, "nohead"
    i1 = acc.find(tail, i0)
    if i1 < 0 or i1 - i0 > len(ns) * 1.3 + 50: return None, "notail"
    a = max(k for k in range(len(L)) if cum[k] <= i0); b = max(k for k in range(len(L)) if cum[k] <= i1 + len(tail) - 1)
    seg = L[a:b+1]
    # 앞뒤 줄이 지문 밖 글자를 포함하면 잘라낸다(첫 줄 앞부분, 끝 줄 뒷부분)
    txts = [mapd(l['t']).strip() for l in seg]
    # 첫 줄: head 앞 글자 제거
    def cut_head(t, h):
        n = ""; 
        for p in range(len(t)):
            if NC(t[p:]).startswith(h[:max(1, min(len(h), len(NC(t[p:]))))]) and NC(t[p:])[:len(h)] == h[:len(NC(t[p:])[:len(h)])]:
                return t[p:]
        return t
    txts[0] = cut_head(txts[0], head)
    # 끝 줄: tail 뒤 글자 제거
    t = txts[-1]
    for p in range(len(t), 0, -1):
        if NC(t[:p]).endswith(tail[-min(len(tail), len(NC(t[:p]))):]) and NC(t[:p]).endswith(tail[-3:]):
            txts[-1] = t[:p]; break
    # 줄 이음 규칙
    groups = {}
    for l in seg: groups.setdefault((l['pg'], l['col']), []).append(l)
    right = {k: max(x['x1'] for x in v) for k, v in groups.items()}
    left = {k: min(x['x0'] for x in v) for k, v in groups.items()}
    gaps = [seg[k+1]['top'] - seg[k]['top'] for k in range(len(seg) - 1) if seg[k+1]['pg'] == seg[k]['pg'] and seg[k+1]['col'] == seg[k]['col']]
    gaps = [g for g in gaps if g > 0]
    pitch = sorted(gaps)[len(gaps) // 2] if gaps else 18
    out = ""
    for k, l in enumerate(seg):
        t = txts[k]
        if k == 0: out = t; continue
        p = seg[k-1]; key = (l['pg'], l['col']); pk = (p['pg'], p['col'])
        csz = (p['bot'] - p['top']) or 10
        full = p['x1'] >= right[pk] - csz * 1.2 and not txts[k-1].rstrip().endswith('>') and not re.search(r'-\s*$', txts[k-1]) and not re.search(r'\[[A-Z]\]\s*$', txts[k-1])
        rightish = l['x0'] > left[key] + (right[key] - left[key]) * 0.45 and t.startswith('<') and len(t) < 12
        same_col = key == pk
        gap = l['top'] - p['top'] if same_col else pitch
        if rightish: out += " " + t; continue
        if t.startswith('*') or t.startswith('-') and not full: out += "\n" + t; continue
        if full and not t.startswith('('): out += " " + t; continue
        out += ("\n\n" if gap > pitch * 1.5 else "\n") + t
    return out, "ok"
if __name__ == "__main__":
    A = json.load(open('/home/claude/chk/v39B.json'))
    res = {}; st = Counter()
    keys = [k for k in A['PAS'] if int(k[:4]) >= 2018 and k.split('||')[1] == '문학'] if len(sys.argv) < 2 else sys.argv[1:]
    for k in keys:
        site = A['PAS'][k]
        try: new, s = build(k.split('||')[0], site)
        except Exception as e: new, s = None, "err " + str(e)[:40]
        if new is None: st[s] += 1; continue
        note = ("\n\n※" + site.split("\n\n※", 1)[1]) if "\n\n※" in site else ""
        if Counter(NC(site.split("\n\n※")[0])) != Counter(NC(new)):
            st["bagdiff"] += 1; res[k] = {"ok": False, "new": new + note}; continue
        st["ok"] += 1; res[k] = {"ok": True, "new": new + note}
    json.dump(res, open('/home/claude/chk/rebuild.json', 'w'), ensure_ascii=False, indent=0)
    print(st)

# ==================== chk/manual39.py ====================
# -*- coding: utf-8 -*-
"""원본 그림을 보고 직접 확인한 바로잡기 목록 → manual39.json
형식: [kind, key, num, 바꿀 글(정확히 1곳), 새 글, 근거]"""
import json
M = []
def C(key, num, old, new, why="원본 그림 대조"): M.append(["선지", key, num, old, new, why])
def B(key, old, new, why="원본 그림 대조"): M.append(["보기", key, None, old, new, why])
def P(key, old, new, why="원본 그림 대조"): M.append(["지문", key, None, old, new, why])
# --- 책 이름 묶음표(그림으로만 찍혀 글자가 없던 『) ---
C("2018-06||독서||16", 2, "□성학집요』", "『성학집요』")
C("2019-06||독서||17", 5, "□주제군징』", "『주제군징』")
C("2020-09||화법과 작문||3", 5, "□봉사도』", "『봉사도』")
# --- 옛한글 ---
C("2019-06||문학||33", 5, "‘□을 ᄃᆞᆯ", "‘ᄀᆞ을 ᄃᆞᆯ")
k = "2019-09||언어와 매체||14"
C(k, 2, "듣ᄉᆞᄇᆞ 며", "듣ᄉᆞᄇᆞ며"); C(k, 4, "듣ᄌᆞᄇᆞ 며", "듣ᄌᆞᄇᆞ며"); C(k, 5, "□□ 듣□□ 며", "ᄆᆞᅀᆞᆷ 듣ᅀᆞᄫᆞ며")
B(k, "敬信(경신)□ □□□ 내ᅀᆞᄫᅡ", "敬信(경신)ᄒᆞᆫ ᄆᆞᅀᆞᄆᆞᆯ 내ᅀᆞᄫᅡ")
k = "2021-06||언어와 매체||13"
C(k, 3, "아ᄃᆞᄅᆡ (아", "아ᄃᆞᄅᆡ(아"); C(k, 4, "가온□", "가온ᄃᆡ"); C(k, 5, "㉤: □□ (", "㉤: 드ᇰ자ᇇ("); C(k, 5, " +ㅅ) 기름", "+ㅅ) 기름")
k = "2021-11||언어와 매체||15"
C(k, 2, "□□ 라 ∅라", "ᄉᆞᅀᅵ라 ∅라")
B(k, "ᄉᆞᅀᅵ라[ᄉᆞᅀᅵ (사이)이다]", "ᄉᆞᅀᅵ라[ᄉᆞᅀᅵ(사이)이다]")
k = "2022-09||언어와 매체||39"
C(k, 1, "ᄀᆞᄅᆞ 매", "ᄀᆞᄅᆞ매"); C(k, 3, "불휘□ □□ [", "불휘ᄅᆞᆯ ᄲᅢᅘᅧ ["); C(k, 4, "모□ □□ 노 라 [", "모ᄉᆞᆯ ᄆᆡᇰᄀᆞ노라 ["); C(k, 5, "아ᄅᆞ쇼 셔", "아ᄅᆞ쇼셔")
k = "2023-11||언어와 매체||37"
C(k, 1, "ᄧᆞᆨ, □", "ᄧᆞᆨ, ᄒᆞᆰ"); C(k, 2, "스□□", "스ᄀᆞᄫᆞᆯ"); C(k, 3, "ᄢᅵ니 , ᄧᆞᆨ, □", "ᄢᅵ니, ᄧᆞᆨ, ᄒᆞᆰ"); C(k, 4, "스ᄀᆞᄫᆞᆯ , □", "스ᄀᆞᄫᆞᆯ, ᄒᆞᆰ"); C(k, 5, "ᄢᅵ니 , 사ᄫᅵ, □", "ᄢᅵ니, 사ᄫᅵ, ᄧᆞᆨ")
B(k, "다시 첫소리□ □□니라", "다시 첫소리ᄅᆞᆯ ᄡᅳᄂᆞ니라")
k = "2026-09||언어와 매체||39"
B(k, "‘ᄉᆞᅀᅵ (사이)’", "‘ᄉᆞᅀᅵ(사이)’"); B(k, "‘즈ᅀᅳᆷᄒᆞ 다 (즈음하다)’", "‘즈ᅀᅳᆷᄒᆞ다(즈음하다)’")
B(k, "ᅀᅵᆯ (ᄉᆞᅀᅵ +ㄹ)", "ᅀᅵᆯ(ᄉᆞᅀᅵ+ㄹ)"); B(k, "㉢ 즈ᅀᅳᆷᄒᆞ 고 (즈ᅀᅳᆷᄒᆞ -+-고)", "㉢즈ᅀᅳᆷᄒᆞ고(즈ᅀᅳᆷᄒᆞ-+-고)")
C(k, 1, "‘ᄉᆞᅀᅵ ’", "‘ᄉᆞᅀᅵ’"); C(k, 4, "‘즈ᅀᅳᆷᄒᆞ 다 ’", "‘즈ᅀᅳᆷᄒᆞ다’"); C(k, 5, "‘즈ᅀᅳᆷᄒᆞ 다 ’", "‘즈ᅀᅳᆷᄒᆞ다’")
k = "2026-11||언어와 매체||36"
B(k, "‘ㆆ, ㅿ, , ㆍ’", "‘ㆆ, ㅿ, ㆁ, ㆍ’")
B(k, "15세기 앗겨(←앗기어) 이ᄣᅢ 어버□ □□  즐기디 국어 현대 아껴(←아끼어) 입때 어버이 가득 즐기지 국어", "15세기 국어 앗겨(←앗기어) 이ᄣᅢ 어버ᅀᅵ ᄀᆞᄃᆞᆨ 즐기디 현대 국어 아껴(←아끼어) 입때 어버이 가득 즐기지")
k = "2025-09||언어와 매체||38"
B(k, "然燈ㅅ 스스□ □외 시고 이제 釋迦 ᄅᆞᆯ 돕ᄉᆞᄫᅡ 燈明ㅅ 道ᄅᆞᆯ 니ᅀᅳ시 며", "然燈ㅅ 스스ᅌᅵ ᄃᆞ외시고 이제 釋迦ᄅᆞᆯ 돕ᄉᆞᄫᅡ 燈明ㅅ 道ᄅᆞᆯ 니ᅀᅳ시며")
B(k, "◦내 부텨ᄭᅴ 말□□ □□ □ □  [현대어", "◦내 부텨ᄭᅴ 말ᄊᆞᄆᆞᆯ ᄒᆞᅀᆞᄫᅩᄃᆡ [현대어")
B(k, "ᄃᆞ외 시고(ᄃᆞ외 -＋-시-＋-고)", "ᄃᆞ외시고(ᄃᆞ외-＋-시-＋-고)"); B(k, "㉠ 니ᅀᅳ시 며(", "㉠ 니ᅀᅳ시며(")
B(k, "㉡ □□ □ □ (ᄒᆞ-", "㉡ ᄒᆞᅀᆞᄫᅩᄃᆡ(ᄒᆞ-")

# --- 2차: 원본 그림 대조 ---
C("2015-06-B||독서||25", 1, "값은 □ 배가 □□ 되겠군.", "값은 1/9배가 되겠군.")
k = "2015-06-B||언어와 매체||16"
for n, (a, b) in enumerate([("ᄋᆡ", "ㅅ"), ("ㅅ", "ᄋᆡ"), ("의", "ㅅ"), ("ㅅ", "의"), ("ᄋᆡ", "의")], 1):
    M.append(["선지", k, n, "*", f"㉠ {a} / ㉡ {b}", "원본 그림 대조(㉠·㉡ 구분 표시)"])
C("2011-06||독서||35", 1, "□어제", "어제", "원본에 없는 기호(빈 글자) 삭제"); C("2011-06||독서||35", 2, "□맑은", "맑은", "원본에 없는 기호(빈 글자) 삭제")
C("2010-11||독서||46", 3, "□=n일", "k=n일")
C("2010-06||독서||19", 1, "부호 □, ∙□를", "부호 □, ⊡를")
B("2010-06||독서||19", "노을 □ 노으리 ∙□ 나불 ◇ 나부리 ◇∙ 북새☆", "노을 □ 노으리 ⊡ 나불 ◇ 나부리 ⟐ 북새 ☆")
B("2015-09-A||언어와 매체||14", "작다 ↔ 크다□", "작다 ↔ 크다[1]"); B("2015-09-B||언어와 매체||14", "작다 ↔ 크다□", "작다 ↔ 크다[1]")
B("2016-06-B||언어와 매체||13", "녹는〕□ [1]", "녹는〕 [동] [1]")
B("2016-06-B||언어와 매체||16", "예: 다□ □ (", "예: 다ᄅᆞᆫ ᄯᅡᆺ (")
B("2017-09||문학||18", "니러나 □□ 나셔", "니러나 ᄯᅮᆨ ᄯᅡᆨ 나셔")
B("2017-09||독서||33", "측정하여 □로 열의 일당량을□□ 구하면", "측정하여 B/A로 열의 일당량을 구하면")
B("2012-09||독서||23", "좌표 (□□ □□ m)", "좌표 (k, l, m)")
B("2014-09-B||언어와 매체||16", "ᄒᆞ고져 □ ㉣ᄯᆞᄅᆞ미니라", "ᄒᆞ고져 ᄒᆞᇙ ㉣ᄯᆞᄅᆞ미니라", "『훈민정음』 언해 원문 대조")
B("2014-예비-B||언어와 매체||16", "字□□ ᄀᆞ노니", "字ᄍᆞᆼᄅᆞᆯ ᄆᆡᇰᄀᆞ노니")
B("2014-예비-B||언어와 매체||16", "ᄒᆞ고져 □ □□미니라", "ᄒᆞ고져 ᄒᆞᇙ ᄯᆞᄅᆞ미니라")
B("2021-09||언어와 매체||15", "字·ᄍᆞᆼ·□ □·ᄀᆞ노·니", "字·ᄍᆞᆼ·ᄅᆞᆯ ᄆᆡᇰ·ᄀᆞ노·니", "『훈민정음』 언해 원문 대조")
B("2014-11-B||언어와 매체||16", "字․ᄍᆞᆼ․□ □․ᄀᆞ노․니", "字․ᄍᆞᆼ․ᄅᆞᆯ ᄆᆡᇰ․ᄀᆞ노․니", "『훈민정음』 언해 원문 대조(스캔본)")
B("2011-06||독서||44", "□용비어천가』", "『용비어천가』"); B("2015-11-B||독서||19", "□조선 상고사』", "『조선 상고사』")
# 표·그림으로 된 <보기>: 원본을 보고 다시 옮김
M.append(["보기", "2018-11||언어와 매체||15", None, "*", """<보 기>
[개정 전 → 개정 후]
㉠ 긁다 [동] ｢1｣ 손톱이나 뾰족한 기구 따위로 바닥이나 거죽을 문지르다. ⋮ ｢9｣ ……
→ 긁다 [동] ｢1｣ 손톱이나 뾰족한 기구 따위로 바닥이나 거죽을 문지르다. ⋮ ｢9｣ …… ｢10｣ 물건 따위를 구매할 때 카드로 결제하다.
㉡ 김-밥[김ː밥] [명] ……
→ 김-밥[김ː밥/김ː빱] [명] ……
㉢ 냄새 [명] ｢1｣ 코로 맡을 수 있는 온갖 기운. ｢2｣ 어떤 사물이나 분위기 따위에서 느껴지는 특이한 성질이나 낌새. / 내음 [명] ‘냄새’의 방언(경상).
→ 냄새 [명] ｢1｣ 코로 맡을 수 있는 온갖 기운. ｢2｣ 어떤 사물이나 분위기 따위에서 느껴지는 특이한 성질이나 낌새. / 내음 [명] 코로 맡을 수 있는 나쁘지 않거나 향기로운 기운. 주로 문학적 표현에 쓰인다.
㉣ 태양-계 [명] 태양과 그것을 중심으로 공전하는 천체의 집합. 태양, 9개의 행성, ……
→ 태양-계 [명] 태양과 그것을 중심으로 공전하는 천체의 집합. 태양, 8개의 행성, ……
㉤ (표제어 없음)
→ 스마트-폰 [명] 휴대 전화에 여러 컴퓨터 지원 기능을 추가한 지능형 단말기.
※ 사전의 개정 내용은 표준어와 표준 발음의 최신 정보를 반영한 것임.""", "표로 된 <보기>를 원본 그림을 보고 다시 옮김"])
M.append(["보기", "2011-06||언어와 매체||11", None, "*", """<보 기>
부르다¹ [동] [1] 말이나 행동으로 다른 사람의 주의를 끌거나 오라고 하다.
　　　　　　[2] 무엇이라고 가리켜 말하거나 이름을 붙이다.
부르다² [동] 먹은 것이 많아 속이 꽉 찬 느낌이 들다.
붇다¹ [동] 물에 젖어서 부피가 커지다.
붇다² [동] 분량이나 수효가 많아지다.
[그림] ‘불리다’ ← ㉮ ‘부르다¹[1]’의 피동, ㉯ ‘부르다¹[2]’의 피동, ㉰ ‘부르다²’의 사동, ㉱ ‘붇다¹’의 사동, ㉲ ‘붇다²’의 사동""", "원본 그림 대조(사전 기호·그림 내용 보충)"])
M.append(["보기", "2025-11||언어와 매체||36", None, "*", """<자 료>
◦뎌녁 ⓐᄀᆞᅀᅢ(ᄀᆞᇫ＋애) 걷나가샤 -『석보상절』
[저쪽 가에 건너가시어]
◦뫼화 그르세 ⓑ담아(담-＋-아) -『월인천강지곡』
[모아서 그릇에 담아]
◦ⓒ누네(눈＋에) 빗 봄과 -『석보상절』
[눈에 빛 봄과]
◦쏜 살이 세 낱 ⓓ붚ᄲᅳᆫ(붚＋ᄲᅳᆫ) ᄢᅦ여디니 -『월인천강지곡』
[쏜 화살이 세 개 북만 꿰어지니]
◦너희 ⓔ스스ᇰ니믈(스스ᇰ＋-님＋을) 보ᅀᆞᆸ고져 ᄒᆞ노니 -『석보상절』
[너희 스승님을 뵙고자 하니]""", "원본 그림 대조(자리 밀림·책 이름 묶음표·옛한글)"])
M.append(["보기", "2025-11||언어와 매체||37", None, "*", "<보 기> 동일한 모습의 단어가 다른 의미로 쓰일 때, 이들은 의미의 연관성이 없는 ㉠동음이의어 관계(예 단풍 철:철 성분)나 연관성이 있는 ㉡다의어 관계(예 머리를 깎다:배의 머리)에 놓인다. 다의어는 한 단어가 여러 의미를 지닌 것인데, 이때 그 구체적 의미가 달라 유의어나 반의어가 다른 경우가 있다. 용언이 다의어일 때는 ㉢필수 성분의 개수가 다르거나, 개수는 같고 종류가 다른 경우가 있다. 물론 다의어의 각 의미 간에 유의어나 ㉣반의어가 같은 경우도 있고 ㉤필수 성분의 개수와 종류가 모두 동일한 경우도 있다.", "원본 그림 대조(낱말 자리 밀림, 선지 글 섞임)"])
for n, t in enumerate(["㉠ 난로에 불을 피웠다. / 그들의 사랑에 불이 붙었다.", "㉡ 이곳엔 가위표를 치는 거야. / 구슬 치는 아이가 있다.", "㉢ 나는 종소리를 듣지 못했다. / 충고까지 잔소리로 듣지 마.", "㉣ 배우가 엷은 화장을 했다. / 아이가 엷은 잠에 들었다.", "㉤ 이곳은 벌써 따뜻한 봄이 왔다. / 그의 성공은 부단한 노력에서 왔다."], 1):
    M.append(["선지", "2025-11||언어와 매체||37", n, "*", t, "원본 그림 대조(두 줄 선지가 한 줄씩 밀려 있던 것)"])
M.append(["보기", "2026-11||독서||16", None, "*", """□ 아래의 핵심 개념에 대해 윗글에 제시된 학자들이 보일 수 있는 입장을 작성해 봅시다.
[핵심 개념 1] 자아에 대한 인식과 경험적 인식
∙칸트: 자아를 인식하는 방식과 시공간적 세계의 대상들을 경험적으로 인식하는 방식은 다르다고 본다. …… ①
∙스트로슨: 시공간적 세계에서 이루어지는 경험적 인식은 자아에 대한 인식에 의존한다고 본다. …… ②
[핵심 개념 2] 추상화 과정
∙스트로슨: 경험으로부터의 추상화 과정을 거치지 않고서 ‘나’를 인식할 수 있다는 것에 동의하지 않는다.
∙롱게네스: 경험으로부터의 추상화 과정을 거치지 않고서 ‘나’를 인식할 수 있다는 것에 동의한다. …… ③
[핵심 개념 3] 통시적 인격과 도덕적 존재
∙칸트, 롱게네스: 도덕적 존재로서의 인간이 자율성을 지닌다는 것을 수용한다. …… ④
∙칸트, 스트로슨, 롱게네스: ‘시간의 흐름 속 동일한 인격으로서의 나’라는 개념을 수용한다. …… ⑤""", "학습 활동지가 첫 줄만 옮겨져 있던 것을 원본대로 보충"])
M.append(["보기", "2025-06||독서||14", None, "*", """□ 다음의 진술에 대해 윗글에 제시된 학자들이 보일 수 있는 견해를 작성해 봅시다.
[진술 1] 객관적으로 존재하는 도덕적 사실이 있다.
∙전통적인 윤리학자: 옳다. 도덕적 판단의 근거는 도덕 주체로부터 독립적으로 존재하기 때문이다. …… ①
∙에이어: 옳지 않다. 도덕 문장은 도덕 주체로부터 독립적일 수 없기 때문이다. …… ②
[진술 2] 도덕 문장은 참 또는 거짓이라는 속성을 갖는다.
∙에이어: 옳지 않다. 도덕 문장은 분석적이지도 종합적이지도 않기 때문이다. …… ③
∙행크스: 옳다. 도덕 문장은 도덕 용어가 나타내는 속성에 비추어 참 또는 거짓이 정해지기 때문이다.
[진술 3] 전건 긍정식의 두 전제에 공통으로 포함된 도덕 문장은 내용이 다르다.
∙에이어: 옳다. 도덕 문장은 전건 긍정식의 전제로 사용되면 진리 적합성을 갖기 때문이다. …… ④
∙행크스: 옳지 않다. 단독으로 진술된 문장은 조건문의 일부로 사용된 때와 내용 차이가 없기 때문이다. …… ⑤""", "학습 활동지가 첫 줄만 옮겨져 있던 것을 원본대로 보충"])
C("2025-06||독서||14", 1, "주체로 부터", "주체로부터"); C("2026-11||독서||16", 4, "지닌 다는", "지닌다는"); C("2026-11||독서||16", 5, "인격 으로서의", "인격으로서의")

json.dump(M, open("/home/claude/chk/manual39.json", "w"), ensure_ascii=False, indent=0)
print(len(M))
# --- 3차: 지문 (원본 그림 대조) ---
M2 = []
def Q(key, old, new, why="원본 그림 대조"): M2.append(["지문", key, None, old, new, why])
Q("2009-06||독서||40~42", "자내 향□ □□□ □□ 니ᄌᆞᆯ", "자내 향ᄒᆡ ᄆᆞᄋᆞᄆᆞᆯ ᄎᆞᄉᆡᆼ 니ᄌᆞᆯ")
Q("2010-06||문학||31~35", "고잣□ □ ᄇᆡᆨ옥", "고잣ᄂᆞᆫ ᄃᆞᆺ ᄇᆡᆨ옥"); Q("2010-06||문학||31~35", "ᄯᅩ 잇□가.", "ᄯᅩ 잇ᄂᆞᆫ가.")
Q("2011-09||독서||19~20", "x, y, □는", "x, y, z는"); Q("2011-09||독서||19~20", "물1 체의", "물체의")
Q("2011-09||독서||19~20", "시간은 □ 배 팽창한다. □□□ −(v/c) 즉,", "시간은 1/√(1−(v/c)²) 배 팽창한다. 즉,")
Q("2012-09||독서||21~23", "점은 □□□□□ =5²이므로", "점은 4²+3²=5²이므로")
k = "2013-11||독서||29~31"
Q(k, "표현하면RTR P=□( : 기체 상수)가 되는데, 이를 ㉠이상 기체 상태 방정식V 이라 한다.", "표현하면 P=RT/V(R: 기체 상수)가 되는데, 이를 ㉠이상 기체 상태 방정식이라 한다.")
Q(k, "제곱에a 반비례하는데, 이것을 비례 상수 a가 포함된 □로 나타낼V□ 수 있다.", "제곱에 반비례하는데, 이것을 비례 상수 a가 포함된 a/V²로 나타낼 수 있다.")
Q(k, "이상 기체에a 비해 □만큼 줄게 된다. V□ 이와", "이상 기체에 비해 a/V²만큼 줄게 된다. 이와")
Q(k, "보정하면RTa P=−가 된다. 이를 ㉡반데르발스 상태 방정식이라V□b V² 하는데", "보정하면 P=RT/(V−b)−a/V²가 된다. 이를 ㉡반데르발스 상태 방정식이라 하는데")
Q("2014-09-A||독서||16~18", "방향 □AN□으로", "방향 AN⃗으로"); Q("2014-09-A||독서||16~18", "방향 □BN□을", "방향 BN⃗을")
Q("2014-09-B||문학||31~33", "기약(期約)□니", "기약(期約)ᄒᆞ니"); Q("2014-09-B||문학||31~33", "너□인가", "너ᄲᅮᆫ인가")
k = "2015-06-B||문학||43~45"
Q(k, "죽다 □니", "죽다 ᄒᆞ니"); Q(k, "못□얘", "못ᄒᆞ얘"); Q(k, "오명가명 □거든", "오명가명 ᄒᆞ거든"); Q(k, "(皎皎白駒)*□ 멀리", "(皎皎白駒)*ᄂᆞᆫ 멀리"); Q(k, "□믈며", "ᄒᆞ믈며")
k = "2015-11-A||독서||20~22"
Q(k, "축nn 소해서", "축소해서"); Q(k, "표시하려면 □× □의 가상 영상을 만들고 화□□ 솟값을", "표시하려면 n/2×n/2의 가상 영상을 만들고 화솟값을"); Q(k, "²n×²n의", "2n×2n의")
M2.append(["보기", "2015-11-A||독서||22", None, "111×□□□개", "100×100개", "원본 그림 대조"])
Q("2015-11-B||문학||31~34", "원(怨)□□ □", "원(怨)ᄒᆞᄂᆞᆫ ᄃᆞᆺ")
Q("2016-06-B||문학||31~33", "쌍□목*", "쌍비목*"); Q("2016-06-B||문학||31~33", "날지 말고 □ 말 들어", "날지 말고 ᄂᆡ 말 들어")
k = "2016-11-B||문학||40~42"
Q(k, "(棟梁材)*□ 뎌리", "(棟梁材)*ᄅᆞᆯ 뎌리"); Q(k, "화살 □ 수하상직", "화살 ᄎᆞᆫ 수하상직"); Q(k, "힘써 □고", "힘써 ᄒᆞᆯ고")
k = "2014-예비-B||문학||34~35"
Q(k, "두어 집이 □* 속의", "두어 집이 ᄂᆡᆺ* 속의", "원본 그림·각주(*ᄂᆡᆺ) 대조"); Q(k, "슬□지 용여(容與)□쟈*", "슬ᄏᆞ지 용여(容與)ᄒᆞ쟈*", "각주(*용여ᄒᆞ쟈)·「어부사시사」 원문 대조")
Q(k, "□ □여라 □ □여라", "ᄇᆡ 셰여라 ᄇᆡ 셰여라", "「어부사시사」 원문 대조"); Q(k, "구룸 □(恨)티", "구룸 ᄒᆞᆫ(恨)티"); Q(k, "어□와(於思臥)", "어ᄉᆞ와(於思臥)"); Q(k, "막□또다", "막ᄂᆞᆫ또다", "「어부사시사」 원문 대조")
Q("2017-06||언어와 매체||11~12", "어간이 ‘□-’으로", "어간이 ‘젛-’으로")
Q("2017-06||독서||25~27", "가시□ □ 도셔", "가시ᄂᆞᆫ ᄃᆞᆺ 도셔", "「가시리」 원문 대조")
Q("2017-09||문학||16~18", "끈칠□ □노 라", "끈칠ᄭᅡ ᄒᆞ노라")
Q("2024-06||언어와 매체||35~36", "(□＋ ᄋᆡ그", "(ᄂᆞᆷ＋ᄋᆡ그")
Q("2025-11||언어와 매체||35~36", "‘님□ □□ ’ (임금의 마음)", "‘님긊 ᄆᆞᅀᆞᆷ’(임금의 마음)"); Q("2025-11||언어와 매체||35~36", "‘ᄃᆞ외 다’, ‘ᄒᆞ오 □’로만", "‘ᄃᆞ외다’, ‘ᄒᆞ오ᅀᅡ’로만")
k = "2027-09||언어와 매체||35~36"
Q(k, "현대 국어에서 쓰인다(□: 불규칙 활용을 하는 형용사로 거머□다 >거멓다).", "현대 국어에서 불규칙 활용을 하는 형용사로 쓰인다([예]: 거머ᄒᆞ다>거멓다).", "원본 그림 대조(낱말 자리 밀림)")
Q(k, "빛깔의 있다(□: 밝거나 어두운 정도를 나타낼 수 희붉다).", "빛깔의 밝거나 어두운 정도를 나타낼 수 있다([예]: 희붉다).", "원본 그림 대조(낱말 자리 밀림)")
Q(k, "빛깔이 있다(□: 매우 선명함을 나타낼 수 검디검다).", "빛깔이 매우 선명함을 나타낼 수 있다([예]: 검디검다).", "원본 그림 대조(낱말 자리 밀림)")
Q("2022-06||언어와 매체||40~42", "나들이: □ 맞아요", "나들이: 맞아요"); Q("2022-06||언어와 매체||40~42", "방치 골칫거리” 되어", "방치되어 골칫거리”", "원본 그림 대조(낱말 자리 밀림)")
Q("2025-11||언어와 매체||35~36", "『월인 천강지곡□을 □훈민정음□ 보면 표기법이 통일되어 있지 않다. 예컨대 (해례본)의", "『월인천강지곡』을 보면 표기법이 통일되어 있지 않다. 예컨대 『훈민정음』(해례본)의", "원본 그림 대조(낱말 자리 밀림·책 이름 묶음표)")
Q("2025-11||언어와 매체||35~36", "『용비어 천가』와", "『용비어천가』와")
M.extend(M2)
json.dump(M, open("/home/claude/chk/manual39.json", "w"), ensure_ascii=False, indent=0)
print("total", len(M))
M3 = []
k = "2023-06||독서||10~13"
for a, b in [("㉠비타민 K과 동물", "㉠비타민 K₁과 동물"), ("㉡비타민 K로 나뉜다", "㉡비타민 K₂로 나뉜다"), ("비타민 K을 충분히", "비타민 K₁을 충분히"), ("비타민 K과 K는 모두", "비타민 K₁과 K₂는 모두"),
             ("활성화를 1 2 유도하지만 K은 간세포에서, K는 그 외의 세포에서 활성이 1 2 높다.", "활성화를 유도하지만 K₁은 간세포에서, K₂는 그 외의 세포에서 활성이 높다."),
             ("주로 K이, 그 외의", "주로 K₁이, 그 외의"), ("주로 K 가 담당한다", "주로 K₂가 담당한다"), ("권장량을 K과 K로 1 2 구분하여 설정해야 하며, K가 함유된", "권장량을 K₁과 K₂로 구분하여 설정해야 하며, K₂가 함유된")]:
    M3.append(["지문", k, None, a, b, "원본 그림 대조(아래 첨자 흩어짐)"])
M.extend(M3)
json.dump(M, open("/home/claude/chk/manual39.json", "w"), ensure_ascii=False, indent=0)
print("total", len(M))

# ==================== chk/gen_pass.py ====================
import json, re
R = json.load(open("resolve38_v2.json"))
OK = re.compile(r"^[ᄀ-ᇿ『』²³¹⁰-⁹ₐ-ₜ₀-₉a-zA-Z+\-=·∙′″]+$")
P, Lf = [], []
for r in R:
    c = r["cap"]
    rep = None
    if c is not None:
        cc = c.replace("​", "").strip()
        if cc and OK.match(cc.replace(" ", "")) and len(cc) <= 12 and not (r["nmatch"] >= 2 and c is None):
            # 맥락이 너무 짧으면(앞뒤 합쳐 비공백 3자 미만) 쓰지 않는다
            if len(re.sub(r"\s", "", r["L"] + r["R"])) >= 3: rep = cc
            # 이웃한 □ 묶음 사이의 공백만 맥락으로 잡힌 경우, 가운뎃소리·끝소리로 시작하는 조각은 자리가 어긋난 것이므로 버린다
            if rep and (not r["L"].strip() or not r["R"].strip()): rep = None
            if rep and "\u1160" <= rep[0] <= "\u11ff": rep = None
    if rep: r = dict(r, rep=rep); P.append(r)
    else: Lf.append(r)
json.dump(P, open("pass2.json", "w"), ensure_ascii=False, indent=0)
json.dump(Lf, open("left2.json", "w"), ensure_ascii=False, indent=0)
print(len(P), len(Lf))
for r in P: print(r["kind"], r["key"], r["num"], repr(r["L"][-8:]), "[" + r["rep"] + "]", repr(r["R"][:8]))

# ==================== chk/disamb38.py ====================
# -*- coding: utf-8 -*-
"""resolve.json 중 맥락이 원본에서 여러 번 나온 것(nmatch≥2)을, 후보 위치마다 더 넓은 앞뒤 맥락(선지는 원문자 번호)을 비교해
가장 잘 맞는 한 곳의 글자로 고친다. 동점이면 cap=None(손대지 않음). 출력: resolve_v2.json"""
import json, re
exec(open('/home/claude/chk/extract38.py').read().split("DIFF = []")[0])
PAS = json.loads([l for l in s if l.startswith("const PASSAGES = ")][0][17:].rstrip(";"))
ITD = {f"{it['exam_id']}||{it['영역']}||{it['문항번호']}": it for it in IT}
import sys
sys.path.insert(0,'/home/claude/chk')
from pua_map import READ, compose
from openpyxl import load_workbook
_ws=load_workbook("/home/claude/chk/직접확인_목록_원본.xlsx")["2 옛한글·기호(글자별)"]
CODE={}
for _r in _ws.iter_rows(min_row=2, values_only=True):
    _num,_code,_typed=_r[0].split("-")[1],_r[2],_r[6]
    if _typed: CODE[chr(int(_code[2:],16))]=_typed
    elif _num in READ: CODE[chr(int(_code[2:],16))]=compose(READ[_num])
CODE["\U000f0854"]="『"; CODE["\U000f0855"]="』"
import sys as _s; _s.path.insert(0, "/home/claude/chk"); from pua_map import EXTRA as _EX; CODE.update(_EX)
def mapd(t): return "".join(CODE.get(c,c) for c in t)
R = json.load(open("resolve38.json"))
exec(open("/home/claude/chk/resolve38.py").read().split("def mapd")[0].split("import sys")[1].join(["import sys",""]) if False else "")
DISP = {}
def disp(ex):
    if ex not in DISP:
        try: DISP[ex] = mapd(build(ex)[2].replace("​", ""))
        except Exception: DISP[ex] = None
    return DISP[ex]
def text_of(r):
    if r["kind"] == "선지": return CH[r["key"]][r["num"] - 1]
    if r["kind"] == "지문": return PAS[r["key"]]
    return ITD[r["key"]][r["kind"]]
def ctx_re(t): return "".join((r"\s*" if ch.isspace() else re.escape(ch) + r"\s*") for ch in t)
def NN(t): return re.sub(r"[\s​]", "", "".join(ch for ch in t if not (0xE000 <= ord(ch) <= 0xF8FF or ord(ch) >= 0xF0000 or ch == "□")))
def score_back(site, src):
    a, b = NN(site), NN(src); n = 0
    while n < len(a) and n < len(b) and a[-1 - n] == b[-1 - n]: n += 1
    return n
def score_fwd(site, src):
    a, b = NN(site), NN(src); n = 0
    while n < len(a) and n < len(b) and a[n] == b[n]: n += 1
    return n
out = []; stat = {"same": 0, "changed": 0, "unres": 0}
for r in R:
    r2 = dict(r)
    if r["nmatch"] >= 2 and r["cap"] is not None:
        ex = r["key"].split("||")[0]; D = disp(ex); t = text_of(r)
        L, Rr = r["L"], r["R"]; p, q = r["pos"], r["pos"] + len(r["run"])
        rx = re.compile(ctx_re(L) + r"\s*(.{0,6}?)" + (r"\s*" if Rr else "") + ctx_re(Rr))
        cands = list(rx.finditer(D))
        before = t[max(0, p - len(L) - 40):p - len(L)]; after = t[q + len(Rr):q + len(Rr) + 40]
        sc = []
        for m in cands:
            s1 = score_back(before, D[max(0, m.start() - 80):m.start()])
            s2 = score_fwd(after, D[m.end():m.end() + 80])
            s3 = 0
            if r["kind"] == "선지" and not NN(before):
                tail = NN(D[max(0, m.start() - 6):m.start()])
                s3 = 100 if tail.endswith("①②③④⑤"[r["num"] - 1]) else 0
            sc.append((s1 + s2 + s3, m.group(1)))
        sc.sort(key=lambda x: -x[0])
        if len(sc) >= 2 and sc[0][0] == sc[1][0] and sc[0][1] != sc[1][1]: r2["cap"] = None; stat["unres"] += 1
        elif sc and sc[0][1] == r["cap"]: stat["same"] += 1
        elif sc: r2["cap"] = sc[0][1]; r2["old"] = r["cap"]; stat["changed"] += 1
    out.append(r2)
json.dump(out, open("resolve38_v2.json", "w"), ensure_ascii=False)
print(stat)
for r in out:
    if "old" in r or (r["nmatch"] >= 2 and r["cap"] is None): print(r["kind"], r["key"], r["num"], repr(r["L"][-8:]), repr(r["R"][:6]), [hex(ord(c)) for c in (r.get("old") or "")], "→", [hex(ord(c)) for c in (r["cap"] or "")])

# ==================== chk/pua_map.py (판독표 끝부분: 수정·추가분) ====================
11:"081":"ㅈㆍㅂ","082":"ㄷㅠㆁ","083":"ㅆㆎ","084":"ㄱㆍㅅ","085":"ㅅㆎ","086":"ㅇㆍㅂ","091":"ㅺㆎ","092":"ㄷㆍㄺ","093":"낡","094":"ㅋㅗㆁ","096":"ㅅㆍㅅ","097":"ㅆㆍㅁ","098":"ㅸㅓ","099":"ㅿㆍㅸ","100":"ㅈㅠㆁ","101":"ㄱㆍㄹ",
12:"102":"ㅇㅑㆁ","103":"ㅈㆎ","104":"ㆁㅣ","105":"ㅽㅡㄴ","106":"ㅅㆍㅂ","107":"ㅅㅕㆁ","109":"ㅈㆍㄱ","110":"ㅼㅏㅎ","112":"ㅸㆎ","113":"ㅄㅜㅊ","115":"ㄷㅡㆁ","116":"ㅄㅡ","117":"ㅊㆎ","118":"ㅶㆍㄱ","119":"ㅴㅣ","120":"ㅺㅜㅁ",
27:EXTRA = {"\ue9a3": "ᄉᆡᇰ", "\ued83": "ᅀᅵᆯ", "\uf164": "자ᇇ", "\uea79": "ᄯᅡᆺ", "\ueafc": "ᄯᆞᆯ", "\uee20": "외", "\ueae7": "ᄯᅴ", "\ue017": "", "\ue052": ",", "\uf186": "젛"}
