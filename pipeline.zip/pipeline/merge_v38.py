# -*- coding: utf-8 -*-
"""merge_v37 → 사용자 정의 영역(PUA) 글자로 깨져 □로 보이던 옛한글·수식 기호·책 이름 묶음표를 바로잡는다 → site_v38.html
근거: chk/resolve.json(□ 자리마다 원본 PDF에서 찾은 글자 코드), chk/pua_map.py(옛한글 판독표), 직접확인 목록 2번 시트의 기호 판독."""
import json, re, subprocess, sys
sys.path.insert(0, "/home/claude/chk")
subprocess.run(["python3", "/home/claude/merge_v37.py"], check=True)
from pua_map import READ, compose
from openpyxl import load_workbook
SRC = "/home/claude/site_v37.html"; DST = "/home/claude/site_v38.html"
lines = open(SRC, encoding="utf-8").read().split("\n")
def idx(n): return [k for k, l in enumerate(lines) if l.startswith(f"const {n} = ")][0]
def load(n): return json.loads(lines[idx(n)][len(f"const {n} = "):].rstrip(";"))
def save(n, v): lines[idx(n)] = f"const {n} = " + json.dumps(v, ensure_ascii=False) + ";"
ITEMS = load("ITEMS"); CHO = load("CHOICES"); PAS = load("PASSAGES")
IT = {f'{i["exam_id"]}||{i["영역"]}||{i["문항번호"]}': i for i in ITEMS}
# 코드 → 글자
wb = load_workbook("/home/claude/chk/직접확인_목록_원본.xlsx"); ws = wb["2 옛한글·기호(글자별)"]
CODE = {}
for r in ws.iter_rows(min_row=2, values_only=True):
    num, code, typed = r[0].split("-")[1], r[2], r[6]
    if typed: CODE[chr(int(code[2:], 16))] = typed
    elif num in READ: CODE[chr(int(code[2:], 16))] = compose(READ[num])
CODE["\U000f0854"] = "『"; CODE["\U000f0855"] = "』"
import sys as _s; _s.path.insert(0, "/home/claude/chk"); from pua_map import EXTRA as _EX; CODE.update(_EX)
R = json.load(open("/home/claude/chk/resolve_v2.json"))
# 맥락이 원본에서 여러 번 나온 자리는, 넓은 맥락으로 다시 따져도 같은 글자가 나온 경우만 쓴다(chk/disamb.py)
R = [r for r in R if r["nmatch"] == 1 or (r["nmatch"] >= 2 and r["cap"] is not None and "old" not in r)]
def conv(cap):
    if cap is None: return None
    c = cap.replace("​", "").strip()
    if not c or c in ("□", "□□"): return None
    out = ""
    for ch in c:
        if ch in CODE: out += CODE[ch]
        elif ch.isspace(): continue
        else: return None            # 원본 글자 흐름과 정확히 맞지 않은 경우는 건드리지 않는다
    return out
by = {}
for r in R:
    rep = conv(r["cap"])
    if rep is None: continue
    by.setdefault((r["kind"], r["key"], r["num"]), []).append((r["pos"], len(r["run"]), rep, r["L"], r["R"]))
n = 0; skipped = 0
def apply(text, reps):
    global n, skipped
    for pos, ln, rep, L, Rr in sorted(reps, reverse=True):
        if text[pos:pos+ln] != "□" * ln or (L and not text[:pos].endswith(L)): skipped += 1; continue
        text = text[:pos] + rep + text[pos+ln:]; n += 1
    return text
for (kind, key, num), reps in by.items():
    if kind == "선지": CHO[key][num-1] = apply(CHO[key][num-1], reps)
    elif kind == "지문": PAS[key] = apply(PAS[key], reps)
    else: IT[key][kind] = apply(IT[key][kind], reps)
save("ITEMS", ITEMS); save("CHOICES", CHO); save("PASSAGES", PAS)
s = "\n".join(lines)
A = "이런 문항의 표 전체 내용은 제시 자료(&lt;보기&gt;) 칸에 옮겨 두었습니다."
assert s.count(A) == 1
s = s.replace(A, A + f" 또 원본 PDF 안에서 글자 코드가 깨져 □로 보이던 옛한글·수식 기호·책 이름 묶음표 {n:,}곳을 원본의 글자 모양을 보고 되살렸습니다. 옛한글은 첫소리·가운뎃소리·끝소리 자모를 이어 적는 방식이라, 옛한글을 지원하지 않는 글꼴에서는 자모가 풀어져 보일 수 있습니다.")
open(DST, "w", encoding="utf-8").write(s)
print("replaced", n, "skipped", skipped)
