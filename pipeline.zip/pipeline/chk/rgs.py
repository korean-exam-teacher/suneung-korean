# 여러 영역을 한 그림으로: rgs.py OUT "EX|찾을글|좌우pt|위아래줄|k" ...
import sys, subprocess, json, re
exec(open("/home/claude/chk/locate.py").read().split('if __name__')[0])
from PIL import Image, ImageDraw, ImageFont
F = ImageFont.truetype("/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc", 22)
out = []
for spec in sys.argv[2:]:
    p = spec.split("|"); ex, q = p[0], p[1]; pad = float(p[2]) if len(p) > 2 else 150; nl = float(p[3]) if len(p) > 3 else 2; k = int(p[4]) if len(p) > 4 else 0
    qn = keyN(q); hits = []
    for pi, col, s, idx in pages(ex):
        for m in re.finditer(re.escape(qn).replace("\\x00", "."), s): hits.append((pi, idx[m.start():m.end()]))
    if not hits: print("nf", spec); continue
    pi, cs = hits[min(k, len(hits) - 1)]; dpi = 300; sc = dpi / 72
    x0 = max(0, min(c["x0"] for c in cs) - pad); x1 = max(c["x1"] for c in cs) + pad
    h = max(c["bottom"] - c["top"] for c in cs); t0 = max(0, min(c["top"] for c in cs) - h * nl); b0 = max(c["bottom"] for c in cs) + h * nl
    subprocess.run(["pdftoppm", "-r", str(dpi), "-f", str(pi+1), "-l", str(pi+1), "-x", str(int(x0*sc)), "-y", str(int(t0*sc)), "-W", str(int((x1-x0)*sc)), "-H", str(int((b0-t0)*sc)), "-png", "-singlefile", SRC + fname(ex), "/tmp/claude-0/rgs"], check=True, stderr=subprocess.DEVNULL)
    im = Image.open("/tmp/claude-0/rgs.png")
    b = Image.new("RGB", (max(im.size[0], 600), im.size[1] + 30), "white"); ImageDraw.Draw(b).text((4, 2), spec, fill=(200, 0, 0), font=F); b.paste(im, (0, 28)); out.append(b)
W = max(b.size[0] for b in out); H = sum(b.size[1] + 8 for b in out)
o = Image.new("RGB", (W, H), (200, 200, 200)); y = 0
for b in out: o.paste(b, (0, y)); y += b.size[1] + 8
o.save(sys.argv[1]); print(o.size)
