# -*- coding: utf-8 -*-
"""원본 문제지 PDF → 단(왼쪽/오른쪽) 순서로 읽은 줄 목록. 선지 대조용 독립 추출.
출력: /home/claude/chk/streams/<exam>.json  [{pg, col, top, x0, t}]"""
import pdfplumber, json, sys, os, re
from concurrent.futures import ProcessPoolExecutor
SRC = "/mnt/user-data/uploads/평가원 기출 문제 모음/"
OUT = "/home/claude/chk/streams/"
def fname(ex):
    p = ex.split("-")
    if p[1] == "예비": return f"2014.00.{p[2]} 문제.pdf"
    if ex == "2027-06": return "2027. 06 문제.pdf"
    if ex == "2022-11": return "2022.11 문제(홀수).pdf"
    return f"{p[0]}.{p[1]}" + (f".{p[2]}" if len(p) > 2 else "") + " 문제.pdf"

def lines_of(chars):
    chars = sorted(chars, key=lambda c: (round(c["top"]), c["x0"]))
    rows = []
    for c in sorted(chars, key=lambda c: c["top"]):
        if rows and abs(rows[-1]["top"] - c["top"]) <= 2.5: rows[-1]["cs"].append(c)
        else: rows.append({"top": c["top"], "cs": [c]})
    out = []
    for r in rows:
        cs = sorted(r["cs"], key=lambda c: c["x0"]); t = ""; prev = None
        for c in cs:
            if prev is not None and c["x0"] - prev["x1"] > c["size"] * 0.25: t += " "
            t += c["text"]; prev = c
        out.append({"top": round(r["top"], 1), "x0": round(cs[0]["x0"], 1), "t": t})
    return out

def run(ex):
    f = SRC + fname(ex)
    res = []
    with pdfplumber.open(f) as pdf:
        for pi, pg in enumerate(pdf.pages):
            W = pg.width; ch = pg.dedupe_chars().chars
            ch = [c for c in ch if c["text"].strip()]
            if not ch: continue
            # 단 사이 빈 곳 찾기(가운데 30~70% 구간에서 글자가 가장 적게 덮는 x)
            cov = [0] * int(W + 1)
            for c in ch:
                for x in range(int(c["x0"]), min(int(c["x1"]) + 1, len(cov))): cov[x] += 1
            lo, hi = int(W * 0.35), int(W * 0.65)
            g = min(range(lo, hi), key=lambda x: (cov[x], abs(x - W / 2)))
            for col, part in enumerate([[c for c in ch if (c["x0"] + c["x1"]) / 2 < g], [c for c in ch if (c["x0"] + c["x1"]) / 2 >= g]]):
                for l in lines_of(part): res.append({"pg": pi, "col": col, **l})
    json.dump(res, open(OUT + ex + ".json", "w"), ensure_ascii=False)
    return ex, len(res)

if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    exs = sys.argv[1:]
    with ProcessPoolExecutor(8) as P:
        for r in P.map(run, exs): print(*r, flush=True)
