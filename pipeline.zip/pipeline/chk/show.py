import json,difflib,re,sys
exec(open('extract.py').read().split("DIFF = []")[0])
D=json.load(open('diff.json'))
out=[]
for r in D:
    if r['status']!='diff': continue
    ops_all=[]
    for k,(a,b) in enumerate(zip(r['site'],r['src'])):
        A,B=N(a),N(b)
        if A==B: continue
        sm=difflib.SequenceMatcher(None,A,B,autojunk=False)
        ops=[(t,A[i1:i2],B[j1:j2]) for t,i1,i2,j1,j2 in sm.get_opcodes() if t!='equal']
        ops_all.append((k+1,ops))
    out.append((r['key'],ops_all))
json.dump(out,open('ops.json','w'),ensure_ascii=False)
for key,o in out:
    line=key+" :: "+" | ".join(f"{k}:"+";".join(f"[{a[:25]}→{b[:25]}]" for t,a,b in ops) for k,ops in o)
    print(line[:400])
