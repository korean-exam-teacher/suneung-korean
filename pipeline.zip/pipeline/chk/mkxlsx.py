import json, re, os, sys
from collections import Counter, defaultdict
from PIL import Image, ImageDraw
from openpyxl import Workbook
from openpyxl.drawing.image import Image as XImg
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
sys.path.insert(0,'/home/claude/chk')
import glyph as G
from streams import fname
s=open('/home/claude/site_v37.html',encoding='utf-8').read().split("\n")
def load(n): return json.loads([l for l in s if l.startswith(f"const {n} = ")][0][len(f"const {n} = "):].rstrip(";"))
IT=load("ITEMS"); CH=load("CHOICES")
ITK={f"{i['exam_id']}||{i['영역']}||{i['문항번호']}":i for i in IT}
R=json.load(open('resolve.json')); P=json.load(open('puapos.json')); D=json.load(open('pdiff_rows.json'))
TITLE=("\U000f0854","\U000f0855")
def ispua(c): o=ord(c); return (0xE000<=o<=0xF8FF or o>=0xF0000) and c not in TITLE
def split(k):
    ex,a,n=k.split("||"); return ex,a,n
def exname(ex):
    p=ex.split("-")
    if p[1]=="예비": return f"2014학년도 예비({p[2]}형)"
    m={"06":"6월","09":"9월","11":"수능"}[p[1]]
    return f"{p[0]}학년도 {m}"+(f"({p[2]}형)" if len(p)>2 else "")
def pdfname(ex):
    if ex in ("2009-09",): return "2009학년도 9월.pdf (스캔)"
    if ex in ("2009-11","2014-11-A","2014-11-B"): return fname(ex)+" (스캔)"
    return fname(ex)
wb=Workbook()
HDR=Font(bold=True,color="FFFFFF"); FILL=PatternFill("solid",fgColor="3B5B8C"); WR=Alignment(wrap_text=True,vertical="top")
INF=PatternFill("solid",fgColor="FFF4CC"); thin=Side(style="thin",color="BBBBBB")
def sheet(title,cols,widths):
    ws=wb.create_sheet(title); ws.append(cols)
    for i,c in enumerate(cols,1):
        cell=ws.cell(1,i); cell.font=HDR; cell.fill=FILL; cell.alignment=Alignment(wrap_text=True,vertical="center")
        ws.column_dimensions[cell.column_letter].width=widths[i-1]
    ws.freeze_panes="A2"; return ws
def fin(ws,inputcols):
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.alignment=WR; c.border=Border(top=thin,bottom=thin,left=thin,right=thin)
            if c.column in inputcols: c.fill=INF
# 0 안내
ws=wb.active; ws.title="안내"
guide=["국어 기출 문제은행 – 직접 확인·입력이 필요한 목록 (2026-10-14, 사이트 Version 39 기준)","",
"노란 칸에 입력해 주세요. 캡처로 주실 때는 '번호'를 파일 이름에 넣어 주시면 됩니다(예: 2-015.png).","",
"1 그림 선지: 선지가 그래프·도식이라 글로 옮기지 못한 8문항. 캡처해 주시면 그림으로 넣거나, 글로 풀어 쓸 수 있으면 적어 주세요.",
"2 옛한글·기호(글자별): 원본 PDF에서 글자 정보가 깨져 사이트에 □로 나오는 글자들입니다. 같은 코드는 같은 글자라서 한 번만 입력하면 해당 글자가 나오는 모든 곳(오른쪽 '나온 횟수')에 한꺼번에 들어갑니다. 그림 속 빨간 네모 안 글자를 입력해 주세요.",
"   - 옛한글은 한글(HWP)의 '문자표 → 옛한글' 또는 '옛한글 입력기'로 입력한 뒤 복사해 붙여 주시면 됩니다. 입력이 어려우면 '첫소리+가운뎃소리+끝소리' 식으로 적어 주셔도 됩니다(예: ㅎ+ㆍ).",
"3 □ 개별 확인: 원본에서 글자 코드조차 없거나(빈 글자) 위치를 자동으로 찾지 못한 □입니다. 원본 쪽을 보고 □ 자리에 들어갈 글자를 적어 주세요.",
"4 지문·보기 의심: 원본 글자 흐름과 비교해 어긋난 곳입니다. 대부분은 별표(*)가 붙은 낱말·말하는 사람 이름·[A] 같은 기호·아래 첨자 숫자가 다른 줄로 밀려난 것으로, 원본 글자 흐름(오른쪽 칸)이 맞는 경우가 많아 Claude가 원본대로 고칠 수 있습니다. 'Claude 의견' 칸을 보시고, 다르게 고쳐야 할 곳만 적어 주시면 됩니다.",
"5 책 이름 『』(자동 수정 예정): 책 이름 묶음표가 □로 나오는 곳. 원본에서 『』임이 확인되어 Claude가 자동으로 고칩니다. 확인만 하시면 됩니다.","",
"※ '4'는 원본과 비교할 수 있었던 지문·보기만 대상입니다(지문 앞뒤를 원본에서 찾지 못한 지문 약 90개, 보기 약 100개는 이번 비교에서 빠졌습니다)."]
for g in guide: ws.append([g])
ws.column_dimensions["A"].width=140; ws["A1"].font=Font(bold=True,size=13)
for r in ws.iter_rows(): r[0].alignment=Alignment(wrap_text=True)
# 1 그림 선지
ws=sheet("1 그림 선지",["번호","회차","영역","문항","발문","원본 파일","내용 입력 또는 캡처 파일 이름","메모"],[7,20,12,7,60,30,40,20])
PICS=["2010-09||독서||38","2010-11||독서||49","2012-06||독서||48","2013-06||독서||25","2013-09||독서||18","2014-09-A||독서||21","2009-09||독서||15","2009-09||독서||44"]
for i,k in enumerate(PICS,1):
    ex,a,n=split(k); ws.append([f"1-{i:02d}",exname(ex),a,int(n),ITK[k]["발문"],pdfname(ex),"",""])
fin(ws,{7})
# 2 글자별
ws=sheet("2 옛한글·기호(글자별)",["번호","원본 글자(빨간 네모)","코드","나온 횟수","나온 곳(일부)","그림 출처","입력할 글자","메모"],[8,26,11,8,46,26,18,20])
cnt=Counter(); where=defaultdict(list)
for r in R:
    if not r['cap']: continue
    for c in r['cap']:
        if ispua(c):
            cnt[c]+=1
            lab=f"{exname(r['key'].split('||')[0])} {r['key'].split('||')[1]} {r['key'].split('||')[2]}"+(f" ⑤"[:0]+f" {r['num']}번 선지" if r['num'] else f" ({r['kind']})")
            if lab not in where[c]: where[c].append(lab)
os.makedirs('/home/claude/chk/glyphs',exist_ok=True)
row=2
gl_index={}
for i,(c,n) in enumerate(cnt.most_common(),1):
    exs=[]
    for r in R:
        if r['cap'] and c in r['cap']:
            e=r['key'].split('||')[0]
            if e not in exs: exs.append(e)
    path=f'/home/claude/chk/glyphs/{ord(c):X}.png'
    src=None
    for ex in exs:
        if c in P.get(ex,{}):
            pg,x0,top,x1,bot=P[ex][c][0]; im=G.page(ex,pg); SC=G.SC; h=max(bot-top,8)
            box=(int((x0-h*2.2)*SC),int((top-h*0.4)*SC),int((x1+h*2.2)*SC),int((bot+h*0.4)*SC))
            cimg=im.crop(box).convert("RGB"); dr=ImageDraw.Draw(cimg)
            dr.rectangle([int(h*2.2*SC)-2,int(h*0.4*SC)-2,int((h*2.2+x1-x0)*SC)+2,int((h*0.4+bot-top)*SC)+2],outline=(220,0,0),width=2)
            if cimg.width>320: cimg=cimg.resize((320,int(cimg.height*320/cimg.width)))
            cimg.save(path); src=(ex,pg+1); break
    code=f"U+{ord(c):04X}"
    ws.append([f"2-{i:03d}","",code,n,"\n".join(where[c][:4])+(f"\n외 {len(where[c])-4}곳" if len(where[c])>4 else ""),f"{pdfname(src[0])} {src[1]}쪽" if src else "","",""])
    if src:
        img=XImg(path); ws.add_image(img,f"B{row}"); ws.row_dimensions[row].height=max(46,img.height*0.78)
    gl_index[code]=f"2-{i:03d}"; row+=1
fin(ws,{7})
# 3 개별
ws=sheet("3 □ 개별 확인",["번호","구분","회차","영역","문항·지문","선지","□ 앞 글자","□","□ 뒤 글자","원본 파일·쪽","입력할 글자","메모"],[8,7,20,11,10,6,26,5,26,30,14,16])
LINES={}
def find_page(ex,ctx):
    if ex in ("2009-09","2009-11","2014-11-A","2014-11-B"): return None
    if ex not in LINES: LINES[ex]=json.load(open(f'/home/claude/chk/streams/{ex}.json'))
    a=re.sub(r"\s","",ctx)[-8:]
    if len(a)<3: return None
    for l in LINES[ex]:
        if a in re.sub(r"\s","",l["t"]): return l["pg"]+1
    return None
j=0
for r in R:
    cap=r['cap']
    if cap is not None and cap.strip() in ("□","□□"): continue                       # 원래 □□(가림 표시)
    if cap and all(ord(x) in (0xF0854,0xF0855) or x.isspace() for x in cap): continue  # 『』 → 5번 시트
    if cap and any(ispua(x) for x in cap): continue                                   # 글자별 시트
    j+=1; ex,a,n=split(r['key']); pg=find_page(ex,r['L']) or find_page(ex,r['R'][::-1][::-1])
    ws.append([f"3-{j:03d}",r['kind'],exname(ex),a,n,r['num'] or "",r['L'],r['run'],r['R'],f"{pdfname(ex)}"+(f" {pg}쪽" if pg else ""),"",""])
fin(ws,{11})
# 4 지문·보기 의심
ws=sheet("4 지문·보기 의심",["번호","구분","회차","영역","지문·문항","어긋난 종류","사이트에 지금 나오는 글","원본 글자 흐름(자동 추출)","원본 파일·쪽","Claude 의견","확인·수정 입력"],[8,6,18,11,10,16,48,48,26,30,30])
k=0
for r in D:
    if re.fullmatch(r"[·…\.]+",r['원본'] or "") or re.search(r"문제지$",r['원본'] or ""): continue
    k+=1; ex,a,n=split(r['key'])
    op={"자리 밀림(다른 글꼴 낱말 등)":"원본 흐름대로 고치면 됨(Claude 자동 수정 가능)","숫자(첨자) 흩어짐":"아래 첨자로 고쳐야 함(Claude가 원본 보고 수정 가능)"}.get(r['유형'],"원본 쪽 확인 필요")
    ws.append([f"4-{k:03d}",r['구분'],exname(ex),a,n,r['유형'],r['사이트 맥락'],r['원본 맥락'],f"{pdfname(ex)} {r['쪽']}쪽",op,""])
fin(ws,{11})
# 5 『』
ws=sheet("5 『』 자동 수정",["번호","구분","회차","영역","문항·지문","□ 앞","□","□ 뒤","바뀔 글자"],[8,7,20,11,10,28,5,28,9])
m=0
for r in R:
    cap=r['cap']
    if cap and all(ord(x) in (0xF0854,0xF0855) or x.isspace() for x in cap) and cap.strip():
        m+=1; ex,a,n=split(r['key'])
        ws.append([f"5-{m:03d}",r['kind'],exname(ex),a,n,r['L'],r['run'],r['R'],"".join("『" if ord(x)==0xF0854 else "』" for x in cap if not x.isspace())])
fin(ws,set())
out="/mnt/user-data/outputs/직접확인_목록_옛한글_그림선지_지문.xlsx"
wb.save(out)
print("sheet2",len(cnt),"sheet3",j,"sheet4",k,"sheet5",m)
