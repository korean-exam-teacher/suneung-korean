# 사용: rg.py EX "찾을글" [앞뒤폭pt] [DPI] [줄수]  → loc/rg.png (찾은 글 위치 둘레를 고해상도로)
import sys, json, re, subprocess
sys.path.insert(0, "/home/claude/chk")
exec(open("/home/claude/chk/locate.py").read().split('if __name__')[0])
from PIL import Image
ex, q = sys.argv[1], sys.argv[2]
pad = float(sys.argv[3]) if len(sys.argv) > 3 else 120; dpi = int(sys.argv[4]) if len(sys.argv) > 4 else 500
nl = float(sys.argv[5]) if len(sys.argv) > 5 else 1.5
k = int(sys.argv[6]) if len(sys.argv) > 6 else 0
qn = keyN(q); hits = []
for pi, col, s, idx in pages(ex):
    for m in re.finditer(re.escape(qn).replace("\\x00", "."), s): hits.append((pi, idx[m.start():m.end()]))
print(len(hits), [(h[0] + 1, round(h[1][0]["top"])) for h in hits][:8])
pi, cs = hits[k]
x0 = min(c["x0"] for c in cs) - pad; x1 = max(c["x1"] for c in cs) + pad
h = max(c["bottom"] - c["top"] for c in cs)
t0 = min(c["top"] for c in cs) - h * nl; b0 = max(c["bottom"] for c in cs) + h * nl
sc = dpi / 72
subprocess.run(["pdftoppm", "-r", str(dpi), "-f", str(pi + 1), "-l", str(pi + 1), "-x", str(int(x0 * sc)), "-y", str(int(t0 * sc)), "-W", str(int((x1 - x0) * sc)), "-H", str(int((b0 - t0) * sc)), "-png", "-singlefile", SRC + fname(ex), "/home/claude/chk/loc/rg"], check=True, stderr=subprocess.DEVNULL)
im = Image.open("/home/claude/chk/loc/rg.png"); print(im.size)
