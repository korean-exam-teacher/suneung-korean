import sys
from PIL import Image
ims=[Image.open(f) for f in sys.argv[2:]]
W=900; ims=[i.resize((W,int(i.size[1]*W/i.size[0])),Image.LANCZOS) for i in ims]
o=Image.new('RGB',(W*len(ims)+10*(len(ims)-1),max(i.size[1] for i in ims)),'white'); x=0
for i in ims: o.paste(i,(x,0)); x+=W+10
o.save(sys.argv[1]); print(o.size)
