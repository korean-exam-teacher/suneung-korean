import json, re
R = json.load(open("resolve38_v2.json"))
OK = re.compile(r"^[ᄀ-ᇿ『』²³¹⁰-⁹ₐ-ₜ₀-₉a-zA-Z+\-=·∙′″]+$")
P, Lf = [], []
for r in R:
    c = r["cap"]
    rep = None
    if c is not None:
        cc = c.replace("​", "").strip()
        if cc and OK.match(cc.replace(" ", "")) and len(cc) <= 12 and not (r["nmatch"] >= 2 and c is None):
            # 맥락이 너무 짧으면(앞뒤 합쳐 비공백 3자 미만) 쓰지 않는다
            if len(re.sub(r"\s", "", r["L"] + r["R"])) >= 3: rep = cc
            # 이웃한 □ 묶음 사이의 공백만 맥락으로 잡힌 경우, 가운뎃소리·끝소리로 시작하는 조각은 자리가 어긋난 것이므로 버린다
            if rep and (not r["L"].strip() or not r["R"].strip()): rep = None
            if rep and "\u1160" <= rep[0] <= "\u11ff": rep = None
    if rep: r = dict(r, rep=rep); P.append(r)
    else: Lf.append(r)
json.dump(P, open("pass2.json", "w"), ensure_ascii=False, indent=0)
json.dump(Lf, open("left2.json", "w"), ensure_ascii=False, indent=0)
print(len(P), len(Lf))
for r in P: print(r["kind"], r["key"], r["num"], repr(r["L"][-8:]), "[" + r["rep"] + "]", repr(r["R"][:8]))
