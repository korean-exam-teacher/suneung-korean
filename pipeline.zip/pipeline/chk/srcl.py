import json, sys
exec(open('/home/claude/chk/movefix.py').read().split('def Nt')[0])
ex = sys.argv[1]
L = json.load(open(f'/home/claude/chk/streams/{ex}.json'))
for w in sys.argv[2:]:
    for i, l in enumerate(L):
        if w in mapd(l['t']):
            for x in L[i:i+int(__import__('os').environ.get('N','1'))]:
                t = mapd(x['t'])
                unk = [hex(ord(c)) for c in x['t'] if (0xE000 <= ord(c) <= 0xF8FF or ord(c) >= 0xF0000) and c not in CODE]
                print(f"{ex} p{x['pg']+1}:", t, ("UNK " + str(unk)) if unk else "")
            print('--')
