# -*- coding: utf-8 -*-
"""원본 흐름에서 문항별 선지를 독립적으로 다시 뽑아 사이트 선지와 비교한다.
출력: diff.json  [{key, site:[5], src:[5]|None, status}]"""
import json, re, unicodedata, difflib
s = open("/home/claude/site_v38.html", encoding="utf-8").read().split("\n")
def load(n): return json.loads([l for l in s if l.startswith(f"const {n} = ")][0][len(f"const {n} = "):].rstrip(";"))
IT = load("ITEMS"); CH = load("CHOICES")
CIR = "①②③④⑤"
HWP = json.load(open("/home/claude/hwp/hwp_paras.json"))
HK = {"2009-09": "2009-09n", "2009-11": "2009-11", "2014-11-A": "2014-11-A", "2014-11-B": "2014-11-B"}
TOK = r"(\d+|국어|언어|영|역|영역|국어\s*영|홀수형|짝수형|[AB]\s*형|\(|\)|화법과\s*작문\)?|언어와\s*매체\)?|제\s*1\s*교시)"
JUNK = re.compile(rf"\s*{TOK}(\s*{TOK})*\s*")
def is_junk(t):
    t = t.strip()
    return (not t) or bool(JUNK.fullmatch(t)) or t.startswith("이 문제지에 관한 저작권은")

def N(t):
    """비교용 정규화: 공백·따옴표·가운뎃점 차이, 원문자 기호 보호, 사용자 정의 영역 글자(PUA)와 □는 지움"""
    for k, c in enumerate(CIR): t = t.replace(c, f"#{k+1}#")
    t = unicodedata.normalize("NFKC", t)
    t = re.sub(r"[\s​]", "", t)
    for a, b in [("‘", "'"), ("’", "'"), ("“", '"'), ("”", '"'), ("`", "'"), ("ㆍ", "·"), ("・", "·"), ("‧", "·"), ("∙", "·"), ("･", "·"), ("～", "~"), ("∼", "~"), ("〜", "~"), ("―", "-"), ("—", "-"), ("–", "-"), ("－", "-")]:
        t = t.replace(a, b)
    t = re.sub(r"[-\U000f0000-\U0010ffff□]", "", t)
    return t

def build(ex):
    """(정규화 문자열, 정규화 위치 → 원문 줄 텍스트 조각) : 원문 표시 글자를 되돌려 쓰기 위해 글자 단위 대응을 만든다"""
    if ex in HK: raw = [t for _, t in HWP[HK[ex]]]
    else: raw = [l["t"] for l in json.load(open(f"/home/claude/chk/streams/{ex}.json"))]
    raw = [t for t in raw if not is_junk(t)]
    disp = ""; seps = []
    for t in raw:
        if disp and not disp.endswith(" "): disp += "\n"
        disp += t
    # 정규화 문자열과 원문 위치 대응
    norm = ""; pos = []
    for i, ch in enumerate(disp):
        n = N(ch)
        for c in n: norm += c; pos.append(i)
    return norm, pos, disp

def clean_disp(t):
    t = t.replace("\n", " ")
    t = re.sub(r"\s+", " ", t).strip()
    return t

DIFF = []
cache = {}
by_ex = {}
for it in IT: by_ex.setdefault(it["exam_id"], []).append(it)
for ex, its in by_ex.items():
    norm, pos, disp = build(ex)
    # 문항 발문 위치
    anchors = []
    for it in its:
        st = N(it["발문"]); st = re.sub(r"\[\d점\]$", "", st)
        a = st[:min(len(st), 40)]
        idx = [m.start() for m in re.finditer(r"(?<![\d#])" + re.escape(a), norm)] if a else []
        anchors.append((it, idx))
    for it, idx in anchors:
        key = f'{ex}||{it["영역"]}||{it["문항번호"]}'
        site = CH.get(key)
        rec = {"key": key, "site": site, "src": None, "status": None}
        if len(idx) == 0:
            rec["status"] = "anchor 0"; DIFF.append(rec); continue
        p = idx[0] + len(N(it["발문"]))
        # 다음 문항 발문 위치(같은 회차에서 이 위치 뒤에 오는 가장 가까운 발문)
        nxt = [i2[0] for it2, i2 in anchors if i2 and i2[0] > idx[0]]
        end = min(nxt) if nxt else len(norm)
        for stop in [r"\*확인사항", r"\[\d{1,2}~\d{1,2}\]"]:
            m = re.compile(stop).search(norm, p, end)
            if m: end = m.start()
        seg = norm[p:end]
        ms = []
        q = 0
        for k in range(1, 6):
            j = seg.find(f"#{k}#", q)
            if j < 0: break
            ms.append(j); q = j + 3
        if len(ms) < 5:
            rec["status"] = f"src markers {len(ms)}"; DIFF.append(rec); continue
        src = []
        for k in range(5):
            a = p + ms[k] + 3; b = p + (ms[k+1] if k < 4 else len(seg))
            if a >= b: src.append(""); continue
            src.append(clean_disp(disp[pos[a]:pos[b-1]+1]))
        rec["src"] = src
        if site is None: rec["status"] = "site none"
        else:
            same = all(N(x) == N(y) for x, y in zip(site, src))
            rec["status"] = "same" if same else "diff"
        DIFF.append(rec)
json.dump(DIFF, open("/home/claude/chk/diff37.json", "w"), ensure_ascii=False, indent=0)
from collections import Counter
print(Counter(r["status"] for r in DIFF))
