import json,sys,re
s=open('/home/claude/site_v36.html',encoding='utf-8').read().split("\n")
IT=json.loads([l for l in s if l.startswith("const ITEMS = ")][0][14:].rstrip(";"))
CH=json.loads([l for l in s if l.startswith("const CHOICES = ")][0][16:].rstrip(";"))
D={r['key']:r for r in json.load(open('/home/claude/chk/diff.json'))}
FB=json.load(open('/home/claude/chk/fix_boiler.json'))
for key in sys.argv[1:]:
    ex,a,n=key.split("||"); it=[i for i in IT if i['exam_id']==ex and i['영역']==a and i['문항번호']==int(n)][0]
    print("=====",key,"| 정답",it['정답'],"| 발문:",it['발문'])
    print("  보기:",repr((it.get('보기') or '')[-220:]))
    site=FB.get(key,CH.get(key)); src=D.get(key,{}).get('src')
    for k in range(5):
        print(f"  site{k+1}:",(site[k] if site else None))
        if src: print(f"  src {k+1}:",src[k][:200])
