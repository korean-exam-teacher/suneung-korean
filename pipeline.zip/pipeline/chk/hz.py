import json, os, subprocess, sys
from PIL import Image, ImageDraw, ImageFont
sys.path.insert(0,'/home/claude/chk')
from streams import fname, SRC
from openpyxl import load_workbook
P=json.load(open('puapos.json')); R=json.load(open('resolve.json'))
wb=load_workbook("/mnt/user-data/outputs/직접확인_목록_옛한글_그림선지_지문.xlsx"); ws=wb["2 옛한글·기호(글자별)"]
rows=[(r[0],r[2],r[6]) for r in ws.iter_rows(min_row=2,values_only=True)]
todo=[(n,c) for n,c,v in rows if not v]
DPI=400; SC=DPI/72
def crop(ex,pg,box):
    base=f"/tmp/claude-0/h_{ex}_{pg}_{box[0]}_{box[1]}"
    x0,y0,w,h=box
    subprocess.run(["pdftoppm","-r",str(DPI),"-f",str(pg+1),"-l",str(pg+1),"-x",str(x0),"-y",str(y0),"-W",str(w),"-H",str(h),"-gray","-png","-singlefile",SRC+fname(ex),base],check=True,stderr=subprocess.DEVNULL)
    return Image.open(base+".png")
ctx={}
for r in R:
    if r['cap']:
        for ch in r['cap']:
            ctx.setdefault(f"U+{ord(ch):04X}",[]).append((r['L'][-8:],r['R'][:8],r['key']))
tiles=[]; info={}
for n,code in todo:
    ch=chr(int(code[2:],16)); loc=None
    for L,Rr,key in ctx.get(code,[]):
        ex=key.split("||")[0]
        if ch in P.get(ex,{}): loc=(ex,P[ex][ch][0]); info[n]=(code,L,Rr,key); break
    if not loc: tiles.append((n,None)); continue
    ex,(pg,x0,top,x1,bot)=loc; h=bot-top
    box=(int((x0-h*1.3)*SC),int((top-h*0.25)*SC),int((x1-x0+h*2.6)*SC),int(h*1.5*SC))
    g=crop(ex,pg,box).convert("RGB"); sc=140/g.height; g=g.resize((max(1,int(g.width*sc)),140))
    from PIL import ImageDraw as _D
    dd=_D.Draw(g); gx0=int(h*1.3*SC*sc); gx1=int((h*1.3+x1-x0)*SC*sc)
    dd.rectangle([gx0-3,2,gx1+3,137],outline=(230,0,0),width=3)
    tiles.append((n,g))
os.makedirs('/home/claude/chk/hz',exist_ok=True)
fnt=ImageFont.load_default()
for b in range(0,len(tiles),16):
    part=tiles[b:b+16]
    o=Image.new("RGB",(4*330,4*165),255); d=ImageDraw.Draw(o)
    for i,(n,g) in enumerate(part):
        x=(i%4)*330; y=(i//4)*165
        d.text((x+4,y+2),n,fill=(0,0,0),font=fnt)
        if g: o.paste(g.crop((0,0,min(g.width,320),140)),(x+4,y+16))
    o.save(f'/home/claude/chk/hz/m{b//16:02d}.png')
json.dump({"todo":todo,"info":info},open('/home/claude/chk/hz/todo.json','w'),ensure_ascii=False)
print(len(tiles))
