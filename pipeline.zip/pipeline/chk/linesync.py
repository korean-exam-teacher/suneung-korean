# -*- coding: utf-8 -*-
"""2017학년도 이전 문학 지문: 사이트 글자는 그대로 두고, 원본 줄 구조(rebuild.build 결과)의 줄 바꿈·연 나눔·띄어쓰기만 옮겨 온다.
원본 PDF에 글자 코드가 없는 옛한글(사이트에서 직접 판독해 채운 글자)도 지워지지 않는다."""
import json, sys, difflib, unicodedata, re
sys.argv_saved = sys.argv; sys.argv = ["x", "__none__"]
exec(open('/home/claude/chk/rebuild.py').read().split('if __name__')[0])
sys.argv = sys.argv_saved
KEEPWJ[0] = True
def nch(c):
    c = unicodedata.normalize("NFKC", c)
    return {"‘": "'", "’": "'", "“": '"', "”": '"', "ㆍ": "·", "․": "·", "∙": "·", "～": "~", "∼": "~", "―": "-", "—": "-", "–": "-", "＋": "+"}.get(c, c)
def chars(t):
    out = []   # (char, index)
    for i, c in enumerate(t):
        if not c.isspace() and c != "\u2060": out.append((c, i))
    return out
def sync(site, R, wj_only=False):
    note = ""
    if "\n\n※" in site: site, note = site.split("\n\n※", 1); note = "\n\n※" + note
    S = chars(site); Rc = chars(R)
    # R 쪽 각 글자 뒤 공백
    rws = []
    for k, (c, i) in enumerate(Rc):
        j = Rc[k + 1][1] if k + 1 < len(Rc) else len(R)
        w = R[i + 1:j]
        rws.append("\n\n" if w.count("\n") >= 2 else "\n" if "\n" in w else "WJ" if "\u2060" in w else " " if w else "")
    sm = difflib.SequenceMatcher(None, [nch(c) for c, _ in S], [nch(c) for c, _ in Rc], autojunk=False)
    amap = {}
    for m in sm.get_matching_blocks():
        for q in range(m.size): amap[m.a + q] = m.b + q
    matched = len(amap) / max(1, len(S))
    marks = [(m.start(), m.end() - 1) for m in re.finditer(r"\[[A-Z가-하]\]", site)]
    out = ""; changed = 0
    for k, (c, i) in enumerate(S):
        out += c
        if k + 1 >= len(S): break
        orig_ws = site[i + 1:S[k + 1][1]]
        near_marker = any(M0 <= i <= M1 or M0 <= S[k + 1][1] <= M1 for M0, M1 in marks)
        if k in amap and k + 1 in amap and amap[k + 1] == amap[k] + 1 and not near_marker:
            w = rws[amap[k]]
            ow = "\n\n" if orig_ws.count("\n") >= 2 else "\n" if "\n" in orig_ws else " " if orig_ws else ""
            if w == "WJ" and re.search(r"[,.?!’”)\]>:]", c):
                out += orig_ws; continue
            if w == "WJ":                       # 원본에서 낱말 중간에서 줄이 바뀐 자리: 붙여 씀
                if ow != "": changed += 1
                continue
            if wj_only or ("\n" not in w and "\n" not in ow):
                out += orig_ws; continue          # 줄 안 띄어쓰기는 지금 사이트 것을 그대로
            if w != ow: changed += 1
            out += w
        else:
            out += orig_ws
    return out + note, matched, changed
if __name__ == "__main__":
    A = json.load(open('/home/claude/chk/v39B.json'))
    RBK = {k for k, v in json.load(open('/home/claude/chk/rebuild.json')).items() if v['ok'] and int(k[:4]) >= 2018}
    keys = [k for k in A['PAS'] if k not in RBK] if len(sys.argv) < 2 else sys.argv[1:]
    res = {}; from collections import Counter; st = Counter()
    for k in keys:
        site = A['PAS'][k]; lit = k.split('||')[1] == '문학'
        try: R, s = build(k.split('||')[0], site)
        except Exception as e: R, s = None, "err"
        if R is None: st[s] += 1; continue
        new, matched, changed = sync(site, R, wj_only=not lit)
        if matched < 0.97: st["lowmatch"] += 1; res[k] = {"ok": False, "matched": matched, "new": new}; continue
        st["ok" if changed else "same"] += 1
        res[k] = {"ok": True, "lit": lit, "matched": round(matched, 4), "changed": changed, "new": new}
    json.dump(res, open('/home/claude/chk/linesync.json', 'w'), ensure_ascii=False, indent=0)
    print(st)
