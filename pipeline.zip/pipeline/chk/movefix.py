# -*- coding: utf-8 -*-
"""지문·<보기>를 원본(streams2: 글자 좌표를 세로 겹침으로 다시 묶은 줄)과 낱말 단위로 맞춘다.
 (가) 자리가 밀린 낱말(묶음)을 원본 자리로 옮긴다  (나) 같은 낱말 안의 □를 원본 글자(판독표 적용)로 채운다
입력: v39A.json  출력: movefix.json {kind||key: new_text}, movefix_log.json"""
import json, re, unicodedata, difflib, sys
sys.path.insert(0, "/home/claude/chk")
from pua_map import READ, compose
from openpyxl import load_workbook
from streams import fname
ws = load_workbook("/home/claude/chk/직접확인_목록_원본.xlsx")["2 옛한글·기호(글자별)"]
CODE = {}
for r in ws.iter_rows(min_row=2, values_only=True):
    num, code, typed = r[0].split("-")[1], r[2], r[6]
    if typed: CODE[chr(int(code[2:], 16))] = typed
    elif num in READ: CODE[chr(int(code[2:], 16))] = compose(READ[num])
CODE.update({"\U000f0854": "『", "\U000f0855": "』", "ꡔ": "『", "ꡕ": "』", "​": ""})
import sys as _s; _s.path.insert(0, "/home/claude/chk"); from pua_map import EXTRA as _EX; CODE.update(_EX)
def mapd(t): return "".join(CODE.get(c, c) for c in t)
CIR = "①②③④⑤"
def Nt(t):
    for k, c in enumerate(CIR): t = t.replace(c, f"#{k+1}#")
    t = unicodedata.normalize("NFKC", t)
    for a, b in [("‘", "'"), ("’", "'"), ("“", '"'), ("”", '"'), ("`", "'"), ("ㆍ", "·"), ("・", "·"), ("‧", "·"), ("∙", "·"), ("･", "·"), ("․", "·"), ("～", "~"), ("∼", "~"), ("〜", "~"), ("―", "-"), ("—", "-"), ("–", "-"), ("－", "-"), ("＋", "+")]:
        t = t.replace(a, b)
    return re.sub(r"[\s​□『』「」｢｣<>〈〉-\U000f0000-\U0010ffff]", "", t)
TOK = r"(\d+|국어|언어|영|역|영역|국어\s*영|홀수형|짝수형|[AB]\s*형|\(|\)|화법과\s*작문\)?|언어와\s*매체\)?|제\s*1\s*교시)"
JUNK = re.compile(rf"\s*{TOK}(\s*{TOK})*\s*")
def is_junk(t):
    t = t.strip(); return (not t) or bool(JUNK.fullmatch(t)) or t.startswith("이 문제지에 관한 저작권은")
SRCD = {}
def src(ex):
    if ex not in SRCD:
        try: L = json.load(open(f"/home/claude/chk/streams2/{ex}.json"))
        except Exception: SRCD[ex] = None; return None
        toks = []   # (표시 토큰, 줄끝 여부)
        for l in L:
            if is_junk(l["t"]): continue
            ws_ = mapd(l["t"]).split()
            for i, w in enumerate(ws_): toks.append([w, i == len(ws_) - 1])
        SRCD[ex] = toks
    return SRCD[ex]
def site_tok(t):
    ms = list(re.finditer(r"\S+", t)); toks = [m.group() for m in ms]
    seps = [t[ms[i].end():(ms[i+1].start() if i + 1 < len(ms) else len(t))] for i in range(len(ms))]
    head = t[:ms[0].start()] if ms else t
    return head, toks, seps
def join(head, toks, seps): return head + "".join(a + b for a, b in zip(toks, seps))
def region(stoks, nsrc):
    """사이트 토큰 목록이 원본 토큰 목록의 어디쯤인지: 여러 군데 4토큰 조각을 찾아 범위를 정한다"""
    n = len(stoks); hits = []
    ns = [Nt(x) for x in stoks]
    idx = {}
    for j in range(len(nsrc) - 3):
        idx.setdefault(tuple(nsrc[j:j+4]), []).append(j)
    for i in range(0, max(1, n - 3)):
        k = tuple(ns[i:i+4])
        if len(k) == 4 and all(k) and 1 <= len(idx.get(k, [])) <= 3:
            for j in idx[k]: hits.append((i, j))
    if len(hits) < 2: return None
    from collections import Counter
    bins = Counter((j - i) // 60 for i, j in hits)
    b0 = bins.most_common(1)[0][0]
    good = [(i, j) for i, j in hits if abs((j - i) // 60 - b0) <= 1]
    if len(good) < max(2, min(10, n // 20)): return None
    j0 = min(j - i for i, j in good); j1 = max(j - i for i, j in good) + n
    return max(0, j0 - 3), min(len(nsrc), j1 + 3)
def fill_box(stok, otok):
    """사이트 낱말의 □ 묶음을 원본 낱말의 글자로 채움(나머지 글자가 똑같을 때만)"""
    if "□" not in stok: return None
    parts = re.split(r"(□+)", stok)
    rx = "".join("(.+?)" if p.startswith("□") else re.escape(p) for p in parts if p)
    m = re.fullmatch(rx, otok)
    if not m: return None
    out = ""; g = 1
    for p in parts:
        if not p: continue
        if p.startswith("□"):
            c = m.group(g); g += 1
            if any(0xE000 <= ord(x) <= 0xF8FF or ord(x) >= 0xF0000 or x == "□" for x in c): return None
            out += c
        else: out += p
    return out
def process(t, ex, log, unit):
    S = src(ex)
    if not S: return t, "nosrc"
    nsrc_all = [Nt(w) for w, _ in S]
    head, toks, seps = site_tok(t)
    if len(toks) < 6: return t, "short"
    rg = region(toks, nsrc_all)
    if not rg: return t, "noanchor"
    a, b = rg; O = S[a:b]; no = nsrc_all[a:b]
    moved = 0
    def score(ns_):
        sm_ = difflib.SequenceMatcher(None, ns_, no, autojunk=False)
        return sum(m.size for m in sm_.get_matching_blocks()), sm_
    def okblock(bt):
        txt = " ".join(bt)
        if any(re.fullmatch(r"[\[(（<〈]?[A-Z가-하ㄱ-ㅎ][\])）>〉]?|\[[^\]]{1,8}\]|<[^>]*>|[ⓐ-ⓩⒶ-Ⓩ㉠-㉭㉮-㉻①-⑳]", x) for x in bt): return False
        return bool(re.search(r"[가-힣A-Za-z]", txt))
    def pref(bt):
        txt = " ".join(bt)
        return (2 if "*" in txt else 0) + (1 if re.search(r":$|□|『|○○|△△|◇◇", txt) else 0)
    for it in range(80):
        ns = [Nt(x) for x in toks]
        base, sm = score(ns)
        ops = [o for o in sm.get_opcodes() if o[0] != "equal"]
        if not ops: break
        cand_src = set(); cand_tgt = set()
        for tg, i1, i2, j1, j2 in ops:
            for p in range(max(0, i1 - 3), min(len(toks), i2 + 3)): cand_src.add(p)
            for p in range(max(0, i1 - 3), min(len(toks), i2 + 4)): cand_tgt.add(p)
        best = None
        for s0 in sorted(cand_src):
            for L in (1, 2, 3, 4):
                if s0 + L > len(toks): break
                bt = toks[s0:s0 + L]
                if not okblock(bt): continue
                rest = ns[:s0] + ns[s0 + L:]
                for tgt in sorted(cand_tgt):
                    t2 = tgt if tgt <= s0 else tgt - L
                    if t2 == s0 or t2 < 0 or t2 > len(rest): continue
                    if abs(tgt - s0) > 40: continue
                    sc, _ = score(rest[:t2] + ns[s0:s0 + L] + rest[t2:])
                    gain = sc - base
                    if gain <= 0: continue
                    key = (gain, -L, pref(bt), -abs(tgt - s0))
                    if best is None or key > best[0]: best = (key, s0, L, t2)
        if not best: break
        _, s0, L, t2 = best
        blk_t = toks[s0:s0 + L]
        before = join("", toks[max(0, s0-4):s0+L+4], seps[max(0, s0-4):s0+L+4])
        last_sep = seps[s0 + L - 1]
        del toks[s0:s0 + L]; del seps[s0:s0 + L]
        if s0 > 0 and "\n" in last_sep and "\n" not in seps[s0 - 1]: seps[s0 - 1] = last_sep
        # 원본에서 이 묶음이 줄 끝인지
        ns2 = [Nt(x) for x in toks[:t2]] + [Nt(x) for x in blk_t] + [Nt(x) for x in toks[t2:]]
        _, sm2 = score(ns2); eol = False; nxt_same = True
        for m in sm2.get_matching_blocks():
            if m.a <= t2 + L - 1 < m.a + m.size:
                jj = m.b + (t2 + L - 1 - m.a); eol = O[jj][1]
        ins_s = [" "] * L
        if t2 > 0 and "\n" in seps[t2 - 1] and eol:
            ins_s[-1] = seps[t2 - 1]; seps[t2 - 1] = " "
        toks[t2:t2] = blk_t; seps[t2:t2] = ins_s
        after = join("", toks[max(0, t2-4):t2+L+4], seps[max(0, t2-4):t2+L+4])
        log.append({"unit": unit, "moved": " ".join(blk_t), "before": before.replace("\n", "⏎"), "after": after.replace("\n", "⏎")})
        moved += 1
    # 외톨이 줄 합치기: '*' 낱말만 있는 줄인데 원본에서는 다음 낱말과 같은 줄이면 줄바꿈을 없앤다
    ns = [Nt(x) for x in toks]; _, sm = score(ns); amap = {}
    for m in sm.get_matching_blocks():
        for q in range(m.size): amap[m.a + q] = m.b + q
    starts = [0] + [i + 1 for i in range(len(toks) - 1) if "\n" in seps[i]]
    for st in starts:
        en = st
        while en < len(toks) - 1 and "\n" not in seps[en]: en += 1
        line = toks[st:en + 1]
        if len(line) <= 2 and any("*" in x for x in line) and en + 1 < len(toks) and seps[en].count("\n") == 1:
            if en in amap and en + 1 in amap and amap[en + 1] == amap[en] + 1 and not O[amap[en]][1]:
                log.append({"unit": unit, "join": " ".join(line) + " ⏎ " + toks[en + 1]})
                seps[en] = " "; moved += 1
    # 옛한글 낱말 안의 군 띄어쓰기: 원본에서는 한 낱말인데 사이트에서 갈라진 경우 붙인다
    ns = [Nt(x) for x in toks]; _, sm = score(ns)
    for tg, i1, i2, j1, j2 in reversed(sm.get_opcodes()):
        if tg != "replace" or i2 - i1 < 2: continue
        if "".join(ns[i1:i2]) != "".join(no[j1:j2]) or j2 - j1 >= i2 - i1: continue
        seg = "".join(toks[i1:i2])
        if not re.search(r"[\u1100-\u11ff]", seg): continue
        if any("\n" in x for x in seps[i1:i2 - 1]): continue
        # 원본 낱말 경계대로 다시 나눔
        new = []; p = 0; flat = "".join(toks[i1:i2])
        for j in range(j1, j2):
            L = len(Nt(O[j][0])); q = p; cnt = 0
            while q < len(flat) and cnt < L:
                cnt += len(Nt(flat[q])); q += 1
            new.append(flat[p:q]); p = q
        if p != len(flat) or any(not x for x in new): continue
        log.append({"unit": unit, "space": " ".join(toks[i1:i2]) + " → " + " ".join(new)})
        last = seps[i2 - 1]
        toks[i1:i2] = new; seps[i1:i2] = [" "] * (len(new) - 1) + [last]
    # □ 채우기
    ns = [Nt(x) for x in toks]
    sm = difflib.SequenceMatcher(None, ns, no, autojunk=False); filled = 0
    for tg, i1, i2, j1, j2 in sm.get_opcodes():
        if tg not in ("equal", "replace") or (i2 - i1) != (j2 - j1): continue
        for k in range(i2 - i1):
            st, ot = toks[i1 + k], O[j1 + k][0]
            f = fill_box(st, ot)
            if f and f != st:
                log.append({"unit": unit, "fill": st + " → " + f}); toks[i1 + k] = f; filled += 1
    return join(head, toks, seps), f"moved {moved} filled {filled}"
if __name__ == "__main__":
    A = json.load(open("/home/claude/chk/v39A.json"))
    out = {}; log = []; from collections import Counter; st = Counter()
    import os
    if os.environ.get("BOGI"):
        A = json.load(open("/home/claude/chk/v39B.json"))
        units = [("보기", k, v) for k, v in A["BOGI"].items() if int(k[:4]) >= 2018]
    else:
        units = [("지문", k, v) for k, v in A["PAS"].items() if int(k[:4]) >= 2018]
    only = sys.argv[1:] 
    for kind, k, v in units:
        if only and k not in only: continue
        ex = k.split("||")[0]
        nv, s = process(v, ex, log, f"{kind}||{k}")
        st[s.split()[0] if not s.startswith("moved") else ("changed" if nv != v else "same")] += 1
        if nv != v: out[f"{kind}||{k}"] = nv
    sfx = "_bogi" if os.environ.get("BOGI") else ""
    json.dump(out, open(f"/home/claude/chk/movefix{sfx}.json", "w"), ensure_ascii=False)
    json.dump(log, open(f"/home/claude/chk/movefix{sfx}_log.json", "w"), ensure_ascii=False, indent=0)
    print(st, "moves", sum(1 for l in log if "moved" in l), "fills", sum(1 for l in log if "fill" in l))
