# -*- coding: utf-8 -*-
"""streams.py의 개량판: 줄 묶기를 '세로 겹침' 기준으로 하여, 글꼴·크기가 다른 낱말(각주 표시 * 단어, 기울임 등)이
줄 앞뒤로 밀려나지 않게 한다. 출력: streams2/<exam>.json"""
import pdfplumber, json, sys, os
from concurrent.futures import ProcessPoolExecutor
sys.path.insert(0, "/home/claude/chk")
from streams import fname, SRC
OUT = "/home/claude/chk/streams2/"
def lines_of(chars):
    rows = []
    for c in sorted(chars, key=lambda c: -(c["bottom"] - c["top"])):
        h = c["bottom"] - c["top"]; best = None; bo = 0
        for r in rows:
            ov = min(r["b"], c["bottom"]) - max(r["t"], c["top"])
            if ov > bo: bo, best = ov, r
        if best is not None and bo >= 0.45 * min(h, best["b"] - best["t"]):
            best["cs"].append(c)
        else: rows.append({"t": c["top"], "b": c["bottom"], "cs": [c]})
    rows.sort(key=lambda r: r["t"])
    out = []
    for r in rows:
        cs = sorted(r["cs"], key=lambda c: c["x0"]); t = ""; ts = ""; prev = None
        for c in cs:
            if c["text"] in (" ", "\u200b"):
                if c["text"] == " " and ts and not ts.endswith(" "): ts += " "
                continue
            if prev is not None:
                gap = c["x0"] - prev["x1"]; sz = max(c["size"], prev["size"])
                if gap > sz * 0.25: t += " "
                if gap > sz * 1.2 and not ts.endswith(" "): ts += " "
            t += c["text"]; ts += c["text"]; prev = c
        if prev is None: continue
        ink = [c for c in cs if c["text"] not in (" ", "\u200b")]
        te = any(c["text"] == " " and c["x0"] >= ink[-1]["x1"] - 1 for c in cs)   # 줄 끝에 공백 글자가 있음 = 낱말 경계
        out.append({"top": round(r["t"], 1), "bot": round(r["b"], 1), "x0": round(ink[0]["x0"], 1), "x1": round(max(c["x1"] for c in ink), 1), "t": t, "ts": ts.strip(), "te": te})
    return out
def run(ex):
    res = []
    with pdfplumber.open(SRC + fname(ex)) as pdf:
        for pi, pg in enumerate(pdf.pages):
            W = pg.width; ch = [c for c in pg.dedupe_chars().chars if c["text"].strip()]
            if not ch: continue
            cov = [0] * int(W + 1)
            for c in ch:
                for x in range(int(c["x0"]), min(int(c["x1"]) + 1, len(cov))): cov[x] += 1
            lo, hi = int(W * 0.35), int(W * 0.65)
            g = min(range(lo, hi), key=lambda x: (cov[x], abs(x - W / 2)))
            allc = [c for c in pg.dedupe_chars().chars if c["text"].strip() or c["text"] == " "]
            spaces = [c for c in pg.chars if c["text"] == " "]
            for col, part in enumerate([[c for c in allc if (c["x0"] + c["x1"]) / 2 < g], [c for c in allc if (c["x0"] + c["x1"]) / 2 >= g]]):
                for l in lines_of(part):
                    # 줄 끝 공백: 단 경계 너머로 넘어간 공백 글자까지 쪽 전체에서 찾는다
                    l["te"] = l["te"] or any(abs((c["top"] + c["bottom"]) / 2 - (l["top"] + l["bot"]) / 2) < 3 and l["x1"] - 1 <= c["x0"] <= l["x1"] + 12 for c in spaces)
                    res.append({"pg": pi, "col": col, **l})
    json.dump(res, open(OUT + ex + ".json", "w"), ensure_ascii=False)
    return ex, len(res)
if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    exs = sys.argv[1:] or sorted(f[:-5] for f in os.listdir("/home/claude/chk/streams"))
    with ProcessPoolExecutor(6) as P:
        for r in P.map(run, exs): print(*r, flush=True)
