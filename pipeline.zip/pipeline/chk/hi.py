import sys, json, re
sys.path.insert(0, "/home/claude/chk")
src = open("/home/claude/chk/locate.py").read().split('if __name__')[0].replace("DPI = 320", "DPI = 640").replace("/tmp/claude-0/L3_", "/tmp/claude-0/L6_")
exec(src)
exec(open("/home/claude/chk/locate2.py").read().split("LEFT = json.load")[0].split('exec(open("/home/claude/chk/locate.py")')[1].split("\n", 1)[1])
from PIL import Image, ImageDraw, ImageFont
LEFT = json.load(open("/home/claude/chk/left2.json"))
F = ImageFont.truetype("/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc", 26)
out = []
for a in sys.argv[1:]:
    i = int(a); e = LEFT[i]; ex = e["key"].split("||")[0]
    h = locate(ex, e["L"], e["R"]) or locate(ex, e["L"], e["R"], 1) or locate(ex, e["L"], e["R"], 2)
    if not h: print("nf", i); continue
    pi, cs = h[0]
    im = crop(ex, pi, cs, pad=0.3)
    if im.size[0] > 1500: im = im.crop((0, 0, 1500, im.size[1]))
    b = Image.new("RGB", (1500, im.size[1] + 36), "white"); ImageDraw.Draw(b).text((4, 2), f"#{i} …{e['L'][-12:]}[{e['run']}]{e['R'][:12]}…".replace("\n","⏎"), fill=(200,0,0), font=F); b.paste(im, (0, 34)); out.append(b)
o = Image.new("RGB", (1500, sum(b.size[1] + 8 for b in out)), (220, 220, 220)); y = 0
for b in out: o.paste(b, (0, y)); y += b.size[1] + 8
o.save("/home/claude/chk/loc/hi.png")
