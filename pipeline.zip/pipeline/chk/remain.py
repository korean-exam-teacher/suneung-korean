import json, re, sys
A = json.load(open('/home/claude/chk/v39B.json'))
LEG = re.compile(r"□{2,3}(?=\s?(연구소|신문|고등학교|고 |고\b|대학교|농업|의학회|생태|전시관|정책|공사|구 보건소|길|시의|시 |지방|박물관|문화원|해양|뉴스|님|선생님|산림| 학교| 사이클| 지역|입니다|경찰서|농장| 생물|\.08|치유|의 노래|의 저서| 박사|의 가요))|빈칸 □|로 표시됩니")
units = [("지문", k, None, v) for k, v in A['PAS'].items()] + [("보기", k, None, v) for k, v in A['BOGI'].items()] + [("선지", k, i+1, c) for k, v in A['CHO'].items() for i, c in enumerate(v)]
out = []
for kind, k, n, t in units:
    for m in re.finditer(r"□+", t):
        ctx = t[max(0, m.start()-14):m.end()+14]
        if LEG.search(t[max(0,m.start()-8):m.end()+12]) or '로 표시됩니' in t[m.end():m.end()+8] or '빈칸 □' in t[m.start()-3:m.end()]: continue
        out.append((kind, k, n, m.start(), m.group(), ctx.replace("\n", "⏎")))
print(len(out))
for o in out: print(o[0], o[1], o[2] or '', '|', o[5])
