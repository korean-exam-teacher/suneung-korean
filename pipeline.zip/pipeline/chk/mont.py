import json, sys, os
from PIL import Image, ImageDraw, ImageFont
L = json.load(open("left2.json")); LOC = json.load(open("loc/loc.json"))
F = ImageFont.truetype("/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc", 22)
ids = [r["i"] for r in LOC if os.path.exists(f"loc/{r['i']:03d}.png") and "로 표시됩니" not in L[r["i"]]["R"]]
per = int(sys.argv[1]) if len(sys.argv) > 1 else 10
os.makedirs("loc/m", exist_ok=True)
for g in range(0, len(ids), per):
    blocks = []
    for i in ids[g:g+per]:
        e = L[i]; im = Image.open(f"loc/{i:03d}.png")
        if im.size[0] > 1100: im = im.resize((1100, int(im.size[1] * 1100 / im.size[0])))
        lab = f"#{i} {e['key']} {e['kind']}{e['num'] or ''}  …{e['L'][-10:]}[{e['run']}]{e['R'][:10]}…".replace("\n", "⏎")
        b = Image.new("RGB", (1150, im.size[1] + 36), "white"); d = ImageDraw.Draw(b)
        d.text((4, 2), lab, fill=(200, 0, 0), font=F); b.paste(im, (4, 34)); blocks.append(b)
    H = sum(b.size[1] for b in blocks) + 8 * len(blocks)
    o = Image.new("RGB", (1150, H), (230, 230, 230)); y = 0
    for b in blocks: o.paste(b, (0, y)); y += b.size[1] + 8
    o.save(f"loc/m/m{g//per:02d}.png")
print(len(ids))
