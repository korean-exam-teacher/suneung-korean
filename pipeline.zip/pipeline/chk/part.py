import sys
from PIL import Image
im = Image.open(sys.argv[1]); W, H = im.size
y0, y1 = float(sys.argv[2]), float(sys.argv[3]); x0 = float(sys.argv[4]) if len(sys.argv) > 4 else 0; x1 = float(sys.argv[5]) if len(sys.argv) > 5 else 1
c = im.crop((int(W * x0), int(H * y0), int(W * x1), int(H * y1)))
c.save("/home/claude/chk/loc/part.png"); print(W, H, c.size)
