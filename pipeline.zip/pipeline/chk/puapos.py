import pdfplumber, json, sys
from concurrent.futures import ProcessPoolExecutor
sys.path.insert(0,'/home/claude/chk')
from streams import fname, SRC
def ispua(c): o=ord(c); return 0xE000<=o<=0xF8FF or o>=0xF0000
def run(ex):
    res={}
    with pdfplumber.open(SRC+fname(ex)) as pdf:
        for pi,pg in enumerate(pdf.pages):
            for ch in pg.chars:
                t=ch["text"]
                if len(t)==1 and ispua(t):
                    res.setdefault(t,[]).append((pi,round(ch["x0"],1),round(ch["top"],1),round(ch["x1"],1),round(ch["bottom"],1)))
    return ex,res
if __name__=="__main__":
    exs=sys.argv[1:]; out={}
    with ProcessPoolExecutor(2) as P:
        for ex,r in P.map(run,exs): out[ex]=r; print(ex,len(r),flush=True)
    json.dump(out,open('/home/claude/chk/puapos.json','w'),ensure_ascii=False)
