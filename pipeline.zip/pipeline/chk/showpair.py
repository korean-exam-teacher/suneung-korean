import json, sys
k = sys.argv[1]; n = int(sys.argv[2]) if len(sys.argv) > 2 else 900
sys.argv = ["x", "__none__"]
exec(open('/home/claude/chk/rebuild.py').read().split('if __name__')[0])
A = json.load(open('/home/claude/chk/v39B.json')); v = A['PAS'][k]
R, s = build(k.split('||')[0], v)
print('---- SITE'); print(v[:n]); print('---- SOURCE'); print(R[:n])
