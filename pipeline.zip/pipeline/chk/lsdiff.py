import json, sys, difflib, re
A = json.load(open('/home/claude/chk/v39B.json')); r = json.load(open('/home/claude/chk/linesync.json'))
for k in sys.argv[1:]:
    a = A['PAS'][k]; b = r[k]['new']
    ta = re.split(r"(\s+)", a); tb = re.split(r"(\s+)", b)
    # 공백 아닌 조각 순서는 같으므로 차례로 맞춤
    wa = [x for x in ta if x and not x.isspace()]; print('=====', k)
    sa = re.sub(r"\S+", "W", a); sb = re.sub(r"\S+", "W", b)
    # 줄바꿈 바뀐 자리 보여주기
    ia = [m.start() for m in re.finditer(r"\S+", a)]; ib = [m.start() for m in re.finditer(r"\S+", b)]
    na = [m.group() for m in re.finditer(r"\S+", a)]; nb = [m.group() for m in re.finditer(r"\S+", b)]
    sm = difflib.SequenceMatcher(None, na, nb, autojunk=False)
    shown = 0
    # 줄 단위 비교
    la = a.split("\n"); lb = b.split("\n")
    for tg, i1, i2, j1, j2 in difflib.SequenceMatcher(None, la, lb, autojunk=False).get_opcodes():
        if tg == 'equal': continue
        print('  -', ' ⏎ '.join(la[i1:i2])[:200]); print('  +', ' ⏎ '.join(lb[j1:j2])[:200]); shown += 1
        if shown > 6: break
