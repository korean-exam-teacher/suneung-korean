# -*- coding: utf-8 -*-
"""사이트 선지(CHOICES)를 원본 문제지 글자 흐름과 대조해 어긋난 문항을 찾는다.
판정: 선지 k의 글자(공백 제거)가 원본 흐름에서 'k번 기호 + 선지 글자 + (k+1번 기호)'로 이어져 나오는지."""
import json, re, unicodedata
s = open("/home/claude/site_v36.html", encoding="utf-8").read().split("\n")
def load(n): return json.loads([l for l in s if l.startswith(f"const {n} = ")][0][len(f"const {n} = "):].rstrip(";"))
IT = load("ITEMS"); CH = load("CHOICES")
CIR = "①②③④⑤"
HWP = json.load(open("/home/claude/hwp/hwp_paras.json"))
HK = {"2009-09": "2009-09n", "2009-11": "2009-11", "2014-11-A": "2014-11-A", "2014-11-B": "2014-11-B"}
def norm(t):
    t = unicodedata.normalize("NFKC", t)
    t = re.sub(r"[\s​　]", "", t)
    t = t.replace("‘", "'").replace("’", "'").replace("“", '"').replace("”", '"').replace("`", "'")
    t = t.replace("ㆍ", "·").replace("・", "·").replace("‧", "·").replace("∙", "·").replace("･", "·")
    t = t.replace("～", "~").replace("∼", "~").replace("〜", "~")
    return t
# NFKC가 ①을 1로 바꾸므로 기호를 먼저 다른 표시로 바꿔 둔다
MK = {c: f"#{k+1}#" for k, c in enumerate(CIR)}
def norm2(t):
    for c, m in MK.items(): t = t.replace(c, m)
    return norm(t)
STREAM = {}
def stream(ex):
    if ex in STREAM: return STREAM[ex]
    if ex in HK: txt = "".join(t for _, t in HWP[HK[ex]])
    else: txt = "".join(l["t"] for l in json.load(open(f"/home/claude/chk/streams/{ex}.json")))
    STREAM[ex] = norm2(txt); return STREAM[ex]
res = []
for it in IT:
    ex = it["exam_id"]; key = f'{ex}||{it["영역"]}||{it["문항번호"]}'
    ch = CH.get(key)
    if ch is None: res.append({"key": key, "kind": "no_choices"}); continue
    S = stream(ex); bad = []
    for k, c in enumerate(ch):
        n = norm2(c)
        if not n: bad.append((k+1, "empty")); continue
        if f"#{k+1}#" in n or any(f"#{j}#" in n for j in range(1, 6)): bad.append((k+1, "marker inside"))
        seg = f"#{k+1}#" + n
        if seg not in S: bad.append((k+1, "not found")); continue
        if k < 4 and seg + f"#{k+2}#" not in S:
            # 다음 기호가 바로 오지 않으면, 선지 뒤에 무엇이 붙는지 기록
            i = S.find(seg); bad.append((k+1, "next≠" + S[i+len(seg):i+len(seg)+12]))
    if bad: res.append({"key": key, "kind": "mismatch", "bad": bad})
json.dump(res, open("/home/claude/chk/check.json", "w"), ensure_ascii=False, indent=0)
from collections import Counter
print(Counter(r["kind"] for r in res))
print(Counter(r["key"].split("||")[0] for r in res if r["kind"] == "mismatch").most_common())
