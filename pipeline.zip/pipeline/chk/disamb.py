# -*- coding: utf-8 -*-
"""resolve.json 중 맥락이 원본에서 여러 번 나온 것(nmatch≥2)을, 후보 위치마다 더 넓은 앞뒤 맥락(선지는 원문자 번호)을 비교해
가장 잘 맞는 한 곳의 글자로 고친다. 동점이면 cap=None(손대지 않음). 출력: resolve_v2.json"""
import json, re
exec(open('/home/claude/chk/extract37.py').read().split("DIFF = []")[0])
PAS = json.loads([l for l in s if l.startswith("const PASSAGES = ")][0][17:].rstrip(";"))
ITD = {f"{it['exam_id']}||{it['영역']}||{it['문항번호']}": it for it in IT}
R = json.load(open("resolve.json"))
DISP = {}
def disp(ex):
    if ex not in DISP:
        try: DISP[ex] = build(ex)[2].replace("​", "")
        except Exception: DISP[ex] = None
    return DISP[ex]
def text_of(r):
    if r["kind"] == "선지": return CH[r["key"]][r["num"] - 1]
    if r["kind"] == "지문": return PAS[r["key"]]
    return ITD[r["key"]][r["kind"]]
def ctx_re(t): return "".join((r"\s*" if ch.isspace() else re.escape(ch) + r"\s*") for ch in t)
def NN(t): return re.sub(r"[\s​]", "", "".join(ch for ch in t if not (0xE000 <= ord(ch) <= 0xF8FF or ord(ch) >= 0xF0000 or ch == "□")))
def score_back(site, src):
    a, b = NN(site), NN(src); n = 0
    while n < len(a) and n < len(b) and a[-1 - n] == b[-1 - n]: n += 1
    return n
def score_fwd(site, src):
    a, b = NN(site), NN(src); n = 0
    while n < len(a) and n < len(b) and a[n] == b[n]: n += 1
    return n
out = []; stat = {"same": 0, "changed": 0, "unres": 0}
for r in R:
    r2 = dict(r)
    if r["nmatch"] >= 2 and r["cap"] is not None:
        ex = r["key"].split("||")[0]; D = disp(ex); t = text_of(r)
        L, Rr = r["L"], r["R"]; p, q = r["pos"], r["pos"] + len(r["run"])
        rx = re.compile(ctx_re(L) + r"\s*(.{0,6}?)" + (r"\s*" if Rr else "") + ctx_re(Rr))
        cands = list(rx.finditer(D))
        before = t[max(0, p - len(L) - 40):p - len(L)]; after = t[q + len(Rr):q + len(Rr) + 40]
        sc = []
        for m in cands:
            s1 = score_back(before, D[max(0, m.start() - 80):m.start()])
            s2 = score_fwd(after, D[m.end():m.end() + 80])
            s3 = 0
            if r["kind"] == "선지" and not NN(before):
                tail = NN(D[max(0, m.start() - 6):m.start()])
                s3 = 100 if tail.endswith("①②③④⑤"[r["num"] - 1]) else 0
            sc.append((s1 + s2 + s3, m.group(1)))
        sc.sort(key=lambda x: -x[0])
        if len(sc) >= 2 and sc[0][0] == sc[1][0] and sc[0][1] != sc[1][1]: r2["cap"] = None; stat["unres"] += 1
        elif sc and sc[0][1] == r["cap"]: stat["same"] += 1
        elif sc: r2["cap"] = sc[0][1]; r2["old"] = r["cap"]; stat["changed"] += 1
    out.append(r2)
json.dump(out, open("resolve_v2.json", "w"), ensure_ascii=False)
print(stat)
for r in out:
    if "old" in r or (r["nmatch"] >= 2 and r["cap"] is None): print(r["kind"], r["key"], r["num"], repr(r["L"][-8:]), repr(r["R"][:6]), [hex(ord(c)) for c in (r.get("old") or "")], "→", [hex(ord(c)) for c in (r["cap"] or "")])
