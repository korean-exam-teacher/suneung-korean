import json, re, difflib, sys
exec(open('/home/claude/chk/movefix.py').read().split('if __name__')[0])
A = json.load(open('/home/claude/chk/v39B.json'))
units = [("지문", k, v) for k, v in A['PAS'].items()] + [("보기", k, v) for k, v in A['BOGI'].items()]
rows = []
for kind, k, v in units:
    ex = k.split('||')[0]; S = src(ex)
    if not S: continue
    head, toks, seps = site_tok(v)
    if len(toks) < 6: continue
    nsrc = [Nt(w) for w, _ in S]
    rg = region(toks, nsrc)
    if not rg: rows.append((kind, k, "NOANCHOR", "", "")); continue
    a, b = rg; no = nsrc[a:b]; ns = [Nt(x) for x in toks]
    sm = difflib.SequenceMatcher(None, ns, no, autojunk=False)
    ops = sm.get_opcodes()
    # 앞뒤 끝 부분의 원본 쪽 군더더기 무시
    for tg, i1, i2, j1, j2 in ops:
        if tg == 'equal': continue
        if tg == 'insert' and (i1 == 0 or i1 == len(ns)): continue
        x = " ".join(toks[i1:i2]); y = " ".join(S[a + j][0] for j in range(j1, j2))
        if "".join(ns[i1:i2]) == "".join(no[j1:j2]): continue   # 띄어쓰기만 다름
        if re.fullmatch(r"[\d\s]*", Nt(x) + Nt(y)) and len(Nt(x) + Nt(y)) <= 3: continue
        ctx = " ".join(toks[max(0, i1 - 5):i2 + 5])
        rows.append((kind, k, tg, x[:60], y[:60], ctx[:140]))
json.dump(rows, open('/home/claude/chk/pdiff3.json', 'w'), ensure_ascii=False, indent=0)
from collections import Counter
print(len(rows), Counter(r[2] for r in rows))
