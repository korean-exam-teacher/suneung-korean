import json, sys
sys.argv = ["x", "__none__"]
exec(open('/home/claude/chk/rebuild.py').read().split('if __name__')[0])
A = json.load(open('/home/claude/chk/v39B.json'))
rows = []
for k, v in A['PAS'].items():
    if k.split('||')[1] != '문학': continue
    try: R, s = build(k.split('||')[0], v)
    except Exception: R, s = None, 'err'
    body = v.split("\n\n※")[0]
    sl = body.count("\n") + 1
    if R is None: rows.append((k, sl, None, s)); continue
    rl = R.count("\n") + 1
    rows.append((k, sl, rl, s))
json.dump(rows, open('/home/claude/chk/linecheck.json', 'w'), ensure_ascii=False)
for k, sl, rl, s in sorted(rows):
    if rl is None or abs(sl - rl) > max(3, 0.15 * rl): print(k, '사이트줄', sl, '원본줄', rl, s)
