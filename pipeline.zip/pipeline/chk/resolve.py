import json,re
from collections import Counter,defaultdict
exec(open('/home/claude/chk/extract37.py').read().split("DIFF = []")[0])
PAS=json.loads([l for l in s if l.startswith("const PASSAGES = ")][0][17:].rstrip(";"))
pat=re.compile(r"□")
units=[]
for k,v in CH.items():
    for i,x in enumerate(v):
        if '□' in x: units.append(("선지",k,i+1,x))
for it in IT:
    k=f"{it['exam_id']}||{it['영역']}||{it['문항번호']}"
    for f in ('발문','보기'):
        if it.get(f) and '□' in it[f]: units.append((f,k,None,it[f]))
for k,v in PAS.items():
    if '□' in v: units.append(("지문",k,None,v))
DISP={}
def disp(ex):
    if ex not in DISP:
        try: DISP[ex]=build(ex)[2].replace("\u200b","")
        except Exception as e: DISP[ex]=None
    return DISP[ex]
def ctx_re(t):
    out=""
    for ch in t:
        if ch.isspace(): out+=r"\s*"
        else: out+=re.escape(ch)+r"\s*"
    return out
res=[]
for kind,k,num,text in units:
    ex=k.split("||")[0]; D=disp(ex)
    for m in re.finditer(r"□+",text):
        L=text[max(0,m.start()-10):m.start()]; R=text[m.end():m.end()+10]
        L=L.split("□")[-1]; R=R.split("□")[0]
        cap=None; n=0
        if D and (len(L.strip())>=3 or len(R.strip())>=3):
            rx=re.compile(ctx_re(L)+r"\s*(.{0,6}?)"+ (r"\s*" if R else "")+ctx_re(R))
            ms=list(rx.finditer(D)); n=len(ms)
            if ms: cap=ms[0].group(1)
        res.append({"kind":kind,"key":k,"num":num,"pos":m.start(),"run":m.group(),"L":L,"R":R,"cap":cap,"nmatch":n})
json.dump(res,open('resolve.json','w'),ensure_ascii=False)
c=Counter()
for r in res:
    cap=r['cap']
    if cap is None: c['nomatch']+=1
    else: c[' '.join(f"U+{ord(x):04X}" if not ('가'<=x<='힣') else x for x in cap)]+=1
print(len(res)); print(c.most_common(40))
