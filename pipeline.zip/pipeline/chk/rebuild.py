# -*- coding: utf-8 -*-
"""문학 지문(2018~)을 원본 줄(streams2)에서 다시 짠다: 시행·연 나눔·각주 줄을 원본대로.
글자 묶음(옛한글·□·공백 뺀 글자 꾸러미)이 지금 사이트 지문과 똑같을 때만 바꾼다(내용이 빠지거나 더해지지 않음을 보장)."""
import json, re, sys, unicodedata
from collections import Counter
_src=open('/home/claude/chk/movefix.py').read(); exec(_src.split('def Nt')[0]); exec('TOK'+_src.split('TOK',1)[1].split('SRCD = {}')[0])
def NC(t):
    t = unicodedata.normalize("NFKC", t)
    for a, b in [("‘", "'"), ("’", "'"), ("“", '"'), ("”", '"'), ("ㆍ", "·"), ("․", "·"), ("∙", "·"), ("～", "~"), ("∼", "~"), ("―", "-"), ("—", "-"), ("–", "-"), ("＋", "+")]: t = t.replace(a, b)
    return re.sub(r"[\s​□『』「」｢｣ᄀ-ᇿ-\U000f0000-\U0010ffff]", "", t)
def lines(ex):
    L = json.load(open(f'/home/claude/chk/streams2/{ex}.json'))
    return [l for l in L if not is_junk(l['t'])]
HASTE = {}
def join_sep(prev, nxt, pline):
    """줄이 꽉 차서 넘어간 자리: 원본 줄 끝 공백 기록이 있으면 그대로, 없으면 지금 사이트 글의 띄어쓰기를 따른다"""
    if HASTE.get(CUR[0]): return " " if pline.get("te") else ""
    a = re.sub(r"\s", "", prev)[-4:]; b = re.sub(r"\s", "", nxt)[:4]
    if not a or not b: return " "
    pat = r"\s*".join(map(re.escape, a)) + r"(\s*)" + r"\s*".join(map(re.escape, b))
    ms = list(re.finditer(pat, CUR[1]))
    if len(ms) == 1: return "" if ms[0].group(1) == "" else " "
    return " "
CUR = [None, ""]
KEEPWJ = [False]
CORPUS = [""]
try:
    _A = json.load(open('/home/claude/chk/v39B.json'))
    CORPUS[0] = re.sub(r"\s+", " ", " ".join(list(_A['PAS'].values()) + [c for v in _A['CHO'].values() for c in v]))
except Exception: pass
def site_junction(prev, nxt):
    a = re.sub(r"\s", "", prev)[-4:]; b = re.sub(r"\s", "", nxt)[:4]
    if not a or not b: return None
    pat = r"\s*".join(map(re.escape, a)) + r"(\s*)" + r"\s*".join(map(re.escape, b))
    ms = list(re.finditer(pat, CUR[1]))
    if len(ms) != 1: return None
    g = ms[0].group(1)
    return "\n" if "\n" in g else (" " if g else "")
def build(ex, site):
    CUR[0] = ex; CUR[1] = site
    if ex not in HASTE:
        try: HASTE[ex] = sum(1 for l in json.load(open(f'/home/claude/chk/streams2/{ex}.json')) if l.get('te')) > 50
        except Exception: HASTE[ex] = False
    L = lines(ex)
    body = site.split("\n\n※")[0]
    ns = NC(body)
    if len(ns) < 40: return None, "short"
    head, tail = ns[:14], ns[-14:]
    cum = []; acc = ""
    for l in L: cum.append(len(acc)); acc += NC(mapd(l['t']))
    i0 = acc.find(head)
    if i0 < 0: return None, "nohead"
    i1 = acc.find(tail, i0)
    if i1 < 0 or i1 - i0 > len(ns) * 1.3 + 50: return None, "notail"
    a = max(k for k in range(len(L)) if cum[k] <= i0); b = max(k for k in range(len(L)) if cum[k] <= i1 + len(tail) - 1)
    seg = L[a:b+1]
    # 앞뒤 줄이 지문 밖 글자를 포함하면 잘라낸다(첫 줄 앞부분, 끝 줄 뒷부분)
    txts = [mapd(l['t']).strip() for l in seg]
    # 첫 줄: head 앞 글자 제거
    def cut_head(t, h):
        n = ""; 
        for p in range(len(t)):
            if NC(t[p:]).startswith(h[:max(1, min(len(h), len(NC(t[p:]))))]) and NC(t[p:])[:len(h)] == h[:len(NC(t[p:])[:len(h)])]:
                return t[p:]
        return t
    txts[0] = cut_head(txts[0], head)
    # 끝 줄: tail 뒤 글자 제거
    t = txts[-1]
    for p in range(len(t), 0, -1):
        if NC(t[:p]).endswith(tail[-min(len(tail), len(NC(t[:p]))):]) and NC(t[:p]).endswith(tail[-3:]):
            txts[-1] = t[:p]; break
    # 줄 이음 규칙
    groups = {}
    for l in seg: groups.setdefault((l['pg'], l['col']), []).append(l)
    right = {k: max(x['x1'] for x in v) for k, v in groups.items()}
    left = {k: min(x['x0'] for x in v) for k, v in groups.items()}
    gaps = [seg[k+1]['top'] - seg[k]['top'] for k in range(len(seg) - 1) if seg[k+1]['pg'] == seg[k]['pg'] and seg[k+1]['col'] == seg[k]['col']]
    gaps = [g for g in gaps if g > 0]
    pitch = sorted(gaps)[len(gaps) // 2] if gaps else 18
    # 줄마다 '꽉 참' 여부와, 둘레 줄들이 대부분 짧은지(운문 구간인지)
    fulls = []
    for k, l in enumerate(seg):
        key = (l['pg'], l['col']); csz = (l['bot'] - l['top']) or 10
        fulls.append(l['x1'] >= right[key] - csz * 1.2 and not txts[k].rstrip().endswith('>') and not re.search(r'-\s*$', txts[k]) and not re.search(r'\[[A-Z]\]\s*$', txts[k]))
    fl = [seg[q] for q in range(len(seg) - 1) if fulls[q]]
    LOCAL_TE = bool(fl) and sum(1 for x in fl if x.get('te')) / len(fl) >= 0.3
    def verse_at(k):
        w = [fulls[q] for q in range(max(0, k - 4), min(len(seg), k + 5)) if not txts[q].startswith('*')]
        return w and sum(1 for f in w if not f) / len(w) > 0.5
    out = ""
    for k, l in enumerate(seg):
        t = txts[k]
        if k == 0: out = t; continue
        p = seg[k-1]; key = (l['pg'], l['col']); pk = (p['pg'], p['col'])
        csz = (p['bot'] - p['top']) or 10
        full = fulls[k-1]
        rightish = l['x0'] > left[key] + (right[key] - left[key]) * 0.45 and t.startswith('<') and len(t) < 12
        same_col = key == pk
        gap = l['top'] - p['top'] if same_col else pitch
        if rightish: out += " " + t; continue
        if t.startswith('*') or t.startswith('-') and not full: out += "\n" + t; continue
        if full and not re.match(r'\([가-하]\)', t) and HASTE.get(CUR[0]) and LOCAL_TE:
            pv = txts[k-1].rstrip()
            if p.get('te'): out += " " + t; continue
            if pv.count("(") > pv.count(")"): out += "\u2060" + t; continue
            if re.search(r"[.?!…”’」』)\]]$", pv): out += ("\n\n" if gap > pitch * 1.5 else "\n") + t; continue
            lw = re.findall(r"[가-힣\u1100-\u11ff]+$", pv); fw = re.findall(r"^[가-힣\u1100-\u11ff]+", t.lstrip())
            if lw and fw and len(lw[0] + fw[0]) >= 2 and re.search(r"(?<![가-힣])" + re.escape(lw[0] + fw[0]), CORPUS[0]):
                out += "\u2060" + t; continue
            if len(t) < len(pv) * 0.4 and not t.startswith("<") and not t.startswith("-"):
                out += ("\u2060" if (lw and fw) else " ") + t; continue
            if not verse_at(k):
                sj = site_junction(txts[k-1], t)
                out += ("\n" if sj == "\n" else "\u2060") + t; continue
            if len(t) < len(pv) * 0.4 and not t.startswith("<"): out += " " + t; continue
            out += ("\n\n" if gap > pitch * 1.5 else "\n") + t; continue
        if full and not re.match(r'\([가-하]\)', t):
            sj = site_junction(txts[k-1], t)
            if sj is not None and sj != " ":
                out += ("\n\n" if (sj == "\n" and gap > pitch * 1.5) else sj) + t; continue
            # 운문 구간: 앞줄보다 들여 쓴 줄만 이어지는 줄이고, 같은 자리에서 시작하면 새 시행
            a_, b_ = txts[k-1].rstrip()[-3:], t.lstrip()[:3]
            midword = (a_ + b_) in CUR[1] and (a_ + " " + b_) not in CUR[1] and (a_ + "\n" + b_) not in CUR[1]
            shortnext = len(t) < len(txts[k-1]) * 0.4
            te_ok = (not (HASTE.get(CUR[0]) and LOCAL_TE)) or not p.get('te')
            if verse_at(k) and same_col and l['x0'] <= p['x0'] + csz * 0.5 and not midword and not shortnext and te_ok:
                out += ("\n\n" if gap > pitch * 1.5 else "\n") + t; continue
            out += join_sep(txts[k-1], t, p) + t; continue
        out += ("\n\n" if gap > pitch * 1.5 else "\n") + t
    return (out if KEEPWJ[0] else out.replace("\u2060", "")), "ok"
if __name__ == "__main__":
    A = json.load(open('/home/claude/chk/v39B.json'))
    res = {}; st = Counter()
    keys = [k for k in A['PAS'] if k.split('||')[1] == '문학'] if len(sys.argv) < 2 else sys.argv[1:]
    for k in keys:
        site = A['PAS'][k]
        try: new, s = build(k.split('||')[0], site)
        except Exception as e: new, s = None, "err " + str(e)[:40]
        if new is None: st[s] += 1; continue
        note = ("\n\n※" + site.split("\n\n※", 1)[1]) if "\n\n※" in site else ""
        if Counter(NC(site.split("\n\n※")[0])) != Counter(NC(new)):
            st["bagdiff"] += 1; res[k] = {"ok": False, "new": new + note}; continue
        st["ok"] += 1; res[k] = {"ok": True, "new": new + note}
    json.dump(res, open('/home/claude/chk/rebuild.json', 'w'), ensure_ascii=False, indent=0)
    print(st)
