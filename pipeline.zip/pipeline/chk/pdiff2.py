import json,re,difflib
exec(open('/home/claude/chk/extract37.py').read().split("DIFF = []")[0])
PAS=json.loads([l for l in s if l.startswith("const PASSAGES = ")][0][17:].rstrip(";"))
JUNKSEG=re.compile(r"^(\d+|국어영역|영역|홀수형|짝수형|\(|\)|이문제지에관한저작권은한국교육과정평가원에있습니다\.?|[\[\]\d~]+다음글을읽고물음에답하시오\.?)+$")
def nmap(text):
    norm="";pos=[]
    for i,ch in enumerate(text):
        for c in N(ch): norm+=c; pos.append(i)
    return norm,pos
cache={}
def stream(ex):
    if ex not in cache: cache[ex]=build(ex)
    return cache[ex]
LINES={}
def lines(ex):
    if ex not in LINES:
        try: LINES[ex]=json.load(open(f'/home/claude/chk/streams/{ex}.json'))
        except: LINES[ex]=None
    return LINES[ex]
import bisect
OFF={}
def page_at(ex,di):
    if ex in HK: return None
    if ex not in OFF:
        L=[l for l in json.load(open(f'/home/claude/chk/streams/{ex}.json')) if not is_junk(l["t"])]
        d=""; st=[]; pg=[]
        for l in L:
            if d and not d.endswith(" "): d+="\n"
            st.append(len(d)); pg.append(l["pg"]+1); d+=l["t"]
        OFF[ex]=(st,pg)
    st,pg=OFF[ex]; k=bisect.bisect_right(st,di)-1
    return pg[max(0,k)]
def page_of(ex,snip):
    L=lines(ex)
    if not L or not snip: return None
    a=N(snip)[:12]
    for l in L:
        if a and a in N(l["t"]): return l["pg"]+1
    return None
units=[("지문",k,v) for k,v in PAS.items()]
for it in IT:
    if it.get("보기"): units.append(("보기",f"{it['exam_id']}||{it['영역']}||{it['문항번호']}",it["보기"]))
rows=[]
for kind,k,v in units:
    ex=k.split("||")[0]
    norm,pos,disp=stream(ex)
    t,tp=nmap(v)
    if len(t)<30: continue
    i=norm.find(t[:25]); 
    if i<0: continue
    j=norm.find(t[-25:],i)
    if j<0 or j-i>len(t)*1.6+200: continue
    src=norm[i:j+25]
    sm=difflib.SequenceMatcher(None,t,src,autojunk=False)
    ops=[(tag,i1,i2,j1,j2) for tag,i1,i2,j1,j2 in sm.get_opcodes() if tag!='equal']
    ins=[src[j1:j2] for _,_,_,j1,j2 in ops]; dels=[t[i1:i2] for _,i1,i2,_,_ in ops]
    for tag,i1,i2,j1,j2 in ops:
        x,y=t[i1:i2],src[j1:j2]
        if not x and JUNKSEG.match(y): continue
        if re.fullmatch(r"(#\d#)+",x+y): continue
        if re.fullmatch(r"[\*]+",x+y): continue
        moved = (x and len(x)>=2 and any(x==z for z in ins)) or (y and len(y)>=2 and any(y==z for z in dels))
        if moved and not x: continue   # 짝 중 한쪽(사이트에 있는 쪽)만 기록
        digits = bool(re.fullmatch(r"\d+",x+y))
        if not (moved or digits or len(x)+len(y)>=3): continue
        a=tp[max(0,i1-1)] if t else 0
        s0=max(0,tp[i1]-25 if i1<len(tp) else len(v)-25); s1=min(len(v),(tp[i2-1] if i2-1<len(tp) and i2>0 else s0)+25)
        site_ctx=v[s0:s1].replace("\n"," / ")
        p0=pos[i+j1] if i+j1<len(pos) else 0
        src_ctx=disp[max(0,p0-25):p0+len(y)+25].replace("\n"," ")
        kindop="자리 밀림(다른 글꼴 낱말 등)" if moved else ("숫자(첨자) 흩어짐" if digits else ("원본에만 있는 글자" if not x else ("사이트에만 있는 글자" if not y else "글자 다름")))
        rows.append({"구분":kind,"key":k,"유형":kindop,"사이트":x,"원본":y,"사이트 맥락":site_ctx,"원본 맥락":src_ctx,"쪽":page_at(ex,p0)})
json.dump(rows,open('/home/claude/chk/pdiff_rows.json','w'),ensure_ascii=False,indent=0)
from collections import Counter
print(len(rows),Counter(r["유형"] for r in rows), len({r['key'] for r in rows}))
