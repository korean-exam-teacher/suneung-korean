import json, os, subprocess, sys
from PIL import Image
sys.path.insert(0,'/home/claude/chk')
from streams import fname, SRC
P=json.load(open('/home/claude/chk/puapos.json'))
DPI=220; SC=DPI/72
_pg={}
def page(ex,pg):
    k=(ex,pg)
    if k not in _pg:
        base=f"/tmp/claude-0/g_{ex}_{pg}"
        if not os.path.exists(base+".png"):
            subprocess.run(["pdftoppm","-r",str(DPI),"-f",str(pg+1),"-l",str(pg+1),"-png","-singlefile",SRC+fname(ex),base],check=True,stderr=subprocess.DEVNULL)
        _pg[k]=Image.open(base+".png")
    return _pg[k]
def glyph(ch, exs, out):
    for ex in exs:
        if ch in P.get(ex,{}):
            pg,x0,top,x1,bot=P[ex][ch][0]
            im=page(ex,pg)
            h=bot-top
            box=(int((x0-h*2.2)*SC),int((top-h*0.35)*SC),int((x1+h*2.2)*SC),int((bot+h*0.35)*SC))
            c=im.crop(box)
            # 가운데 글자 아래 표시
            c.save(out); return ex,pg+1
    return None
if __name__=="__main__":
    print(glyph(chr(int(sys.argv[1],16)), sys.argv[2:], "/home/claude/chk/crops/g_test.png"))
