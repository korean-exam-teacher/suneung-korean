# -*- coding: utf-8 -*-
"""left2.json의 □ 자리를 원본 PDF 글자 좌표에서 찾아, 그 부분을 크게 잘라 그림으로 만든다(눈으로 판독용)."""
import json, re, unicodedata, sys, os, subprocess
sys.path.insert(0, "/home/claude/chk")
import pdfplumber
from PIL import Image, ImageDraw, ImageFont
from streams import fname, SRC
from pua_map import READ, compose
from openpyxl import load_workbook
wb = load_workbook("/home/claude/chk/직접확인_목록_원본.xlsx"); ws = wb["2 옛한글·기호(글자별)"]
CODE = {}
for r in ws.iter_rows(min_row=2, values_only=True):
    num, code, typed = r[0].split("-")[1], r[2], r[6]
    if typed: CODE[chr(int(code[2:], 16))] = typed
    elif num in READ: CODE[chr(int(code[2:], 16))] = compose(READ[num])
CODE["\U000f0854"] = "『"; CODE["\U000f0855"] = "』"
import sys as _s; _s.path.insert(0, "/home/claude/chk"); from pua_map import EXTRA as _EX; CODE.update(_EX)
CIR = "①②③④⑤"
def nch(c):
    if c in CODE: c = CODE[c]
    o = ""
    for x in c:
        if x in CIR: o += "#"; continue
        x = unicodedata.normalize("NFKC", x)
        for a, b in [("‘", "'"), ("’", "'"), ("“", '"'), ("”", '"'), ("ㆍ", "·"), ("․", "·"), ("‧", "·"), ("∙", "·"), ("～", "~"), ("∼", "~")]: x = x.replace(a, b)
        x = re.sub(r"\s", "", x)
        x = "".join("\x00" if (0xE000 <= ord(y) <= 0xF8FF or ord(y) >= 0xF0000 or y == "□") else y for y in x)
        o += x
    return o
PAGES = {}
def pages(ex):
    if ex in PAGES: return PAGES[ex]
    out = []
    with pdfplumber.open(SRC + fname(ex)) as pdf:
        for pi, pg in enumerate(pdf.pages):
            cs = [c for c in pg.dedupe_chars().chars if c["text"].strip()]
            W = pg.width
            # 단 나누기: 가운데 기준
            mid = W / 2
            for col in (0, 1):
                part = [c for c in cs if ((c["x0"] + c["x1"]) / 2 < mid) == (col == 0)]
                part.sort(key=lambda c: (round(c["top"] / 3), c["x0"]))
                s = ""; idx = []
                for c in part:
                    for x in nch(c["text"]): s += x; idx.append(c)
                out.append((pi, col, s, idx))
    PAGES[ex] = out; return out
def keyN(t): return "".join(nch(c) for c in t)
DPI = 320; SC = DPI / 72
def page_img(ex, pg):
    base = f"/tmp/claude-0/L3_{ex}_{pg}"
    if not os.path.exists(base + ".png"):
        subprocess.run(["pdftoppm", "-r", str(DPI), "-f", str(pg+1), "-l", str(pg+1), "-png", "-singlefile", SRC + fname(ex), base], check=True, stderr=subprocess.DEVNULL)
    return Image.open(base + ".png")
def locate(ex, L, R, mode=0):
    Ln = keyN(L)[-6:]; Rn = keyN(R)[:5]
    if mode == 1: Ln = ""; Rn = keyN(R)[:7]
    if mode == 2: Ln = keyN(L)[-7:]; Rn = ""
    if len(Ln) + len(Rn) < 3: return []
    pre = r"(?:.{0,6})" if mode == 1 else ""; post = r"(?:.{0,6})" if mode == 2 else ""
    rx = re.compile(pre + re.escape(Ln).replace("\\x00", ".") + r"(.{0,8}?)" + re.escape(Rn).replace("\\x00", ".") + post, re.S)
    hits = []
    try: P = pages(ex)
    except Exception as e: return []
    for pi, col, s, idx in P:
        for m in rx.finditer(s):
            a = max(0, m.start() - 0); b = min(len(idx) - 1, m.end() - 1)
            cs = idx[a:b+1]
            hits.append((pi, cs))
    return hits
def crop(ex, pi, cs, pad=2.0):
    im = page_img(ex, pi)
    top = min(c["top"] for c in cs); bot = max(c["bottom"] for c in cs)
    h = max(c["bottom"] - c["top"] for c in cs)
    # 여러 줄에 걸치면 줄마다 따로
    rows = {}
    for c in cs: rows.setdefault(round(c["top"] / 4), []).append(c)
    pieces = []
    for _, rc in sorted(rows.items()):
        x0 = min(c["x0"] for c in rc) - h * pad; x1 = max(c["x1"] for c in rc) + h * pad
        t0 = min(c["top"] for c in rc) - h * 0.5; b0 = max(c["bottom"] for c in rc) + h * 0.5
        pieces.append(im.crop((int(x0 * SC), int(t0 * SC), int(x1 * SC), int(b0 * SC))))
    W = sum(p.size[0] for p in pieces) + 10 * (len(pieces) - 1); H = max(p.size[1] for p in pieces)
    o = Image.new("RGB", (W, H), "white"); x = 0
    for p in pieces: o.paste(p, (x, 0)); x += p.size[0] + 10
    return o
if __name__ == "__main__":
    LEFT = json.load(open("/home/claude/chk/left2.json"))
    res = []
    for i, r in enumerate(LEFT):
        ex = r["key"].split("||")[0]
        h = locate(ex, r["L"], r["R"]); mode = 0
        if not h: h = locate(ex, r["L"], r["R"], 1); mode = 1
        if not h: h = locate(ex, r["L"], r["R"], 2); mode = 2
        rec = {"i": i, "n": len(h), "mode": mode}
        if h:
            pi, cs = h[0]
            im = crop(ex, pi, cs); p = f"/home/claude/chk/loc/{i:03d}.png"; im.save(p)
            rec.update(pg=pi + 1, codes=[f"{ord(c['text'][0]):X}" if c["text"] else "" for c in cs])
        res.append(rec)
        print(i, r["key"], len(h), flush=True)
    json.dump(res, open("/home/claude/chk/loc/loc.json", "w"), ensure_ascii=False)
