import json, sys
exec(open('/home/claude/chk/movefix.py').read().split('def Nt')[0])
ex, start, n = sys.argv[1], sys.argv[2], int(sys.argv[3])
L = json.load(open(f'/home/claude/chk/streams2/{ex}.json'))
for i, l in enumerate(L):
    if start in mapd(l['t']):
        for x in L[i:i+n]:
            raw = x['t']; unk = [hex(ord(c)) for c in raw if (0xE000 <= ord(c) <= 0xF8FF or ord(c) >= 0xF0000) and c not in CODE]
            print(f"{x['x0']:6.1f} {x['x1']:6.1f} {x['top']:6.1f}|", mapd(raw), ("UNK" + str(unk)) if unk else "")
        break
