import sys, json
from PIL import Image, ImageDraw, ImageFont
L = json.load(open("left2.json"))
F = ImageFont.truetype("/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc", 24)
ids = [int(x) for x in sys.argv[2:]]; sc = float(sys.argv[1])
bl = []
for i in ids:
    im = Image.open(f"loc/{i:03d}.png"); im = im.resize((int(im.size[0] * sc), int(im.size[1] * sc)), Image.LANCZOS)
    if im.size[0] > 1500: im = im.crop((0, 0, 1500, im.size[1]))
    e = L[i]; lab = f"#{i} …{e['L'][-12:]}[{e['run']}]{e['R'][:12]}…".replace("\n", "⏎")
    b = Image.new("RGB", (1500, im.size[1] + 36), "white"); ImageDraw.Draw(b).text((4, 2), lab, fill=(200, 0, 0), font=F); b.paste(im, (0, 34)); bl.append(b)
o = Image.new("RGB", (1500, sum(b.size[1] + 8 for b in bl)), (220, 220, 220)); y = 0
for b in bl: o.paste(b, (0, y)); y += b.size[1] + 8
o.save("loc/zoom.png")
