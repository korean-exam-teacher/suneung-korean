# -*- coding: utf-8 -*-
"""문항(발문 ~ 다음 문항 발문 직전)을 원본 PDF에서 잘라 그림으로 만든다.  python3 crop.py KEY [KEY ...]"""
import json, re, sys, os, subprocess
from PIL import Image
exec(open("/home/claude/chk/extract.py").read().split("def build(ex):")[0])
from streams import fname, SRC
s = open("/home/claude/site_v36.html", encoding="utf-8").read().split("\n")
IT = json.loads([l for l in s if l.startswith("const ITEMS = ")][0][14:].rstrip(";"))
OUT = "/home/claude/chk/crops/"; os.makedirs(OUT, exist_ok=True)
DPI = int(os.environ.get("DPI","110")); SC = DPI / 72
_pages = {}
def page_img(ex, pg):
    k = (ex, pg)
    if k not in _pages:
        base = f"/tmp/claude-0/pg{DPI}_{ex}_{pg}"
        if not os.path.exists(base + ".png"):
            subprocess.run(["pdftoppm", "-r", str(DPI), "-f", str(pg+1), "-l", str(pg+1), "-png", "-singlefile", SRC + fname(ex), base], check=True)
        _pages[k] = Image.open(base + ".png")
    return _pages[k]
_lines = {}
def lines(ex):
    if ex not in _lines:
        L = json.load(open(f"/home/claude/chk/streams/{ex}.json"))
        _lines[ex] = L
    return _lines[ex]
def gutter_x(ex, pg):
    L = [l for l in lines(ex) if l["pg"] == pg and l["col"] == 1]
    return min(l["x0"] for l in L) - 4 if L else None
def find(ex, num, stem):
    a = N(stem)[:25]
    for i, l in enumerate(lines(ex)):
        acc = ""; j = i
        while j < len(lines(ex)) and len(acc) < len(a) + 5:
            acc += N(lines(ex)[j]["t"]); j += 1
        if acc.startswith(a): return i
    return None
def crop(key, extra=0):
    ex, area, num = key.split("||"); num = int(num)
    its = sorted([i for i in IT if i["exam_id"] == ex], key=lambda i: (0,))
    it = [i for i in IT if i["exam_id"] == ex and i["영역"] == area and i["문항번호"] == num][0]
    L = lines(ex)
    i0 = find(ex, num, it["발문"])
    if i0 is None: print("not located", key); return None
    # 끝: 이후 줄 중 다음 문항 번호 "N+1." 또는 세트 머리로 시작하는 첫 줄
    i1 = None
    for j in range(i0 + 1, len(L)):
        t = L[j]["t"].strip()
        if re.match(rf"^{num+1}\s*\.", t) or re.match(r"^\[\s*\d{1,2}\s*[~～∼]\s*\d{1,2}\s*\]", t) or "확인 사항" in t:
            i1 = j; break
    if i1 is None: i1 = min(len(L) - 1, i0 + 40)
    i1 += extra
    segs = []
    cur = None
    for j in range(i0, i1 + 1):
        l = L[j]; k = (l["pg"], l["col"])
        if cur is None or cur[0] != k:
            if cur is not None: cur[2] = 99999   # 단이 바뀌면 앞 단은 끝까지
            cur = [k, l["top"], l["top"]]; segs.append(cur)
        cur[2] = max(cur[2], l["top"] - (22 if j == i1 else 0))
    if segs[-1][1] > segs[-1][2]: segs.pop()
    ims = []
    for (pg, col), t0, t1 in segs:
        img = page_img(ex, pg); W, H = img.size
        g = gutter_x(ex, pg)
        gx = g * SC if g else W / 2
        x0, x1 = (0, gx + 4) if col == 0 else (gx - 4, W)
        ims.append(img.crop((int(x0), int(max(0, (t0 - 8) * SC)), int(x1), int(min(H, (t1 + 22) * SC)))))
    Wm = max(i.size[0] for i in ims); Hs = sum(i.size[1] for i in ims) + 6 * (len(ims) - 1)
    out = Image.new("RGB", (Wm, Hs), "white"); y = 0
    for im in ims: out.paste(im, (0, y)); y += im.size[1] + 6
    p = OUT + key.replace("||", "_").replace(" ", "") + ".png"
    out.save(p); return p
if __name__ == "__main__":
    for k in sys.argv[1:]: print(crop(k))
