import json, sys, difflib
A = json.load(open('/home/claude/chk/v39A.json')); M = json.load(open('/home/claude/chk/movefix.json'))
for k in sys.argv[1:]:
    a = A['PAS'][k]; b = M.get('지문||' + k)
    if b is None: print('NOCHANGE', k); continue
    ta, tb = a.replace('\n', ' ⏎ ').split(' '), b.replace('\n', ' ⏎ ').split(' ')
    sm = difflib.SequenceMatcher(None, ta, tb, autojunk=False)
    print('=====', k)
    for tg, i1, i2, j1, j2 in sm.get_opcodes():
        if tg != 'equal': print(' ', tg, '|', ' '.join(ta[max(0,i1-4):i2+3]), '  ==>  ', ' '.join(tb[max(0,j1-4):j2+3]))
