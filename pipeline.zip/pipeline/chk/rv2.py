import json,sys,re
exec(open('/home/claude/chk/extract.py').read().split("DIFF = []")[0])
D={r['key']:r for r in json.load(open('/home/claude/chk/diff.json'))}
FB=json.load(open('/home/claude/chk/fix_boiler.json'))
for key in sys.argv[1:]:
    site=FB.get(key,CH.get(key)); src=D[key]['src']
    print("=====",key)
    for k in range(5):
        if N(site[k])!=N(src[k]):
            print(f"  site{k+1}:",site[k][:230]); print(f"  src {k+1}:",src[k][:230])
