import sys, json, re, os
sys.path.insert(0, "/home/claude/chk")
exec(open("/home/claude/chk/locate.py").read().split('if __name__')[0].replace("DPI = 320", "DPI = 600").replace("/tmp/claude-0/L3_", "/tmp/claude-0/L6_"))
from PIL import Image, ImageDraw, ImageFont
LEFT = json.load(open("/home/claude/chk/left2.json"))
def tight(i):
    e = LEFT[i]; ex = e["key"].split("||")[0]
    Ln = keyN(e["L"])[-6:]; Rn = keyN(e["R"])[:5]
    if len(Ln) + len(Rn) < 3: return None
    rx = re.compile(re.escape(Ln).replace("\\x00", ".") + r"(.{0,8}?)" + re.escape(Rn).replace("\\x00", "."), re.S)
    for pi, col, s, idx in pages(ex):
        m = rx.search(s)
        if not m: continue
        a, b = m.start(1), m.end(1)
        lc = idx[max(0, a - 2):a]; rc = idx[b:b + 2]; gc = idx[a:b]
        cs = lc + gc + rc
        # 같은 줄(왼쪽 글자의 줄) 기준
        im = page_img(ex, pi)
        ref = (lc or rc)[-1] if lc else rc[0]
        hgt = ref["bottom"] - ref["top"]
        rows = {}
        for c in cs: rows.setdefault(round(c["top"] / 4), []).append(c)
        pieces = []
        for _, r in sorted(rows.items()):
            x0 = min(c["x0"] for c in r) - hgt * 0.3; x1 = max(c["x1"] for c in r) + hgt * 0.3
            if lc and r is rows.get(round(lc[-1]["top"] / 4)) and not gc and rc and round(rc[0]["top"]/4) == round(lc[-1]["top"]/4):
                pass
            t0 = min(c["top"] for c in r) - hgt * 0.45; b0 = max(c["bottom"] for c in r) + hgt * 0.45
            pieces.append(im.crop((int(x0 * SC), int(t0 * SC), int(x1 * SC), int(b0 * SC))))
        W = sum(p.size[0] for p in pieces) + 30 * (len(pieces) - 1); H = max(p.size[1] for p in pieces)
        o = Image.new("RGB", (W, H), "white"); x = 0
        for p in pieces: o.paste(p, (x, 0)); x += p.size[0] + 30
        return o
    return None
F = ImageFont.truetype("/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc", 28)
if __name__ == "__main__":
    ids = [int(x) for x in sys.argv[2:]]; out = []
    for i in ids:
        im = tight(i); e = LEFT[i]
        if im is None:
            p = f"/home/claude/chk/loc/{i:03d}.png"
            if not os.path.exists(p): continue
            im = Image.open(p)
        if im.size[1] > 220: im = im.resize((int(im.size[0] * 220 / im.size[1]), 220), Image.LANCZOS)
        if im.size[0] > 1500: im = im.crop((0, 0, 1500, im.size[1]))
        b = Image.new("RGB", (1500, im.size[1] + 40), "white"); ImageDraw.Draw(b).text((4, 2), f"#{i} {e['key']} …{e['L'][-12:]}[{e['run']}]{e['R'][:12]}…".replace("\n", "⏎"), fill=(200, 0, 0), font=F); b.paste(im, (0, 38)); out.append(b)
    o = Image.new("RGB", (1500, sum(b.size[1] + 8 for b in out)), (210, 210, 210)); y = 0
    for b in out: o.paste(b, (0, y)); y += b.size[1] + 8
    o.save(sys.argv[1]); print(len(out))
