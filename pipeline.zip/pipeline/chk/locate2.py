import json, re, sys
sys.path.insert(0, "/home/claude/chk")
exec(open("/home/claude/chk/locate.py").read().split('if __name__')[0])
s = open("/home/claude/site_v38.html", encoding="utf-8").read().split("\n")
def load(n): return json.loads([l for l in s if l.startswith(f"const {n} = ")][0][len(f"const {n} = "):].rstrip(";"))
ITEMS = load("ITEMS"); CHO = load("CHOICES"); PAS = load("PASSAGES")
IT = {f'{i["exam_id"]}||{i["영역"]}||{i["문항번호"]}': i for i in ITEMS}
def text_of(e):
    if e["kind"] == "선지": return CHO[e["key"]][e["num"] - 1]
    if e["kind"] == "지문": return PAS[e["key"]]
    return IT[e["key"]][e["kind"]]
LEFT = json.load(open("loc/../left2.json")); LOC = json.load(open("loc/loc.json"))
for rec in LOC:
    if rec["n"]: continue
    e = LEFT[rec["i"]]
    if "로 표시됩니" in e["R"]: continue
    t = text_of(e); p = e["pos"]; q = p + len(e["run"])
    toks = []
    for m in re.finditer(r"[가-힣A-Za-z0-9]{3,}", t[max(0, p - 60):p]): toks.append((p - (max(0, p-60) + m.end()), m.group(), -1))
    for m in re.finditer(r"[가-힣A-Za-z0-9]{3,}", t[q:q + 60]): toks.append((m.start(), m.group(), 1))
    toks.sort()
    ex = e["key"].split("||")[0]
    try: P = pages(ex)
    except Exception: continue
    got = None
    for d, tok, side in toks:
        tn = keyN(tok)
        hs = [(pi, si, idx) for pi, col, st, idx in P for si in [m.start() for m in re.finditer(re.escape(tn), st)]]
        if len(hs) == 1:
            pi, si, idx = hs[0]
            a = max(0, si - (25 if side == 1 else 5)); b = min(len(idx), si + len(tn) + (25 if side == -1 else 5))
            got = (pi, idx[a:b], tok); break
    if got:
        im = crop(ex, got[0], got[1], pad=0.6); im.save(f"loc/{rec['i']:03d}.png")
        rec.update(n=1, mode=3, pg=got[0] + 1, tok=got[2])
    print(rec["i"], e["key"], rec["n"], rec.get("tok"))
json.dump(LOC, open("loc/loc.json", "w"), ensure_ascii=False)
