import json,re,difflib
from collections import Counter
exec(open('/home/claude/chk/extract37.py').read().split("DIFF = []")[0])
PAS=json.loads([l for l in s if l.startswith("const PASSAGES = ")][0][17:].rstrip(";"))
JUNKSEG=re.compile(r"^(\d+|국어영역|영역|홀수형|짝수형|\(|\)|이문제지에관한저작권은한국교육과정평가원에있습니다\.?|[\[\]\d~]+다음글을읽고물음에답하시오\.?)+$")
cache={}
def stream(ex):
    if ex not in cache: cache[ex]=build(ex)
    return cache[ex]
out=[]
units=[("지문",k,v) for k,v in PAS.items()]
for it in IT:
    if it.get("보기"): units.append(("보기",f"{it['exam_id']}||{it['영역']}||{it['문항번호']}",it["보기"]))
for kind,k,v in units:
    ex=k.split("||")[0]
    if ex.startswith("2028"): continue
    norm,pos,disp=stream(ex)
    t=N(v)
    if len(t)<30: continue
    a=t[:25]; b=t[-25:]
    i=norm.find(a)
    if i<0: out.append((kind,k,"anchor-start",[])); continue
    j=norm.find(b,i)
    if j<0 or j-i>len(t)*1.6+200: out.append((kind,k,"anchor-end",[])); continue
    src=norm[i:j+len(b)]
    sm=difflib.SequenceMatcher(None,t,src,autojunk=False)
    ops=[]
    for tag,i1,i2,j1,j2 in sm.get_opcodes():
        if tag=='equal': continue
        x,y=t[i1:i2],src[j1:j2]
        if not x and JUNKSEG.match(y): continue
        if re.fullmatch(r"#\d#",y) or re.fullmatch(r"#\d#",x): continue
        ops.append((tag,x,y,i1))
    if ops: out.append((kind,k,"diff",ops))
json.dump(out,open('pdiff.json','w'),ensure_ascii=False)
print(Counter((o[0],o[2]) for o in out))
