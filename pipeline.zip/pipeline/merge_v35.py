# -*- coding: utf-8 -*-
"""site_v34 + hsj/integ.json(정답·유형·해설) → site_v35.html, explain.json"""
import json, re
SRC = "/home/claude/site_v34.html"; DST = "/home/claude/site_v35.html"
D = json.load(open("/home/claude/hsj/integ.json", encoding="utf-8"))
lines = open(SRC, encoding="utf-8").read().split("\n")
def idx(n): return [k for k, l in enumerate(lines) if l.startswith(f"const {n} = ")][0]
items = D["items"]
for it in items:
    if f'{it["exam_id"]}||{it["영역"]}||{it["문항번호"]}' in D["explain"]: it["_h"] = 1
lines[idx("ITEMS")] = "const ITEMS = " + json.dumps(items, ensure_ascii=False) + ";"
pk = sorted(D["pexplain"].keys())
lines.insert(idx("PASSAGE_NOTES") + 1, "const PASSAGE_EXPLAIN_KEYS = new Set(" + json.dumps(pk, ensure_ascii=False) + ");")
s = "\n".join(lines)
json.dump({"i": D["explain"], "p": D["pexplain"]}, open("/home/claude/explain.json", "w", encoding="utf-8"), ensure_ascii=False, separators=(",", ":"))

def rep(old, new, cnt=1):
    global s
    assert s.count(old) == cnt, (s.count(old), old[:90])
    s = s.replace(old, new)

# ---- 문항 상세: 해설 보기 ----
rep("""      ${withJump ? `<button type="button" class="btn-line goto-exam" data-exam="${escapeHtml(it.exam_id)}" data-key="${escapeHtml(itemKey(it))}">지문과 함께 보기 →</button>` : ''}
    </div>
  `;
}""", """      ${it._h ? `<button type="button" class="btn-plain do-explain" data-key="${escapeHtml(itemKey(it))}" aria-expanded="false">해설 보기</button>` : ''}
      ${withJump ? `<button type="button" class="btn-line goto-exam" data-exam="${escapeHtml(it.exam_id)}" data-key="${escapeHtml(itemKey(it))}">지문과 함께 보기 →</button>` : ''}
    </div>
    ${it._h ? `<div class="explain" hidden></div>` : ''}
  `;
}

/* ---------- 해설(정답 및 해설 원자료) : 처음 열 때 explain.json을 한 번만 받아 온다 ---------- */
let explainData = null, explainLoading = null;
function loadExplain(){
  if(explainData) return Promise.resolve(explainData);
  if(!explainLoading){
    explainLoading = fetch('explain.json').then(r=>{ if(!r.ok) throw new Error(r.status); return r.json(); })
      .then(d=>{ explainData = d; return d; })
      .catch(err=>{ explainLoading = null; throw err; });
  }
  return explainLoading;
}
function explainHtml(text){
  return text.split(/\\n+/).map(p=>{
    let h = escapeHtml(p.trim());
    h = h.replace(/^\\[?(정답 ?해설|지문 ?해설|보기 ?해설)\\]?\\s*:?\\s*/, (m,a)=>`<b class="ex-h">${a.replace(' ','')}</b> `)
         .replace(/^\\[(오답 ?피하기)\\]\\s*/, '<b class="ex-h">오답 피하기</b> ');
    return `<p>${h}</p>`;
  }).join('');
}
async function toggleExplain(btn, kind){
  const box = kind==='p' ? btn.closest('.pg-body').querySelector('.explain') : btn.closest('.detail').querySelector('.explain');
  if(!box) return;
  const open = box.hidden;
  btn.setAttribute('aria-expanded', String(open));
  if(!open){ box.hidden = true; btn.textContent = kind==='p' ? '지문 해설 보기' : '해설 보기'; return; }
  box.hidden = false; btn.textContent = kind==='p' ? '지문 해설 닫기' : '해설 닫기';
  if(box.dataset.done) return;
  box.innerHTML = '<p class="ex-wait">해설을 불러오는 중입니다…</p>';
  try{
    const d = await loadExplain();
    const t = (kind==='p' ? d.p : d.i)[btn.dataset.key];
    const it = kind==='p' ? null : itemByKey(btn.dataset.key);
    box.innerHTML = t ? `<div class="ex-src">${kind==='p'?'지문 해설':'문항 해설'} · 해당 회차 「정답 및 해설」 원문${it && it.유형_해설확인 ? ` · 해설 유형: ${escapeHtml(it.유형_해설확인)}` : ''}</div>${explainHtml(t)}` : '<p class="ex-wait">이 문항의 해설은 아직 없습니다.</p>';
    box.dataset.done = '1';
  }catch(err){
    box.innerHTML = '<p class="ex-wait">해설을 불러오지 못했습니다. 잠시 뒤 다시 눌러 주세요.</p>';
  }
}
document.addEventListener('click', e=>{
  const b = e.target.closest('.do-explain'); if(b){ toggleExplain(b, 'i'); return; }
  const p = e.target.closest('.do-pexplain'); if(p){ toggleExplain(p, 'p'); }
});""")

# ---- 지문 해설 버튼 ----
rep("""  const notesHtml = notes.length ? `<div class="notes"><b>낱말 풀이</b><dl>${notes.map(n=>`<dt>${escapeHtml(n[0])}</dt><dd>${escapeHtml(n[1])}</dd>`).join('')}</dl></div>` : '';
  return body + notesHtml;""", """  const notesHtml = notes.length ? `<div class="notes"><b>낱말 풀이</b><dl>${notes.map(n=>`<dt>${escapeHtml(n[0])}</dt><dd>${escapeHtml(n[1])}</dd>`).join('')}</dl></div>` : '';
  const pkey = `${examId}||${g.영역}||${g.지문범위}`;
  const pex = PASSAGE_EXPLAIN_KEYS.has(pkey) ? `<div class="pex-bar"><button type="button" class="btn-plain do-pexplain" data-key="${escapeHtml(pkey)}" aria-expanded="false">지문 해설 보기</button></div><div class="explain" hidden></div>` : '';
  return body + notesHtml + pex;""")

# ---- CSS ----
rep(".notes{margin-top:10px;", """.explain{margin-top:12px;border:1px solid var(--line);border-left:3px solid var(--brand);background:var(--bg-sub);padding:12px 16px;font-size:calc(14px * var(--rs));line-height:1.8}
.explain p{margin:0 0 6px}
.explain .ex-h{color:var(--brand);margin-right:4px}
.explain .ex-src{font-size:12px;color:var(--text-faint);margin-bottom:6px}
.explain .ex-wait{color:var(--text-sub)}
.pex-bar{margin-top:10px}
.notes{margin-top:10px;""")

# ---- 정답 출처 안내 ----
rep("""  'EBS 기출의 미래(2023학년도판)': 'EBS 「2023학년도 수능 기출의 미래」 해설(2018~2021학년도 기출 수록)과 대조해 확인한 유형입니다. 이 회차들은 별도 공식 정답표가 없어 정답도 이 자료의 매칭 결과에 의존합니다.',""",
    """  'EBS 기출의 미래(2023학년도판)': 'EBS 「2023학년도 수능 기출의 미래」 해설(2018~2021학년도 기출 수록)과 대조해 확인한 유형입니다.',""")

# ---- 이용 안내 ----
def sub_between(start, end, new):
    global s
    i = s.index(start); j = s.index(end, i)
    s = s[:i] + new + s[j:]
rep("정답은 확보한 정답표로 1,440문항에 반영했고, 2014학년도 예비 시행 90문항은 정답표를 구하지 못해 정답이 없습니다.",
    "정답은 확보한 정답표로 1,440문항에 반영했고, 해당 회차 「정답 및 해설」의 정답표와도 모두 일치함을 확인했습니다(2012학년도 9월, 2013학년도 6월·9월은 해설 파일의 정답표 글자가 그림이라 대조하지 못했습니다). 2014학년도 예비 시행 90문항은 정답표를 구하지 못해 정답이 없습니다.")
sub_between("2018~2021학년도(12개 회차, 540문항)는 별도로 구할 수 있는 공식 정답표가 없어", "</p>",
    "2018~2021학년도(12개 회차, 540문항)는 해당 회차 「정답 및 해설」에 실린 정답표로 정답을 반영했습니다. 예전에는 공식 정답표를 구하지 못해 EBS 「2023학년도 수능 기출의 미래」 해설과 지문·발문을 대조해 정답을 붙였는데(443문항), 「정답 및 해설」 정답표와 맞춰 보니 그중 150문항이 틀려 있어 모두 바로잡았고, 비어 있던 97문항도 채웠습니다. 2022~2027학년도 952문항의 정답도 같은 정답표와 모두 일치합니다. 배점은 문제지에 인쇄된 값을 그대로 반영했습니다.")
sub_between("<p>2018~2027학년도 문항은 공식·사설 해설 자료와 대조해 유형을 검증했습니다", "</p>",
    "<p>문항마다 해당 회차 「정답 및 해설」에 적힌 유형 이름을 확인해 유형 묶음을 정했습니다(\"유형 확인\" 표시, 전체 3,022문항 중 2,593문항). 2009~2017학년도는 1,530문항 중 1,273문항, 2018~2021학년도는 540문항 중 438문항을 「정답 및 해설」로 확인했습니다. 2018~2021학년도는 예전에 EBS 「기출의 미래」와 대조해 붙였던 유형을 「정답 및 해설」 유형으로 바꾸었고, 「정답 및 해설」로 확인하지 못한 문항(2018학년도 6월·수능 등 해설 파일의 글자가 그림이라 읽을 수 없는 회차)은 EBS 대조 결과도 믿기 어려워 확인 표시를 뺐습니다. 2022~2027학년도는 공식 「정답 및 해설」(728문항), EBS 「기출의 미래」(99문항), 사설 학원(바탕국어연구소) 해설지(55문항)와 대조했습니다. 해설 자료에 적힌 원래 유형 이름은 문항을 펼치면 \"해설 표기\"로 함께 보이고, 확인 표시가 없는 문항은 발문 패턴에 따른 자동 분류입니다.")
rep("""        <summary>2009~2017학년도 기출 정리 방법</summary>""", """        <summary>해설 보기</summary>
        <p>문항을 펼쳐 "해설 보기"를 누르면 해당 회차 「정답 및 해설」의 문항 해설(정답 해설·오답 피하기)을 원문 그대로 보여 줍니다. 회차 화면에서는 지문 아래 "지문 해설 보기"로 지문 해설도 볼 수 있습니다. 해설에는 정답이 나오므로 먼저 풀어 본 뒤 여는 것이 좋습니다. 2009~2027학년도 문항 중 2,678문항에 해설이 있습니다. 해설 파일의 글자가 그림이라 읽을 수 없는 회차(2012학년도·2017학년도·2018학년도 수능, 2018학년도 6월), 해설 파일이 없는 회차(2023학년도 9월, 2014학년도 예비 시행)와 일부 문항은 해설이 없습니다. 해설은 처음 누를 때 한 번 내려받으므로 잠깐 걸릴 수 있습니다.</p>
      </details>
      <details>
        <summary>2009~2017학년도 기출 정리 방법</summary>""")

open(DST, "w", encoding="utf-8").write(s)
print("ok", len(s.encode()) / 1e6, "MB; explain.json", len(open("/home/claude/explain.json", "rb").read()) / 1e6, "MB")
