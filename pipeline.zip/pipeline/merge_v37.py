# -*- coding: utf-8 -*-
"""merge_v36을 다시 돌린 뒤, 원본 문제지와 대조해 확인한 선지·제시 자료 보정(Stage 22)을 반영한다 → site_v37.html
보정 근거: /home/claude/chk/ (fixes.py: 그림으로 확인한 보정표, src_fix.json: 원본 PDF 글자 흐름에서 다시 뽑은 선지, fix_boiler.json 규칙)"""
import json, subprocess, re, sys
subprocess.run(["python3", "/home/claude/merge_v36.py"], check=True)
SRC = "/home/claude/site_v36.html"; DST = "/home/claude/site_v37.html"
lines = open(SRC, encoding="utf-8").read().split("\n")
def idx(n): return [k for k, l in enumerate(lines) if l.startswith(f"const {n} = ")][0]
def load(n): return json.loads(lines[idx(n)][len(f"const {n} = "):].rstrip(";"))
def save(n, v): lines[idx(n)] = f"const {n} = " + json.dumps(v, ensure_ascii=False) + ";"
ITEMS = load("ITEMS"); CHO = load("CHOICES"); PAS = load("PASSAGES")
IT = {f'{i["exam_id"]}||{i["영역"]}||{i["문항번호"]}': i for i in ITEMS}
ns = {}; exec(open("/home/claude/chk/fixes.py", encoding="utf-8").read(), ns); FIX = ns["FIX"]
SRCFIX = json.load(open("/home/claude/chk/src_fix.json", encoding="utf-8"))
log = {}
def mark(k, why):
    log[k] = why; IT[k]["_선지보정"] = why

# 1) 시험지 끝 안내문(‘답안지의 해당란에 … 확인하시오’, ‘※ 확인 사항’)이 마지막 선지에 붙은 것 떼기
BP = re.compile(r"\s*(\*\*\s*확확인인.*|◦?\s*답안지의 해당란에 필요한.*)$")
for k, v in CHO.items():
    v2 = [BP.sub("", c) for c in v]
    if v2 != v: CHO[k] = v2; mark(k, "시험지 끝 안내문(답안지 확인 문구)이 ⑤번 선지 뒤에 붙어 있었음")

# 2) 다른 글꼴로 된 낱말(책 이름·△△신문·○○ 등)이 앞 선지 끝으로 밀려나 있던 것: 원본 글자 흐름에서 다시 뽑은 선지로 교체
for k, v in SRCFIX.items():
    if k in FIX: continue
    assert len(v) == 5 and all(v), k
    CHO[k] = v; mark(k, "다른 글꼴로 된 낱말(책 이름·기호 등)이 앞 선지 끝으로 밀려나 있었음")
CHO["2023-06||독서||8"][4] = "ㄷ의 관점에 따르면, 『치평요람』 편찬과 관련한 세종의 생각에서 학문의 근본은 도의 본체에, 현실에서 학문의 구현은 도의 큰 쓰임에 대응하겠군."

# 3) 두 줄짜리(ⓐ/ⓑ, ㉠/㉡, A/B) 선지: 첫 줄이 한 칸씩 밀려 ①의 첫 줄이 <보기> 끝에 붙어 있던 것
BRACKET = ["2020-06||언어와 매체||15", "2020-11||화법과 작문||10", "2023-09||언어와 매체||38", "2026-09||독서||9",
           "2026-09||화법과 작문||45", "2026-11||독서||13", "2027-09||언어와 매체||37", "2015-06-A||언어와 매체||13",
           "2015-11-A||언어와 매체||12", "2016-06-A||언어와 매체||13", "2016-09-A||언어와 매체||15", "2016-11-A||언어와 매체||13",
           "2017-11||언어와 매체||15"]
LAB = r"(ⓐ|㉠|A)\s*:"
for k in BRACKET:
    ch = CHO[k]; it = IT[k]; b = it.get("보기") or ""
    m = re.search(r"\s(" + LAB + r".*)$", ch[0]); lab = m.group(2)
    bi = max(b.rfind(lab + ":"), b.rfind(lab + " :")); assert bi >= 0, k
    first = b[bi:].strip(); it["보기"] = b[:bi].rstrip()
    out = []; prev = first
    for j in range(5):
        c = ch[j]
        mm = re.search(r"\s(" + LAB + r".*)$", c) if j < 4 else None
        own = c[:mm.start()].strip() if mm else c.strip()
        tag = re.match(r"^(ⓐ|ⓑ|ⓒ)\s+(B\s*:.*)$", own)       # 2015-11-A, 2016-11-A: 앞에 ⓐ~ⓒ 표시가 붙는 문항
        out.append(f"{tag.group(1)} {prev} {tag.group(2)}" if tag else f"{prev} {own}")
        prev = mm.group(1).strip() if mm else None
    out = [re.sub(r"\s+", " ", re.sub(r"B :", "B:", x)).strip() for x in out]
    CHO[k] = out; mark(k, "두 줄짜리 선지의 첫 줄이 한 칸씩 밀려 있었음(①의 첫 줄은 <보기> 끝에 붙어 있었음)")

# 4) 그림과 대조해 직접 옮긴 보정
for k, d in FIX.items():
    it = IT[k]
    if "choices" in d: CHO[k] = d["choices"]
    if "bogi_set" in d: it["보기"] = d["bogi_set"]
    for old, new in d.get("bogi", []):
        b = it.get("보기") or ""
        assert old in b, (k, old); it["보기"] = b.replace(old, new, 1)
    mark(k, d["why"])

# 5) 기타
for k in ["2020-06||독서||19", "2023-06||화법과 작문||41"]:       # 표제·부제 사이 줄표가 빠짐
    src = json.load(open("/home/claude/chk/diff.json"))
    src = [r for r in src if r["key"] == k][0]["src"]
    CHO[k] = [re.sub(r"\s*-\s*", " - ", x, count=1) for x in src]; mark(k, "표제와 부제 사이의 줄표(-)가 빠져 있었음")
c = CHO["2011-09||문학||21"][4]; CHO["2011-09||문학||21"][4] = c[:c.index("해소했다.") + len("해소했다.")]
mark("2011-09||문학||21", "⑤번 선지 뒤에 다음 문항의 <보기>가 붙어 있었음")
for k in ["2009-09||독서||15", "2009-09||독서||44"]:              # 선지가 그림(도식)이라 글로 옮길 수 없음 → 빈 선지 대신 ‘표시할 수 없음’ 안내
    del CHO[k]; mark(k, "선지가 그림(도식)이라 글로 옮길 수 없음")

# 6) 2014학년도 수능 A·B형 9~10번 지문(그림이던 신문 기사·게시판 글) – 스캔 문제지에서 옮김
P910 = ("※ 작문 상황: (가)를 읽고, 친구들에게 나눔 도서관을 소개하기 위해 (나)를 썼다.\n\n"
        "(가) 신문 기사\n□□신문\n○○시는 최근 ‘나눔 도서관’을 운영하기 시작했다. 나눔 도서관에서는 책은 물론 사용하지 않는 물건들도 이웃과 나눌 수 있다. 또한 이 도서관은 노인들을 대상으로 ‘듣는 책 교실’도 운영하고 있다.\n\n"
        "(나) 학교 누리집 게시판에 올린 글\n[게시판]\n"
        "저는 얼마 전 신문에서 나눔 도서관에 관한 기사를 읽고 그곳을 찾아가 더 자세한 정보를 알아보았습니다. 나눔 도서관은 나눔의 정신을 실천할 수 있는 곳으로 우리가 이용해 볼 만한 충분한 가치가 있다고 생각하여 소개합니다.\n"
        "우선 나눔 도서관은 책을 공유하는 나눔의 성격이 ㉠강화되어진 도서관입니다. 이 도서관은 책을 필요로 하는 사람에게 책을 무료로 나눠 주기도 하고, 시민들로부터 책을 ㉡기여받기도 합니다.\n"
        "보고서에 따르면 우리 국민의 절반 이상이 한 번 읽은 책은 더 이상 읽지 않고 집에 쌓아 둔다고 합니다. 여러분도 한 번 읽고 책꽂이에 꽂아 둔 책이 한두 권씩은 있을 거예요. 그리고 책을 사고 싶지만 책값이 부담되어 망설이며 고민하던 때도 있지 않았나요? 나눔 도서관이 그런 고민을 해결해 줄 것입니다.\n"
        "㉢그 동전으로 나눔터에 있는 다른 물품을 구입할 수 있습니다. 그뿐만 아니라 쓰지 않는 물품은 도서관 내의 ‘나눔터’에서 ‘나눔 동전’으로 교환할 수 있습니다. 혹시 사용하지 않는 물건들이 있나요? 그렇다면 여러분도 나눔 동전과 교환하여 자신에게 ㉣요청되는 물건을 구입해 보세요.\n"
        "㉤이처럼 나눔 도서관은 책은 물론 여러 물건들을 함께 나눌 수 있는 공간입니다. 우리도 나눔 도서관을 적극적으로 이용해 보아요. 지금 [도서관 누리집]을 누르시면 나눔 도서관 누리집으로 바로 연결되어 더 자세한 정보를 얻을 수 있습니다.\n"
        "└ 댓글")
for X in "AB":
    pk = f"2014-11-{X}||화법과 작문||9~10"
    assert pk not in PAS, pk
    PAS[pk] = P910

# 7) 책 이름 묶음표가 다른 문자(ꡔ ꡕ)로 들어가 있던 것을 『 』로
def bk(t): return t.replace("ꡔ", "『").replace("ꡕ", "』") if isinstance(t, str) else t
CHO = {k: [bk(x) for x in v] for k, v in CHO.items()}
PAS = {k: bk(v) for k, v in PAS.items()}
for it in ITEMS:
    for f in ("발문", "보기"):
        if it.get(f): it[f] = bk(it[f])

# 검증: 빈 선지·안내문 잔재가 없어야 한다
for k, v in CHO.items():
    assert len(v) == 5 and all(x.strip() for x in v), (k, v)
    assert not any(re.search(r"답안지의 해당란|확확인인", x) for x in v), k
save("ITEMS", ITEMS); save("CHOICES", CHO); save("PASSAGES", PAS)
s = "\n".join(lines)
def rep(old, new, cnt=1):
    global s
    assert s.count(old) == cnt, (s.count(old), old[:80]); s = s.replace(old, new)
rep(" 2014학년도 수능(A·B형)의 9~10번 지문(신문 기사·게시판 글)과 9번 선택지는 원본 파일에서도 그림이라 싣지 못했습니다.",
    " 2014학년도 수능(A·B형)의 9~10번 지문(신문 기사·게시판 글)과 9번 선택지는 한글 파일에서 그림이라 스캔 문제지를 보고 옮겼습니다.")
n_fix = len(log)
n_all = len(ITEMS); n_ch = sum(1 for k in IT if k in CHO); n_no = n_all - n_ch
rep("이렇게 확보한 선택지는 1,492문항 중 1,479문항(약 99.1%)입니다. 나머지 13문항 중 8개는 EBS 교재도 선택지를 표·그림 형태 그대로 실어 두어서 원문을 구할 수 없었고, 5개는 발문 표기 차이 등으로 EBS 교재에서 해당 문항 자체를 찾지 못했습니다. 이 13문항은 \"선택지 정보를 표시할 수 없습니다\"로 표시됩니다.",
    f"지금은 전체 {n_all:,}문항 중 {n_ch:,}문항의 선택지를 싣고 있으며, 나머지 {n_no}문항은 선택지가 그래프·도식 그림이라 \"선택지 정보를 표시할 수 없습니다\"로 표시됩니다. 2026년 10월에 모든 문항의 선택지를 원본 문제지와 하나하나 대조해 {n_fix}문항을 바로잡았습니다 — 표 속 줄 끝에 번호(……①)가 붙은 선택지가 비거나 섞인 것, 두 줄짜리 선택지(ⓐ/ⓑ 등)의 첫 줄이 한 칸씩 밀린 것, 책 이름·기호처럼 다른 글꼴로 된 낱말이 앞 선택지 끝으로 밀려난 것, 시험지 끝 안내문(답안지 확인 문구)이 마지막 선택지에 붙은 것, 다음 문항의 선택지가 잘못 들어간 것 등입니다. 표 속 선택지는 그 줄의 칸 이름을 [ ]·( ) 안에, 왼쪽 칸 내용을 ‘→’ 앞에 함께 적었고, 이런 문항의 표 전체 내용은 제시 자료(&lt;보기&gt;) 칸에 옮겨 두었습니다.")
json.dump(log, open("/home/claude/chk/applied_log.json", "w"), ensure_ascii=False, indent=0)
open(DST, "w", encoding="utf-8").write(s)
print("ok fixes", n_fix, "choices", len(CHO), len(s.encode()) / 1e6, "MB")
