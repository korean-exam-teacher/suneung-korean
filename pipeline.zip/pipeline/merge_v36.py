# -*- coding: utf-8 -*-
"""merge_v35(정답·유형·해설 반영)을 다시 돌린 뒤, HWP로 새로 합류한 회차(2009 수능, 2014 수능 A/B)의 지문·선택지를 넣고 안내문을 고친다 → site_v36.html"""
import json, subprocess, re
subprocess.run(["python3", "/home/claude/merge_v35.py"], check=True)
SRC = "/home/claude/site_v35.html"; DST = "/home/claude/site_v36.html"
NB = json.load(open("/home/claude/hwp/new_bundle.json", encoding="utf-8"))
lines = open(SRC, encoding="utf-8").read().split("\n")
def idx(n): return [k for k, l in enumerate(lines) if l.startswith(f"const {n} = ")][0]
def load(n): return json.loads(lines[idx(n)][len(f"const {n} = "):].rstrip(";"))
def save(n, v): lines[idx(n)] = f"const {n} = " + json.dumps(v, ensure_ascii=False) + ";"
PAS = load("PASSAGES"); CHO = load("CHOICES"); NOTES = load("PASSAGE_NOTES")
for k in NB["passages"]: assert k not in PAS, k
PAS.update(NB["passages"]); CHO.update(NB["choices"]); NOTES.update(NB["notes"])
# 2014학년도 예비 시행 B형 7번: 선택지 번호가 표의 줄 끝에 붙어 있어(“……①”) 선택지·제시 자료가 어긋나 있던 것을 원본 줄 순서대로 바로잡는다
ITEMS = load("ITEMS")
k7 = "2014-예비-B||화법과 작문||7"
assert CHO[k7][3].startswith("방향 3."), CHO[k7]
CHO[k7] = ["연령대별 결혼율에 대한 통계 자료", "미혼자를 대상으로 한 결혼 관련 인터뷰 자료",
           "서론: 저출산 문제와 결혼 연기 현상의 관련성을 지적하여 논의의 필요성을 밝힘.",
           "본론: 2. 저출산 문제의 심각성을 제시함.", "본론: 3. 자료들을 통해 결혼이 늦어지는 사회적 원인들을 분석함."]
it7 = [i for i in ITEMS if i["exam_id"] == "2014-예비-B" and i["문항번호"] == 7][0]
it7["보기"] = ("주제문 ◦결혼하기 좋은 환경을 만들어 저출산 문제를 해결하자.\n"
              "논거 자료 ◦연령대별 결혼율에 대한 통계 자료 ······ ①\n"
              "　　　　 ◦결혼을 미루는 이유에 대한 설문 조사 자료\n"
              "　　　　 ◦미혼자를 대상으로 한 결혼 관련 인터뷰 자료 ······ ②\n"
              "　　　　 ◦결혼 비용 관련 통계 자료\n"
              "　　　　 ◦청년 실업률, 취업자 중 비정규직 비율에 대한 통계 자료\n"
              "내용 구성 방향 ◦서론: 저출산 문제와 결혼 연기 현상의 관련성을 지적하여 논의의 필요성을 밝힘. ······ ③\n"
              "　　　　 ◦본론: 1. 결혼이 늦어지고 있는 실태를 제시함.\n"
              "　　　　　　 2. 저출산 문제의 심각성을 제시함. ······ ④\n"
              "　　　　　　 3. 자료들을 통해 결혼이 늦어지는 사회적 원인들을 분석함. ······ ⑤\n"
              "　　　　　　 4. 분석한 원인별로 해결 방안을 제시함.\n"
              "　　　　 ◦결론: 논의를 종합하며 주제를 강조함.")
save("ITEMS", ITEMS); save("CHOICES", CHO); save("PASSAGES", PAS); save("PASSAGE_NOTES", NOTES)
s = "\n".join(lines)
n_all = len(ITEMS); n_old = sum(1 for i in ITEMS if i["exam_id"] < "2018")
n_exams = len({i["exam_id"] for i in ITEMS}); n_old_exams = len({i["exam_id"] for i in ITEMS if i["exam_id"] < "2018"})
ans_old = sum(1 for i in ITEMS if i["exam_id"] < "2018" and i["정답"] and "예비" not in i["exam_id"])
n_pre = sum(1 for i in ITEMS if "예비" in i["exam_id"] and i["정답"])
def ver(i): return (not i.get("_유형재분류")) and bool(i.get("_유형출처") or i.get("_ebs_매칭") == "passage_anchor")
v_all = sum(1 for i in ITEMS if ver(i)); v_old = sum(1 for i in ITEMS if i["exam_id"] < "2018" and ver(i))
v_1821 = sum(1 for i in ITEMS if "2018" <= i["exam_id"] < "2022" and ver(i))
n_h = sum(1 for i in ITEMS if i.get("_h"))
f = lambda n: f"{n:,}"

def rep(old, new, cnt=1):
    global s
    assert s.count(old) == cnt, (s.count(old), old[:80])
    s = s.replace(old, new)

rep("""  '2009-9': '2009학년도 9월 모의평가: 확보한 문제지가 스캔 이미지뿐이라 아직 싣지 못했습니다.',
  '2009-11': '2009학년도 수능: 확보한 문제지가 스캔 이미지뿐이라 아직 싣지 못했습니다.',
  '2014-11': '2014학년도 수능(A형·B형): 확보한 문제지가 스캔 이미지뿐이라 아직 싣지 못했습니다.',
""", "")
rep(" 미수록 회차는 원본 문제지가 스캔 이미지뿐이라 글자를 옮기지 못한 회차입니다.", "")
rep("모두 63개 회차 3,022문항을", f"모두 {n_exams}개 회차 {f(n_all)}문항을")
rep("<p><b>2009~2017학년도</b>(34개 회차, 1,530문항): 2009학년도 6월, 2010~2013학년도 6월·9월·수능, 2014학년도 6월·9월(A·B형)과 예비 시행(A·B형), 2015·2016학년도 6월·9월·수능(A·B형), 2017학년도 6월·9월·수능. 2009학년도 9월·수능과 2014학년도 수능은 확보한 문제지가 스캔 이미지뿐이라 아직 싣지 못했습니다(표에 \"미수록\"으로 표시). 정답은 확보한 정답표로 1,440문항에 반영했고,",
    f"<p><b>2009~2017학년도</b>({n_old_exams}개 회차, {f(n_old)}문항): 2009학년도 6월·9월·수능, 2010~2013학년도 6월·9월·수능, 2014학년도 6월·9월·수능(A·B형)과 예비 시행(A·B형), 2015·2016학년도 6월·9월·수능(A·B형), 2017학년도 6월·9월·수능. 2009학년도 9월·수능과 2014학년도 수능(A·B형)은 PDF가 스캔 이미지라 한글(HWP) 문제지 파일에서 옮겼습니다. 2014학년도 수능(A·B형)의 9~10번 지문(신문 기사·게시판 글)과 9번 선택지는 원본 파일에서도 그림이라 싣지 못했습니다. 정답은 확보한 정답표로 {f(ans_old)}문항에 반영했고,")
rep("(\"유형 확인\" 표시, 전체 3,022문항 중 2,593문항). 2009~2017학년도는 1,530문항 중 1,273문항, 2018~2021학년도는 540문항 중 438문항을",
    f"(\"유형 확인\" 표시, 전체 {f(n_all)}문항 중 {f(v_all)}문항). 2009~2017학년도는 {f(n_old)}문항 중 {f(v_old)}문항, 2018~2021학년도는 540문항 중 {v_1821}문항을")
rep("「정답 및 해설」로 확인하지 못한 문항(2018학년도 6월·수능 등 해설 파일의 글자가 그림이라 읽을 수 없는 회차)은",
    "「정답 및 해설」에 유형 이름이 없거나 유형 이름을 묶음에 대응시키지 못한 문항은")
rep("2009~2027학년도 문항 중 2,678문항에 해설이 있습니다. 해설 파일의 글자가 그림이라 읽을 수 없는 회차(2012학년도·2017학년도·2018학년도 수능, 2018학년도 6월), 해설 파일이 없는 회차(2023학년도 9월, 2014학년도 예비 시행)와 일부 문항은 해설이 없습니다.",
    f"2009~2027학년도 문항 중 {f(n_h)}문항에 해설이 있습니다. 일부 문항은 해설이 없습니다. 2014학년도 예비 시행 해설은 이투스청솔 교육평가연구소의 「2014 수능 예비시험 정답 및 해설」에서 사용 허락을 받아 옮겼습니다(평가원 공식 해설이 아님). 2017학년도 수능 해설은 EBS 해설 파일, 2018학년도 6월 해설은 한글(HWP) 해설 파일에서 옮겼고, 2012·2018학년도 수능 해설은 PDF 안 글꼴의 글자 정보가 깨져 있어 글꼴 내부의 글자 배열로 되살렸습니다(되살리지 못한 옛한글 몇 글자는 □로 표시). 해설 원문의 정답 표기가 정답표와 다른 경우(해설 쪽 오기)에는 해설 아래에 안내를 붙였습니다.")
rep("2014학년도 예비 시행 90문항은 정답표를 구하지 못해 정답이 없습니다.",
    f"2014학년도 예비 시행 {n_pre}문항의 정답은 평가원 정답표를 구하지 못해, 이투스청솔 교육평가연구소 「2014 수능 예비시험 정답 및 해설」의 정답표로 넣었습니다(해설 본문의 문항별 정답 표기와 모두 일치함을 확인).")
open(DST, "w", encoding="utf-8").write(s)
print("ok", n_all, n_exams, "verified", v_all, "explained", n_h, len(s.encode())/1e6, "MB")
